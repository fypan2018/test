function d_est = EstEr(X_mat,M,N)
% Model order selection
[U,S,V] = svd(X_mat);
% Calculating U up and U down
U_up = U(2:M,:);
U_down = U(1:(M-1),:);

d_max = min(M-2,N);
E_est = zeros(1,d_max);
for kk = 1:d_max
    phi_est = pinv(U_down(:,1:kk))*U_up(:,1:kk);
    E_aux = (U_down(:,1:kk)*phi_est-U_up(:,1:kk));
    %     E_est(kk) = norm(E_aux*(E_aux'),2);
    E_est(kk) = norm(E_aux,2)^2;
end
% inv_E_est = (E_est).^(-1);
% [value,d_est] = max(inv_E_est);
[value,d_est] = min(E_est);