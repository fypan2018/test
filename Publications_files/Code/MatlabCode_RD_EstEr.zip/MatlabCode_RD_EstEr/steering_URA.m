function a = steering_URA(theta,M,fc,d)
% generates a steering vector for ULA array
% theta: angle of arrival (in degree)
% M: number of antennas
% fc: carrier frequency (in Hz)
% d: inter-element spacing (in meter)

c=3e8;        % speed of light in meter/sec
Lambda=c/fc;  % wavelength in meter
m1=[0:M(1)-1].';
m2=[0:M(2)-1].';
a1=exp(j*2*pi*m1*d*cos(pi*theta(1)/180)*cos(pi*theta(2)/180)/Lambda);
a2=exp(j*2*pi*m2*d*sin(pi*theta(1)/180)*cos(pi*theta(2)/180)/Lambda);
a = krp(a2,a1);