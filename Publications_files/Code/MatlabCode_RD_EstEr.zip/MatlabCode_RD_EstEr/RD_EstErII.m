function d_est = RD_EstErII(X,sizeX,R)
% Model order selection
%
[S,U] = hosvd(X);
%
d_max = max(sizeX(1:R))-2;
E_est = zeros(1,d_max);
for kk = 1:d_max
    
    [Sc,Uc] = cuthosvd(S,U,kk);
    
    u_1_tensor = Sc;%id_tensor;
    u_2_tensor = Sc;%id_tensor;
    %phi_est = cell(1,R);
    for rr = 1:R
        u_1_tensor = nmode_product(u_1_tensor,Uc{rr}(1:sizeX(rr)-1,1:min(kk,sizeX(rr))),rr);
        u_2_tensor = nmode_product(u_2_tensor,Uc{rr}(2:sizeX(rr),1:min(kk,sizeX(rr))),rr);
    end
    unfold_u_1 = unfolding(u_1_tensor, length(sizeX));
    unfold_u_2 = unfolding(u_2_tensor, length(sizeX));
    phi_est = unfold_u_2*pinv(unfold_u_1);
    % norm(unfold_u_2 - phi_est*unfold_u_1,'fro')^2
    E_est(kk) = norm(unfold_u_2 - phi_est*unfold_u_1,'fro')^2;
end
%
% inv_E_est = (E_est).^(-1);
% [value,d_est] = max(inv_E_est);
[value,d_est] = min(E_est);

% function d_est = RD_EstEr(X,sizeX,N)
% % Model order selection
% %[U,S,V] = svd(X_mat);
% R = length(size(X)) - 1;
% %
% [S,U] = hosvd(X);
% %
% d_max = min([sizeX N]);
% E_est = zeros(1,d_max-2);
% for kk = 1:(d_max-2)%(d_max-2)
%     
%     [Sc,Uc] = cuthosvd(S,U,kk);
%     
%     u_1_tensor = Sc;%id_tensor;
%     u_2_tensor = Sc;%id_tensor;
%     %phi_est = cell(1,R);
%     for rr = 1:R
%         u_1_tensor = nmode_product(u_1_tensor,Uc{rr}(1:sizeX(rr)-1,1:kk),rr);
%         u_2_tensor = nmode_product(u_2_tensor,Uc{rr}(2:sizeX(rr),1:kk),rr);
%     end
%     unfold_u_1 = unfolding(u_1_tensor, R+1);
%     unfold_u_2 = unfolding(u_2_tensor, R+1);
%     phi_est = unfold_u_2*pinv(unfold_u_1);
%     % norm(unfold_u_2 - phi_est*unfold_u_1,'fro')^2
%     E_est(kk) = norm(unfold_u_2 - phi_est*unfold_u_1,'fro')^2;
% end
% %
% % inv_E_est = (E_est).^(-1);
% % [value,d_est] = max(inv_E_est);
% [value,d_est] = min(E_est);