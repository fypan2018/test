function K = rank_est_RD_AIC(lambda,p,n)
% function K = rank_est_WK(lambda,p,n)
% AIC estimator for number of signals

R = length(p);
dim = min(p(R),n(R));
AIC = zeros(dim,1);

for k=0:dim-1
    AIC(k+1) = 0;
    
    for r=1:R
        a = 1/(p(r)-k) * sum(lambda{r}(k+1:p(r)));
        temp = -(p(r)-k)*n(r)*(  1/(p(r)-k) * sum(log(lambda{r}(k+1:p(r)))) - log(a) ) ;
        temp = temp + k * (2*p(r)-k) ;
        AIC(k+1) = AIC(k+1)+temp;
    end
end

[val, loc] = min(AIC);

K = loc-1;

return;