function [ str] = array2string( x )

L = length(x);
if L==1
    str = num2str(x(L));
    return;
else
    str='[';
    for l=1:L-1
        str = [str,num2str(x(l)),', '];
    end
    str = [str,num2str(x(L)),']'];
end
end
