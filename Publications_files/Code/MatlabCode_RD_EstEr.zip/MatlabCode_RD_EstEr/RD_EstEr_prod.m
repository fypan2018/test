function d_est = RD_EstEr_prod(X,sizeX,R)
% Model order selection

[dim1,I1] = sort(sizeX(1:R),2,'descend');

for rr = 1:R
    [U,S,V] = svd(unfolding(X,I1(rr)));
    % Calculating U up and U down
    U_up{rr} = U(2:dim1(rr),:);
    U_down{rr} = U(1:(dim1(rr)-1),:);
end

%
rr_start = 1; dim1(R+1) = 0;
d_max = dim1(rr_start)-2;
E_est = ones(1,d_max);
for rr_end=rr_start:R
    if dim1(rr_end+1)<dim1(rr_end)
        break;
    end
end
for rr=rr_start:rr_end
    for kk = 1:d_max%(d_max-2)
        phi_est = pinv(U_down{rr}(:,1:kk))*U_up{rr}(:,1:kk);
        E_aux = (U_down{rr}(:,1:kk)*phi_est-U_up{rr}(:,1:kk));
        %     E_est(kk) = norm(E_aux*(E_aux'),2);
        E_est(kk) = E_est(kk) * norm(E_aux,2)^2;
    end
end
[value,d_est] = min(E_est);
while(rr<=R)
    rr_start = rr+1;
    d_max = dim1(rr_start)-2;
    
    if d_est<=d_max
        
        for rr_end=rr_start:R
            if dim1(rr_end+1)<dim1(rr_end)
                break;
            end
        end
        
        for rr=rr_start:rr_end
            for kk = 1:d_max
                phi_est = pinv(U_down{rr}(:,1:kk))*U_up{rr}(:,1:kk);
                E_aux = (U_down{rr}(:,1:kk)*phi_est-U_up{rr}(:,1:kk));
                %     E_est(kk) = norm(E_aux*(E_aux'),2);
                E_est(kk) = E_est(kk) * norm(E_aux,2)^2;
            end
            
            [value,d_est] = min(E_est(1:d_max));
        end
        
    else
        break;
    end
end

end