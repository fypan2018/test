function y = dec2binxarray( x, N )

for n=1:N
    y(n) = mod(x,2);
    x = floor(x/2);
end

