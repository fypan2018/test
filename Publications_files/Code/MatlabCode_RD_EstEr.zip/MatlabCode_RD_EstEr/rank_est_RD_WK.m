function K = rank_est_RD_WK(lambda,p,n)
% function K = rank_est_WK(lambda,p,n)
% MDL estimator for number of signals proposed by
% Wax & Kailath in
% "Detection of signals by information theoretic criteria", IEEE
% Transactions on Acoustics, Speech and Signal Processing 33 (2) (1985)
% 387�392.

R = length(p);
dim = min(p(R),n(R));
MDL = zeros(dim,1);

for k=0:dim-1
    MDL(k+1) = 0;
    
    for r=1:R
        a = 1/(p(r)-k) * sum(lambda{r}(k+1:p(r)));
        temp = -(p(r)-k)*n(r)*(  1/(p(r)-k) * sum(log(lambda{r}(k+1:p(r)))) - log(a) ) ;
        temp = temp + 1/2 * k * (2*p(r)-k) * log(n(r));
        MDL(k+1) = MDL(k+1)+temp;
    end
end

[val, loc] = min(MDL);

K = loc-1;

return;
