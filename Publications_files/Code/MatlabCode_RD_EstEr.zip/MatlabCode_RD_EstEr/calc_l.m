function [L] = calc_l(rho,M)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% returns the L functions
% with correlation rho(ii) for M antennas
%
% by J.P.C.L. da Costa
%
% modified by Stefanie Schwarz
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
K = length(rho);
L = cell(1,K);

for k = 1:K
    %
    rho_comp = sqrt(1-rho(k)^2);
    for m = 1:M(k)
        aux_vec = (0:1:(M(k)-m))';
        if (m == 1)
            aux_vec = rho(k).^aux_vec;
        else
            aux_vec = rho(k).^aux_vec;
            aux_vec = rho_comp*aux_vec;
        end
        L{k}(m:M(k),m) = aux_vec;
    end
end;