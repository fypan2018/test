function d_est = ITW_EstEr(X,sizeX,R)
% Model order selection
%
for rr = 1:R
    [U,S,V] = svd(unfolding(X,rr));
    % Calculating U up and U down
    U_up{rr} = U(2:sizeX(rr),:);
    U_down{rr} = U(1:(sizeX(rr)-1),:); 
end
%
d_max = min(sizeX(1:R))-2;

for kk = 1:d_max %(min_M_N-2)
    id_tensor = supereye(R+1,kk); % supereye(R,kk);
    u_1_tensor = id_tensor;
    u_2_tensor = id_tensor;
    for rr = 1:R
        phi_est{rr} = pinv(U_down{rr}(:,1:min(kk,sizeX(rr))))*U_up{rr}(:,1:min(kk,sizeX(rr)));
        u_1_tensor = nmode_product(u_1_tensor,U_down{rr}(:,1:min(kk,sizeX(rr)))*phi_est{rr},rr);
        u_2_tensor = nmode_product(u_2_tensor,U_up{rr}(:,1:min(kk,sizeX(rr))),rr);
    end
    E_est(kk) = ho_norm(u_2_tensor - u_1_tensor);
end
%
% inv_E_est = (E_est).^(-1);
% [value,d_est] = max(inv_E_est);
[value,d_est] = min(E_est);