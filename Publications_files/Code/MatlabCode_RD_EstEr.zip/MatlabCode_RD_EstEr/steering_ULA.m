function a = steering_ULA(theta,M,fc,d)
% generates a steering vector for ULA array
% theta: angle of arrival (in degree)
% M: number of antennas
% fc: carrier frequency (in Hz)
% d: inter-element spacing (in meter)

c=3e8;        % speed of light in meter/sec
Lambda=c/fc;  % wavelength in meter
m=0:M-1;
a=exp(j*2*pi*m*d*sin(pi*theta/180)/Lambda);
a=a.';