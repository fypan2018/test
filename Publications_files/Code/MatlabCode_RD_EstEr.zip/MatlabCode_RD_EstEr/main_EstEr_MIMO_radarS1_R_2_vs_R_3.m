clc; clear all; close all
tic

addpath('tensor_toolbox');
addpath('hoesprit');

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %
% % Parameter Estimation
% %
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%

%*******************************************************************
% SELECT DATA PARAMETERS
%*******************************************************************

tarmod='S1'                % Target model ('S1' for Swerling I or 'S2' for Swerling II)
SwerlingType = 1;
Mt=8;                       % number of transmit antennas
Mr=8;                       % number of receive antennas
Q=8;                       % Number of pulses (transmitted waveform)
L=64;                      % Number of samples for each transmitted pulse
Tp=5e-6;                    % pulse duration in sec.
%SNR=10;                     % SNR value (choose SNR=inf if no noise)
fc = 1e9;                   % carrier frequency in Hz
c = 3e8;                    % speed of light (m/s)
Lambda = c/fc;              % wavelength (m)
dt=Lambda/2;                % inter-element spacing at ULA transmitter (m)
dr=Lambda/2;                % inter-element spacing at ULA receiver (m)

K=3; %5;                        % number of targets
Var_mat=0.3:0.1:0.3+0.1*(K-1);%
% Var_mat=[0.3 0.4 0.5].';    % Variances of target RCS coefficients
%                                         % (to model Swerling 2 RCS                                  % fluctuations from pulse to pulse)

%*******************************************************************
% GENERATE DATA
%*******************************************************************
% Generation of pulses: Orthogonal waveforms S (MtxL) such that (1/L)*S*S' is identity matrix
S=(1/sqrt(2))*(hadamard(L)+j*hadamard(L));
S=S(1:prod(Mt),:);

M = [Mr,Mt];
R = length(M);              % number of modes
M_total = prod([M,Q]);

[dim1,I1] = sort([M,Q],2,'descend');
if dim1(1)>M_total/dim1(1)
    dim1(1) = M_total/dim1(1);
end

ndim = 2^R-1;
dim2 = zeros(ndim,1);
for r=1:ndim
    bin = dec2binxarray( r, R+1 );
    dim_index = find(bin==1);
    M_rows = prod(M(dim_index));
    dim2(r) = min(M_rows,M_total/M_rows);
end
[dim2,I2] = sort(dim2,1,'descend');

for r=1:ndim
    bin = dec2binxarray( I2(r), R+1 );
    dim_index = find(bin==1);
    if prod(M(dim_index))~=dim2(r)
        I2(r) = 2^(R+1)-1-I2(r);
    end
end
beta = 2;   % beta=1 for real valued observations. Change to beta=2 for complex valued data and noise.
alpha_KN1 = 1e-2;%5/(dim2(1)^2*K^2; % confidence level for the algorithm by KN.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
snr_vec = -20:5:100;  %150;         % SNR range2.
SNR_length = length(snr_vec);
NAvg = 1*10^0;                 % number of realizations

rho = 0.675+[0.125,0.125,0.125]; %[0.95,0.75,0.80];%
rho = [rho,zeros(1,R+1-length(rho))];
noise_corr_1 = rho.*ones(1,R+1);
% Draw correlation factor for
[L_corr] = calc_l(noise_corr_1,[M,Q]);

d_ester_1 = zeros(SNR_length,NAvg);
d_ester_2 = zeros(SNR_length,NAvg);
d_ester_3 = zeros(SNR_length,NAvg);

d_rd_ester_inc = zeros(SNR_length,NAvg);
d_rd_ester_II = zeros(SNR_length,NAvg);
d_rd_ester_prod = zeros(SNR_length,NAvg);
d_rd_ester_prod_1 = zeros(SNR_length,NAvg);

d_rd_MDL = zeros(SNR_length,NAvg);
d_rd_AIC = zeros(SNR_length,NAvg);
d_rd_RMT = zeros(SNR_length,NAvg);

% Loop for NAvg independent realizations
for nRun = 1:NAvg
    
    Ang_Tx(:,1)=(rand(K,1)-0.5)*360;%[-80,-40,0];     % AOD in degree for each target
    Ang_Rx(:,1)=(rand(K,1)-0.5)*360;%[ 70,50,-10];    % AOA in degree for each target

    % Transmit and receive steering matrix
    A=zeros(prod(Mt),K);
    B=zeros(prod(Mr),K);
    for k=1:K
        A(:,k)=steering_ULA(Ang_Tx(k,:),Mt,fc,dt);  % transmit steering matrix
        B(:,k)=steering_ULA(Ang_Rx(k,:),Mr,fc,dr);  % receive steering matrix
    end
    
    Speed_mat= rand(K,1)*Lambda/(2*Tp)/10.0;%[300 250 400].';  % Speed of targets in meters per second, typical requirement fD*T<<1
    % (fD=2*v/Lambda is the Doppler
    % shift and T is the pulse period)
    % Target reflection coefficients in C (QxK)
    C=zeros(Q,K);
    for k=1:K
        C(:,k)=sqrt(Var_mat(k))*(randn(Q,1)+j*randn(Q,1));
    end
    
    % Vandermonde matrix with Doppler shifts
    Cdop=zeros(Q,K);
    q=0:Q-1;
    for k=1:K
        Cdop(:,k)=exp(j*2*pi*q*2*Speed_mat(k)*Tp/Lambda);
    end
    
    % Generate noise-free observed tensor of size Mr*L*Q
    X_rec=zeros(prod(Mr),L,Q);
    if strcmp(tarmod,'S1')==1   % RCS coefficients do not vary from pulse to pulse
        for q=1:Q
            X_rec(:,:,q)=B*diag(C(1,:))*diag(Cdop(q,:))*A.'*S;  % take the first row of C only
        end
        
    elseif strcmp(tarmod,'S2')==1  % RCS coefficients vary from pulse to pulse
        for q=1:Q
            X_rec(:,:,q)=B*diag(C(q,:))*diag(Cdop(q,:))*A.'*S;
        end
    end
    
    % Matched filtering by (1/L)S', and get the MrxMtxQ matched filtered tensor
    X0=zeros(prod(Mr),prod(Mt),Q);
    for q=1:Q
        X0(:,:,q)=(1/L)*X_rec(:,:,q)*S';
    end
    
    sigma_s = norm(X0(:),'fro')^2/(M_total);
    X = reshape(X0,[M,Q]);
    
    %% Loop for SNRs
    for SNRrun = 1:SNR_length
        % Add colored noise to noise-free measurement matrix/tensor
        Y_rec = addnoise_colored(X,snr_vec(SNRrun),sigma_s,L_corr);
        
        %% Algorithms: RD ESTER, RD ESTER Addition, RD ESTER Product
        %
        d_ester_1(SNRrun,nRun) = EstEr(unfolding(Y_rec,1),M(1),prod(M)*Q/M(1));
        d_ester_2(SNRrun,nRun) = EstEr(unfolding(Y_rec,2),M(2),prod(M)*Q/M(2));
        d_ester_3(SNRrun,nRun) = EstEr(unfolding(Y_rec,3),Q,prod(M));
        
        d_rd_ester_inc(SNRrun,nRun) = ITW_EstEr(Y_rec,[M,Q],R);
        d_rd_ester_prod(SNRrun,nRun) = RD_EstEr_prod(Y_rec,[M,Q],R);
        d_rd_ester_prod_1(SNRrun,nRun) = RD_EstEr_prod(Y_rec,[M,Q],R+1);
        d_rd_ester_II(SNRrun,nRun) = RD_EstErII(Y_rec,[M,Q],R);
        
        E1 = cell(1,R+1);
        for r=1:R+1
            E1{r} = sort(real(eig(dim1(r)/M_total*(unfolding(Y_rec, I1(r))*unfolding(Y_rec, I1(r))'))),'descend');
        end
        
        n = dim1(1); p = dim1(1); lambda = E1{1};
        d_hat_MDL = rank_est_WK(lambda,p,n);
        d_hat_AIC = rank_est_AIC(lambda,p,n);
        for r=2:R+1
            if d_hat_MDL<dim1(r) || d_hat_AIC<dim1(r)
                lambda = lambda(1:dim1(r)).*E1{r};
                
                if d_hat_MDL<dim1(r)
                    d_hat_MDL = rank_est_WK(lambda,dim1(r),n);
                end
                
                if d_hat_AIC<dim1(r)
                    d_hat_AIC = rank_est_AIC(lambda,dim1(r),n);
                end
                
            else
                break;
            end
        end
        d_rd_MDL(SNRrun,nRun) = d_hat_MDL;
        d_rd_AIC(SNRrun,nRun) = d_hat_AIC;
        
        dim_index = find(dec2binxarray( I2(1), R+1 )==1);
        E2 = dim2(r)/M_total*svd(double(tenmat(Y_rec, dim_index))).^2;
        p = dim2(1);n = M_total/dim2(1);
        [d_rd_RMT(SNRrun,nRun),sigma_hat1(SNRrun,nRun)] = KN_rankEst(E2,n,beta,alpha_KN1);
    end
    
    if mod(nRun,10)==0
        fprintf('%d / %d: done (%g s).\n',nRun,NAvg,toc);
    end
    %
end

prob_ester_1 = mean(d_ester_1==K,2);
prob_ester_2 = mean(d_ester_2==K,2);
prob_ester_3 = mean(d_ester_3==K,2);

prob_rd_ester_inc = mean(d_rd_ester_inc==K,2);
prob_rd_ester_prod = mean(d_rd_ester_prod==K,2);
prob_rd_ester_prod_1 = mean(d_rd_ester_prod_1==K,2);
prob_rd_ester_II = mean(d_rd_ester_II==K,2);

prob_rd_MDL = mean(d_rd_MDL==K,2);
prob_rd_AIC = mean(d_rd_AIC==K,2);
prob_rd_RMT = mean(d_rd_RMT==K,2);

filename = ['matfile/MIMO radar/SwerlingI/R=' num2str(R), ', M=' array2string(M),', Q=' num2str(Q),', K=', num2str(K),', rho=', array2string(rho),', NAvg=', num2str(NAvg),'.mat'];
save(filename);

%% Plots
figure(1);
clf
ColorOrder=get(gcf,'DefaultAxesColorOrder');
NewColorOrder = ColorOrder([1:6,1:2,7,3],:);
set(gcf,'DefaultAxesColorOrder',NewColorOrder);
plot(snr_vec,prob_rd_MDL,'--+','LineWidth',1.25, 'MarkerSize',6);
hold all;
plot(snr_vec,prob_rd_AIC,'-.v','LineWidth',1.5, 'MarkerSize',6.5);
hold all;
plot(snr_vec,prob_rd_RMT,':^','LineWidth',1.25, 'MarkerSize',6);
hold all;
plot(snr_vec,prob_ester_1,'-d','LineWidth',1.25, 'MarkerSize',6);
hold all;
plot(snr_vec,prob_ester_2,'--p','LineWidth',1.25, 'MarkerSize',6);
hold all;
plot(snr_vec,prob_ester_3,'-.x','LineWidth',1.25, 'MarkerSize',6);
hold all;
plot(snr_vec,prob_rd_ester_inc,':*','LineWidth',1.25, 'MarkerSize',6);
hold all;
plot(snr_vec,prob_rd_ester_prod,'-s','LineWidth',1.25, 'MarkerSize',6);
hold all;
plot(snr_vec,prob_rd_ester_prod_1,'--s','LineWidth',1.25, 'MarkerSize',6);
hold all;
plot(snr_vec,prob_rd_ester_II,'-.o','LineWidth',1.25, 'MarkerSize',6);
hold off;
legend('R-D MDL','R-D AIC', 'R-D RMT', 'ESTER 1', 'ESTER 2', 'ESTER 3', 'Original R-D ESTER', 'Proposed R-D ESTER I (R)', 'Proposed R-D ESTER I (R+1)', 'Proposed R-D ESTER II');
xlabel('SNR [dB]');
ylabel('Pr ($\hat{d} = d$)','interpreter','Latex');
title(['Swerling I: R=' num2str(R), ', M=' array2string(M),', Q=' num2str(Q),', K=', num2str(K),', \rho=', array2string(rho),', NAvg=', num2str(NAvg)]);
axis([min(snr_vec) max(snr_vec) 0 1]); grid on;

set(gcf, 'DefaultAxesColorOrder', 'remove');