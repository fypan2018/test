function[N_C] = kronecker_structure(N_W,L,modus)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This function computes a Kronecker structure
% as follows:
%
% N_C = N_W x_1 L_1 x_2 L_2 ... x_R L_R
%
% where x_i is the i-mode product and
% L_1, L_2, ..., L_R are the matrices of the
% cell array L.
%
% For generating colored Kronecker noise,
% N_W is a white noise tensor.
%
% Modus 1 can be used for prewhitening.
%
% (c) Stefanie Schwarz 2011
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[temp, R] = size(L);

if nargin < 3
    modus='normal';
end

switch (modus)
    case 'normal'
        for ii = 1:R
            if (ii == 1)
                N_C = nmode_product(N_W,L{ii},ii);
            else
                N_C = nmode_product(N_C,L{ii},ii);  
            end
        end
    
    case 'inv'
         for ii = 1:R
            if (ii == 1)
                N_C = nmode_product(N_W,pinv(L{ii}),ii); % modified by Kefei Liu inv->pinv
            else
                N_C = nmode_product(N_C,pinv(L{ii}),ii);  
            end
         end
end
    