function I = supereye(R,d)

% SUPEREYE   Computes the identity tensor of order R and size d.
%
% |----------------------------------------------------------------
% | (C) 2007 TU Ilmenau, Communications Research Laboratory
% |
% |     Florian Roemer
% |     
% |     Advisors:
% |        Dipl.-Ing. Giovanni Del Galdo
% |        Univ. Prof. Dr.-Ing. Martin Haardt
% |
% |     Last modifications: 12/17/2007
% |----------------------------------------------------------------
%
% Syntax:
%    I = SUEPREYE(R,d)
% 
% Input:
%    R - order of the identity tensor (R-dimensional).
%    d - size of the identity tensor (SIZE(I)=[d,d,...,d].
%
% Output:
%    I - identity tensor of size d*ones(1,R) having ones on its
%    hyperdiagonal and zeros elsewhere.

I = zeros(d*ones(1,R));

%%% Slow but safe
% for nd = 1:d
%     ed = [zeros(1,nd-1), 1, zeros(1,d-nd)].';
%     rankoneterm = ed;
%     for r = 1+1:R
%         rankoneterm = outer_product({rankoneterm,ed});
%     end
%     I = I + rankoneterm;
% end

%%% Fast but weird
for nd = 1:d
    I = subsasgn(I,struct('type','()','subs',{mat2cell(nd*ones(1,R),1,ones(1,R))}),1);
end