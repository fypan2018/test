function CRB = calc_crb(mu, M, SNR, N, type, Rss, LPR)

% CALC_CRB   Calculate stochastic or deterministic CRB of a hypercuboidal array.
%
% SYNTAX
%  CRB = CALC_CRB(mu, M, SNR, N [, type[, Rss[, LPR]]])
%
% INPUT
%    mu:   R x d matrix of spatial frequencies. \mu_i^{(r)} -> mu(r,i)
%    M :   length R vector of array size in all R modes.
%    SNR:  signal to noise ratio in dB.
%    N :   total number of snapshots
%    type: 'stoch' for stochastic CRB, 'det' for deterministic CRB.
%          This parameter is optional, it defaults to 'stoch'
%    Rss:  d x d matrix: In case of a stochastic CRB it is the signal
%          covariance matrix (E{s(t)*s(t)'}), for the deterministic CRB it
%          is the sample covariance matrix (1/N*S*S'). This parameter is
%          optional, it defaults to EYE(d).
%    LPR:  Optional: Control choice of phase center for A.
%              LPR = 0: phase center for A chosen at first element [default]
%              LPR = 1: phase center for A chosen in the middle, A is left-Pi-real.
%
%
% OUTPUT
%    The output is the CRB covariance matrix of size d*R x d*R.
%
%    To obtain a total RMSE, use SQRT(TRACE(CRB)).


%%% Check input parameters
[R,d] = size(mu);
if length(M) ~= R
    error('Invalid parameters. Length of M should match #rows in mu.');
end

if nargin < 5
    type = 'stoch';
end
if nargin < 6
    Rss = eye(d);
end
if nargin < 7
    LPR = 0;
end

if ~strcmp(type,'stoch') && ~strcmp(type,'det')
    error('Unknown type.');
end

if (size(Rss,1) ~= d) || (size(Rss,2) ~= d)
    error('Invalid parameters. Size of Rss should be d x d.');
end

%%% Compute noise power and total number of sensors
PN = 10^(-SNR/10)*trace(Rss)/(R*d);
Mtotal = prod(M);

%%% Compute array steering matrices and partial derivatives
[A,D] = array_matr_Rd(mu,M, LPR);


%%% Compute array part of CRB
Pi_A_perp = eye(Mtotal) - A*inv(A'*A)*A';
ArrayPart = D' * Pi_A_perp * D;

%%% Compute covariance part of CRB, depending on type.
switch type
    case 'stoch'
        Rxx = A*Rss*A' + PN*eye(Mtotal);
        %Rxx = A*Rss*A' + 2*PN*eye(Mtotal);
        CovPart = Rss * A' * inv(Rxx) * A * Rss;
    case 'det'
        CovPart = Rss; % actually this is Rsshat
end
%CovPart_big = kron(eye(R), CovPart);
CovPart_big = kron(ones(R), CovPart);

%%% Combine both parts to the final CRB
CRB = PN / 2 / N * inv(real( ArrayPart .* (CovPart_big.') ));
%CRB = PN / N * inv(real( ArrayPart .* (CovPart_big.') ));