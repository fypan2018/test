%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Demonstration for spectral estimation from time series using ESPRIT
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Author: Florian Roemer, CRL, TU Ilmenau, Nov 2010
%         florian.roemer@tu-ilmenau.de
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This demo generates a signal with NS spanshots containing a linear
% mixture of harmonics with randomly generated frequencies and different
% power levels. White Gaussian noise is added as well. Afterwards, the
% dominant frequencies are estimated via ESPRIT. Also, the model order is
% estimated using the EDC test.
%
% At the end, the relative mean square estimation error of the frequencies
% is displayed as a function of the number of snapshots NS. Also, the
% number of estimated frequencies is displayed vs NS.
%
% We observe that for low NS, fewer harmonics are estimated, for high NS,
% all frequencies can be resolved.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear; clc; close all
tic;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Step 1: Setup signal parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% true number of harmonics (unknown at the observer)
M = 10; N = 20; d = 2;

UnequalPowerFlag = 0; CloseSpacedFlag = 1;

if UnequalPowerFlag == 1
    % signal powers for the different harmonics
    sigma_s = [1e3 1]/1000;%
    %sigma_s = 1.0*randn(1,d).^2;%
else
    sigma_s = 0.001*ones(1,d);%SNR = -10;
end
mean_power = mean(sigma_s);

sigma_n = 1.0;
SNR = 10*log10(mean_power/sigma_n);

theta_in_deg = [0 5];
theta = theta_in_deg/360*2*pi;
mu = pi*sin(theta);
A =  exp(1j*(0:M-1)'*pi*sin(theta)); % /sqrt(M)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Step 2: Spectral estimation for different values of NS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
NRuns = 1e4;

% pre-allocate MSEs for later display
muhat_under = zeros(1,NRuns);
muhat_correct_src = zeros(2,NRuns);
muhat_correct_sorted = zeros(2,NRuns);

seed = 10000; randn('state',seed); % for reproducibility. Change the seed for new results

for run = 1:NRuns
    
    s = sqrt(diag(sigma_s/2))*(randn(d,N) + 1j*randn(d,N));
    X0 = A*s;
    
    Z = sqrt(sigma_n/2)*(randn(M,N) + 1i*randn(M,N));
    X = X0+Z;
    
    [U,S,V] = svd(X);
    
    muhat_orig = angle(eig(pinv(U(1:M-1,1:d))*U(2:M,1:d)))';
    [mu_used_orig,muhat_used_orig] = Rd_mypairing(mu,muhat_orig);
    
    muhat_correct_sorted(:,run) = muhat_orig(muhat_used_orig);
    
    [~,muhat_used_orig_index] = sort(mu_used_orig);
    muhat_used_orig_src = muhat_used_orig(muhat_used_orig_index);
    muhat_correct_src(:,run) = muhat_orig(muhat_used_orig_src);
    
    muhat_under(run) = angle(eig(pinv(U(1:M-1,1:d-1))*U(2:M,1:d-1)))';
    
    if mod(run,100)==0
        fprintf('%d / %d: done (%g s).\n',run,NRuns,toc);
    end
end

toc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Step 3: Display the results
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
mu_vec = (-180:1:180)/360*2*pi;

figure(1);
clf; %axes('fontsize',15);
hist(muhat_under,mu_vec);
h = findobj(gca,'Type','patch');
set(h,'FaceColor','r','EdgeColor','w');
xlabel('$\hat{\mu}$','interpreter','latex','fontsize',18);
ylabel('Number of estimates');
title(['M=', num2str(M),', N_s=',num2str(N),', d=', num2str(d),', \theta=', array2string(theta_in_deg),'^0, SNR=', num2str(SNR),'dB']);
grid on; axis tight;

figure(2);
clf; %axes('fontsize',15);
subplot(2,1,1),
hist(muhat_correct_src(1,:),mu_vec);
h = findobj(gca,'Type','patch');
set(h,'FaceColor','r','EdgeColor','w');
xlabel('$\hat{\mu}_1$','interpreter','latex','fontsize',18);
ylabel('Number of estimates');
legend('Source 1 DOA estimate');
title(['Histogram of 1st DOA estimate',' @ d=$\hat{d}$=', num2str(d),', $\theta$=', array2string(theta_in_deg),'$^0$, SNR=', num2str(SNR),'dB'],'interpreter','latex');
grid on; axis tight;

subplot(2,1,2),
hist(muhat_correct_src(2,:),mu_vec);
h = findobj(gca,'Type','patch');
set(h,'FaceColor','b','EdgeColor','w');
xlabel('$\hat{\mu}_2$','interpreter','latex','fontsize',18);
ylabel('Number of estimates');
legend('Source 2 DOA estimate');
title(['Histogram of 2nd DOA estimate',' @ d=$\hat{d}$=', num2str(d),', $\theta$=', array2string(theta_in_deg),'$^0$, SNR=', num2str(SNR),'dB'],'interpreter','latex');
grid on; axis tight;

mHist2d = hist2D(muhat_correct_src(2:-1:1,:)',mu_vec,mu_vec);

figure(5);
clf; %axes('fontsize',15);
[vX,vY] = meshgrid(mu_vec,mu_vec);
meshz(vX,vY,mHist2d);
% pcolor (mu_vec, mu_vec, mHist2d);
% shading interp; colorbar; 
xlabel('$\hat{\mu}_1$','interpreter','latex','fontsize',18);
ylabel('$\hat{\mu}_2$','interpreter','latex','fontsize',18);
zlabel('Number of estimates');
title(['M=', num2str(M),', N_s=',num2str(N),', d=dhat=', num2str(d),', $\theta$=', array2string(theta_in_deg),'^0, SNR=', num2str(SNR),'dB']);
grid on; axis tight;

figure(d+1+3);
clf; %axes('fontsize',15);
subplot(d,1,1),
hist(muhat_correct_sorted(1,:),mu_vec);
h = findobj(gca,'Type','patch');
set(h,'FaceColor','r','EdgeColor','w');
xlabel('$\hat{\mu}_{i_1}$','interpreter','latex','fontsize',18);
ylabel('Number of estimates');
legend('Accurate estimate');
title(['Histogram of $\hat{\mu}_{i_1}$ @ d=$\hat{d}$=', num2str(d),', $\theta$=', array2string(theta_in_deg),'$^0$, SNR=', num2str(SNR),'dB'],'interpreter','latex');
grid on; axis tight;

subplot(d,1,2),
hist(muhat_correct_sorted(2,:),mu_vec);
h = findobj(gca,'Type','patch');
set(h,'FaceColor','r','EdgeColor','w');
xlabel('$\hat{\mu}_{i_2}$','interpreter','latex','fontsize',18);
ylabel('Number of estimates');
legend('Inaccurate estimate');
title(['Histogram of $\hat{\mu}_{i_2} @ d=$\hat{d}$=', num2str(d),', $\theta$=', array2string(theta_in_deg),'$^0$, SNR=', num2str(SNR),'dB'],'interpreter','latex');
grid on; axis tight;

figure(d+1+4);
clf; %axes('fontsize',15); 
muhat = [];
subplot(d+1,1,1),
hist(muhat_correct_sorted(1,:),mu_vec);
muhat = [muhat muhat_correct_sorted(1,:)];
h = findobj(gca,'Type','patch');
set(h,'FaceColor','r','EdgeColor','w');
xlabel('$\hat{\mu}_{i_1}$','interpreter','latex','fontsize',18);
ylabel('Number of estimates');
legend('Accurate estimate');
title(['Histogram of $\hat{\mu}_{i_1}$ @ d=$\hat{d}$=', num2str(d),', $\theta$=', array2string(theta_in_deg),'$^0$, SNR=', num2str(SNR),'dB'],'interpreter','latex');
grid on; axis tight;

subplot(d+1,1,2),
hist(muhat_correct_sorted(2,:),mu_vec);
muhat = [muhat muhat_correct_sorted(2,:)];
h = findobj(gca,'Type','patch');
set(h,'FaceColor','r','EdgeColor','w');
xlabel('$\hat{\mu}_{i_2}$','interpreter','latex','fontsize',18);
ylabel('Number of estimates');
legend('Inaccurate estimate');
title(['Histogram of $\hat{\mu}_{i_2}$ @ d=$\hat{d}$=', num2str(d),', $\theta$=', array2string(theta_in_deg),'$^0$, SNR=', num2str(SNR),'dB'],'interpreter','latex');
grid on; axis tight;

subplot(d+1,1,d+1),
hist(muhat,mu_vec);
h = findobj(gca,'Type','patch');
set(h,'FaceColor','r','EdgeColor','w');
xlabel('$\hat{\mu}_{i_k},k=1,2$','interpreter','latex','fontsize',18);
ylabel('Number of estimates');
legend('Union');
title(['Histogram of $\hat{\mu}_{i_k}$ @ d=$\hat{d}$=', num2str(d),', $\theta$=', array2string(theta_in_deg),'$^0$, SNR=', num2str(SNR),'dB'],'interpreter','latex');
grid on; axis tight;