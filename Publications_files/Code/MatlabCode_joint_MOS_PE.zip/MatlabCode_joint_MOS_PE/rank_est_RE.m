function K = rank_est_RE(lambda,n,m, beta)
% function K = rank_est_RR(lambda,m,n)
% RR estimator for number of signals proposed by
% Wax & Kailath in 
% "Detection of signals by information theoretic criteria", IEEE
% Transactions on Acoustics, Speech and Signal Processing 33 (2) (1985)
% 387�392.
if nargin<4
    beta = 2;
end

t   = zeros(min(n,m),1); 
RR = zeros(min(n,m),1); 

for k=0:min(n,m)-1
    t(k+1) = ((n-k)*sum(lambda(k+1:n).^2)/sum(lambda(k+1:n))^2-(1+n/m))*n-(2/beta-1)*n/m;
    RR(k+1) = beta/4*(m/n)^2*t(k+1)^2 + 2*(k+1); 
end

[~, loc] = min(RR); 

K = loc-1;

return; 
