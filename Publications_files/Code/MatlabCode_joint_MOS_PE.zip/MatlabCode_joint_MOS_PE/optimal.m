function [ k, delta ] = optimal( N, alpha )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
C = norminv(1-alpha);
k = round(4*(2*(N-1)^2/C^2)^(1/5));
delta = 5/k - 4/k^2;

end

