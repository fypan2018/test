function [local_coeff,prob_found] = calc_coef_paper(M,N,Pfa,coeff_unit,q)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Program to generate the coefficients for the EFT method %
% Joao Paulo C. L. da Costa                               %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
max_eig_numb = min([M N]);
% Calculating J_final vector since it depends only on M and N
for pp = 1:(max_eig_numb-1)
    pp_aux = pp + 1;
    a_mi_ff = 225/((pp_aux^2+2)^2);
    a_mi_fs = 180*pp_aux / ( N * (pp_aux^2 - 1) * (pp_aux^2 +2) );
    a_mi = (a_mi_ff - a_mi_fs)^0.5;
    a_ex_fr = 15/(pp_aux^2 + 2);
    a_diff = a_ex_fr - a_mi;
    a_final(pp_aux) = (0.5*a_diff)^0.5;
    r_final(pp_aux) = exp(-2*a_final(pp_aux));
    J_final(pp_aux) = ( 1 - r_final(pp_aux) ) / ( 1 - (r_final(pp_aux)^pp_aux) );

    coeff_max = 1.0/J_final(pp_aux)-1.0; 
    if pp==1
        coeff_min = coeff_max*31/32;
        coeff{pp} = coeff_initialize(coeff_max,coeff_unit,coeff_min);
    else
        coeff{pp} = coeff_initialize(coeff_max,coeff_unit);
    end
end
barra = waitbar(0,'Please wait... Calculating thresholds for EFT');
for ii = 1:q
    noise = randn(M,N);
    noise_eig = (svd(noise).^2)/N;
    noise_eig = sort(noise_eig,'descend');
    for pp = 1:(max_eig_numb-1)
        pp_aux = pp + 1;
        sum_eig = sum(noise_eig((max_eig_numb-pp):max_eig_numb));
        comp_q = noise_eig(max_eig_numb-pp)/sum_eig;
        comp_q_tot = comp_q/J_final(pp_aux) - 1;
        %histogram(ii,pp) = comp_q/J_final(pp_aux);
        prob_q{pp} = coeff{pp} < comp_q_tot;
        if (ii == 1)
            prob_fim{pp} = 1.0*prob_q{pp};
        else
            prob_fim{pp} = (prob_fim{pp}+1.0*prob_q{pp});
        end
    end
    waitbar(ii/q,barra);      
end
close(barra);
for pp = 1:(max_eig_numb-1)
    [~,local_Pfa(pp)] = min(abs(prob_fim{pp} - q*Pfa));
    local_coeff(pp) = coeff{pp}(local_Pfa(pp));
    prob_found(pp) = prob_fim{pp}(local_Pfa(pp))/q;
%     if (local_Pfa(pp) == 1)
%         prob_found(pp) = 0;
%     else
%         prob_found(pp) = prob_fim(pp,local_Pfa(pp)-1);
%     end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%