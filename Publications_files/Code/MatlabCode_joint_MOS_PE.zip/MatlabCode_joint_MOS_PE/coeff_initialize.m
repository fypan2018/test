function coeff_range = coeff_initialize(coeff_max,unit,coeff_min)

if nargin==3
    coeff_range = [0:0.1*unit:coeff_min coeff_min+0.01*unit:0.01*unit:coeff_max+0.01*unit];
    return;
end

deci = 0:0.1*unit:0.1;
deci_to_one = 0.1+unit:unit:1.0;
one_to_ten = 1.0+10*unit:10*unit:10.0;
ten_to_hun = 10.0+100*unit:100*unit:100.0;

if coeff_max<=0.1
    coeff_range = 0:0.1*unit:coeff_max;
    
elseif coeff_max>0.1 && coeff_max<=1.0
    coeff_range = [deci,0.1:unit:coeff_max];
    
elseif coeff_max>1.0 && coeff_max<=10.0
    coeff_range = [deci,deci_to_one,1.0+10*unit:10*unit:coeff_max];
    
elseif coeff_max>10.0 && coeff_max<=100.0
    coeff_range = [deci,deci_to_one,one_to_ten,10.0+100*unit:100*unit:coeff_max];
    
else
    coeff_range = [deci,deci_to_one,one_to_ten,ten_to_hun,100.0+1e3*unit:1e3*unit:coeff_max];
end

end