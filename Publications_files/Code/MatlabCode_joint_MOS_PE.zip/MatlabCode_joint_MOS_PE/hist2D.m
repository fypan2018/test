%function mHist = hist2d ([vY, vX], vYCenter, vXCenter)
%2 Dimensional Histogram
%Counts number of points in the bins defined by vYCenter, vXCenter.
%size(vX) == size(vY) == [n,1]
%size(mHist) == [length(vYCenter) -1, length(vXCenter) -1]
%
%EXAMPLE
%   mYX = rand(100,2);
%   vXCenter = linspace(0,1,10);
%   vYCenter = linspace(0,1,20);
%   mHist2d = hist2d(mYX,vYCenter,vXCenter);
%
%   nXBins = length(vXCenter);
%   nYBins = length(vYCenter);
%   vXLabel = 0.5*(vXCenter(1:(nXBins-1))+vXCenter(2:nXBins));
%   vYLabel = 0.5*(vYCenter(1:(nYBins-1))+vYCenter(2:nYBins));
%   pcolor(vXLabel, vYLabel,mHist2d); colorbar
function mHist = hist2D(mX, vYCenter, vXCenter)
nCol = size(mX, 2);
if nCol < 2
    error ('mX has less than two columns')
end

nRow = length (vYCenter);
nCol = length (vXCenter);

vRow = mX(:,1);
vCol = mX(:,2);

mHist = zeros(nRow,nCol);

for iRow = 1:nRow
    if iRow==1
        rRowLB = -inf;
    else
        rRowLB = (vYCenter(iRow-1)+vYCenter(iRow))/2.0;
    end
    
    if iRow==nRow
        rRowUB = inf;
    else
        rRowUB = (vYCenter(iRow)+vYCenter(iRow+1))/2.0;
    end
    
    vColFound = vCol((vRow > rRowLB) & (vRow <= rRowUB));
    
    if (~isempty(vColFound))
        
        
        vFound = hist (vColFound, vXCenter);
        
        nFound = (length(vFound));
        
        if (nFound ~= nCol)
            disp([nFound nCol])
            error ('hist2d error: Size Error')
        end
        
        [nRowFound, nColFound] = size (vFound);
        
        if nRowFound == nCol
            mHist(iRow, :)= vFound(1:nFound)';
        elseif nColFound == nCol
            mHist(iRow, :)= vFound(1:nFound);
        else
            error ('hist2d error: Size Error')
        end
    end
    
end


