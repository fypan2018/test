%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Demonstration for spectral estimation from time series using ESPRIT
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear; clc; close all
tic;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Step 1: Setup signal parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% true number of harmonics (unknown at the observer)
M = 10; N = 100; d = 5;

UnequalPowerFlag = 1; CloseSpacedFlag = 0;

if UnequalPowerFlag == 1
    % signal powers for the different harmonics
    str1 = 'UnequalPowered\';
else
    str1 = 'EqualPowered\';
end

if CloseSpacedFlag==1
    str2 = 'CloseSpaced\';
else
    str2 = 'WideSpaced\';
end

rand('state',sum(100.*clock));

if UnequalPowerFlag == 1
    % signal powers for the different harmonics
    %sigma_s = [1e3 1];%/1000;%
    sigma_s = 1.0*randn(1,d).^2;%
    sigma_s_sorted = sort(sigma_s);
    ratio = sigma_s_sorted(2:end)./sigma_s_sorted(1:end-1);
    while min(ratio)<1.5
        sigma_s = 1.0*randn(1,d).^2;%
        sigma_s_sorted = sort(sigma_s);
        ratio = sigma_s_sorted(2:end)./sigma_s_sorted(1:end-1);
    end
else
    sigma_s = 1.0*ones(1,d);%SNR = -10;
end
mean_power = mean(sigma_s);

sigma_n = 1.0;
SNR = 10*log10(mean_power/sigma_n);

if CloseSpacedFlag==1
    % minimum frequency spacing of two harmonics that is allowed for the randomly generated frequencies
    mindelf = 5;
    theta_in_deg = fix(180*(rand(1,d)-0.5));
    while min(diff(sort(theta_in_deg)))>mindelf % assure minimum spacing
        theta_in_deg = fix(180*(rand(1,d)-0.5));
    end
else
    theta_in_deg1 = 180*(round(linspace(1,M+1,d+1))-0.5)/M-90;
    theta_in_deg = theta_in_deg1(1:end-1);
end

theta = theta_in_deg/360*2*pi;
mu = pi*sin(theta);
A =  exp(1j*(0:M-1)'*pi*sin(theta)); % /sqrt(M)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Step 2: RMT and EFT
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% for RMT
alpha = 0.01; % condicience level for RMT criterion
beta = 2; %: indication of real-valued or complex-valued, real-valued: beta=1; complex-valued: beta=2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Find coefficients eta_p
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This is done via Monte-Carlo trials with only noise
% Can be done offline since the coefficients are only a function of M, N
% and the Target PFA (probability of false alarm).
% It is recommended to do this once for a configuration of M and N and then
% to store the cofficients and load them for each simulation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% for EFT, computation of the threshold
Pfa = 0.01; % Probability of false alarm rate
coeff_unit = 1e-3;

filename = ['1-D EFT threshold\eta_p (M=', num2str(M),', Ns=',num2str(N),', Pfa=', num2str(Pfa),...
    ', unit=', num2str(coeff_unit),').mat'];
if exist(filename,'file')==2
    load(filename);
    
elseif exist(filename,'file')==0
    fprintf('Obtaining threshold coefficients...');
    
    % Number of Monte-Carlo trials to find eta_p
    I = Pfa/(min(M,N)-1); % Probability of false alarm rate for each assumed number of signals
    esti_accuracy_of_I = 0.1;
    confidence_level = 0.95;
    upperband = norminv(0.5+confidence_level/2.0);
    q = ceil((upperband/esti_accuracy_of_I)^2/I); % number of Monte Carlo runs for threshold determination
    
    [local_coeff_eft,prob_found_eft] = calc_coef_paper(M,N,I,coeff_unit,q);
    
    fprintf(' done (%g s).\n',toc);
    save(filename,'local_coeff_eft','prob_found_eft');
else
    display('Error!')
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Step 3: Computation of rmse of the estimates and model order selection
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
seed = 10000; randn('state',seed); % for reproducibility. Change the seed for new results

SNR_vec = -20:2.5:100;%0.5
SNR_length = length(SNR_vec);
NTrials = 1e1;

crb_correct = zeros(SNR_length,NTrials);
crb_se_vector = zeros(SNR_length,d,NTrials);
se_all = zeros(SNR_length,d,NTrials);
mu_all = zeros(SNR_length,d,NTrials);
muhat_all = zeros(SNR_length,d,NTrials);

dhat_samos = zeros(SNR_length,NTrials);
dhat_ester = zeros(SNR_length,NTrials);
dhat_ester_combt = zeros(SNR_length,NTrials);
dhat_radoi = zeros(SNR_length,NTrials);
dhat_music = zeros(SNR_length,NTrials);
dhat_aic = zeros(SNR_length,NTrials);
dhat_mdl = zeros(SNR_length,NTrials);
dhat_edc = zeros(SNR_length,NTrials);
dhat_re = zeros(SNR_length,NTrials);
dhat_kn = zeros(SNR_length,NTrials);
dhat_sure = zeros(SNR_length,NTrials);
dhat_eft = zeros(SNR_length,NTrials);

for trial = 1:NTrials
    
    s = sqrt(diag(sigma_s/2))*(randn(d,N) + 1j*randn(d,N));
    Rss = 1/N*(s*s');
    X0 = A*s;
    
    for snr_index = 1:SNR_length
        
        sigma_n = 10^(-SNR_vec(snr_index)/10)*mean_power;
        Z = sqrt(sigma_n/2)*(randn(M,N) + 1i*randn(M,N));
        X = X0+Z;
        
        [U,S,V] = svd(X);
        
        % eigenvalues of the sample covariance matrix
        eig_vec = diag(S).^2/N;
        
        dhat_samos(snr_index,trial) = samos(X,M,N);
        % dhat_ester(snr_index,trial) = ester(X,M,N,d);
        dhat_music(snr_index,trial) = order_orth(U,M);
        dhat_radoi(snr_index,trial) = ranoi(eig_vec);%_app
        
        dhat_aic(snr_index,trial) = akaike_short2(eig_vec,size(X,2));
        dhat_mdl(snr_index,trial) = mdl_short2(eig_vec,size(X,2));
        dhat_edc(snr_index,trial) = edc_short2(eig_vec,size(X,2));
        dhat_re(snr_index,trial) = rank_est_RE(eig_vec,M,N);
        dhat_kn(snr_index,trial) = KN_rankEst(eig_vec,N, beta, alpha); % modification by liu k.f.
        dhat_sure(snr_index,trial) = sure_method(X,M,N);
        dhat_eft(snr_index,trial) = eft_short_paper(eig_vec,local_coeff_eft,M,N);
        dhat_ester(snr_index,trial) = ester(X,M,N,1,M-2);
        
        if N/M<2
            dmin = min([dhat_re(snr_index,trial),dhat_kn(snr_index,trial),dhat_eft(snr_index,trial),dhat_sure(snr_index,trial)]);
            dmax = min([dhat_re(snr_index,trial),dhat_kn(snr_index,trial),dhat_eft(snr_index,trial),dhat_sure(snr_index,trial)]);
        else
            if N/M>=2 && N/M<5
                dmin = max(dhat_edc(snr_index,trial),dhat_sure(snr_index,trial));
            elseif N/M>=5 && N/M<10
                dmin = dhat_mdl(snr_index,trial);
            else
                dmin = 1;%min([dhat_edc(snr_index,trial),dhat_radoi(snr_index,trial),dhat_music(snr_index,trial)]);
                dmax = M-2;%dhat_aic(snr_index,trial);%min([dhat_aic(snr_index,trial),dhat_music(snr_index,trial)]);
            end
            %dmax = dhat_aic(snr_index,trial);
        end
        dhat_ester_combt(snr_index,trial) = ester(X,M,N,dmin,dmax);
        
        square_error_matrix = calc_crb(mu, M, SNR_vec(snr_index), N,'det',Rss);
        crb_se_vector(snr_index,:,trial) = sort(diag(square_error_matrix));
        crb_correct(snr_index,trial) = trace(square_error_matrix)/d;
        
        for dhat = 1:d-1
            muhat = angle(eig(pinv(U(1:M-1,1:dhat))*U(2:M,1:dhat)))';
            [mu_used,muhat_used] = Rd_mypairing(mu,muhat);
            se_all(snr_index,dhat,trial) = mean(abs(muhat(muhat_used) - mu(mu_used)).^2);
        end
        
        muhat = angle(eig(pinv(U(1:M-1,1:d))*U(2:M,1:d)))';
        [mu_used,muhat_used] = Rd_mypairing(mu,muhat);
        mu_all(snr_index,:,trial) = mu(mu_used);
        muhat_all(snr_index,:,trial) = muhat(muhat_used);
        se_all(snr_index,d,trial) = mean(abs(muhat_all(snr_index,:,trial) - mu_all(snr_index,:,trial)).^2);
    end
    if mod(trial,10)==0
        fprintf('Trials: %d / %d: done (%g s).\n',trial,NTrials,toc);
    end
end

crb = sqrt(mean(crb_correct,2));
rmse_all = sqrt(mean(se_all,3));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Step 4: Identification of the effective and optimal model order
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eta = 1; rho = 0.05;

% rmse_peak = sqrt(compute_var(mu,NTrials));
rmse_peak = sqrt(compute_var2(mu,M,N,NTrials));

d_eff = zeros(SNR_length,1);
d_opt = zeros(SNR_length,1);
for snr_index = 1:SNR_length
    if rmse_all(snr_index,d) >= rmse_peak*(1.0-rho) %rmse_peak-eta/360*2*pi
        d_eff(snr_index) = 0;
        d_opt(snr_index) = 0;
    else
        snr_ni_index = snr_index;
        break;
    end
end

se_theo = zeros(SNR_length,d);
rmse_theo = zeros(SNR_length,1);
for snr_index = SNR_length:-1:1
    sigma_n = 10^(-SNR_vec(snr_index)/10)*mean_power;
    se_theo(snr_index,:) = theoretical_se_by_ESPRIT2( mu,M,N,diag(sigma_s),sigma_n )';
    rmse_theo(snr_index) = sqrt(mean(se_theo(snr_index,:)));
end
for snr_index = SNR_length:-1:1
    if rmse_all(snr_index,d)<= rmse_theo(snr_index)+eta/360*2*pi
        d_eff(snr_index) = d;
        d_opt(snr_index) = d;
    else
        snr_th_index = snr_index;
        break;
    end
end

h = zeros(SNR_length,d);
p = zeros(SNR_length,d);
statistic = zeros(SNR_length,d);
s = struct('chi2stat', 0, 'df', 0,'edges',cell(SNR_length,d),'O',cell(SNR_length,d),'E',cell(SNR_length,d));
alpha = 0.05;
[nbins, delta] = optimal(NTrials,alpha);
% nbins = NTrials/10;
edges = linspace(0,1,nbins+1);
% theta = fsolve(@(x)(sin(M/2*x)/sin(x/2))^2-M^2/2,pi/M);

rmse_best_eff = zeros(SNR_length,1);
crb_eff = zeros(SNR_length,1);

for snr_index = 1:snr_th_index
    if snr_index>=snr_ni_index && snr_index<=snr_th_index
        muhat = [];
        for k=d:-1:1
            muhat = [muhat;(squeeze(muhat_all(snr_index,k,:))+pi)/(2*pi)];
            [h(snr_index,k),p(snr_index,k),s(snr_index,k)] = chi2gof(muhat,'cdf',@unifcdf,'edges',edges,'alpha',alpha);
            statistic(snr_index,k) = s(snr_index,k).chi2stat;
        end
        
        [~,d_eff(snr_index)] = min(statistic(snr_index,:));
        d_eff(snr_index) = d_eff(snr_index)-1;
    end
    if d_eff(snr_index)==0
        rmse_best_eff(snr_index) = rmse_peak;
        crb_eff(snr_index) = rmse_peak;
    else
        rmse_best_eff(snr_index) = sqrt(mean(mean(abs(muhat_all(snr_index,1:d_eff(snr_index),:)-mu_all(snr_index,1:d_eff(snr_index),:)).^2)));
        crb_eff(snr_index) = sqrt(mean(mean(crb_se_vector(snr_index,1:d_eff(snr_index),:))));
    end
end

rmse_opt = zeros(SNR_length,1);
crb_opt = zeros(SNR_length,1);
for snr_index = snr_ni_index:SNR_length
    if snr_index>=snr_ni_index && snr_index<=snr_th_index
        [~,d_opt(snr_index)] = min(rmse_all(snr_index,:));
    end
    if d_opt(snr_index)==0
        rmse_opt(snr_index) = rmse_peak;
        crb_opt(snr_index) = rmse_peak;
    else
        rmse_opt(snr_index) = rmse_all(snr_index,d_opt(snr_index));
        crb_opt(snr_index) = sqrt(mean(mean(crb_se_vector(snr_index,1:d_opt(snr_index),:))));
    end
end

toc;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Step 5: Display the results
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
set(0,'DefaultAxesColorOrder',[0 0 1; 0 1 0; 0 1 1; 1 0 0; 1 0 1; 1 0.6 0; 0.6 0 1; .6 0.6 0; 1 0 0.6]);

figure(1);
clf;
plot(SNR_vec,d_eff,'LineStyle','-','Marker','o','Color',[0 0 1]);
hold all;
plot(SNR_vec,d_opt,'LineStyle','-.','Marker','*','Color',[1 0 0]);
hold all;
line([SNR_vec(snr_ni_index) SNR_vec(snr_ni_index)],[0 d+1],'LineStyle','-.','linewidth',2.0,'Color',[0 0 0]);
hold all;
line([SNR_vec(snr_th_index) SNR_vec(snr_th_index)],[0 d+1],'LineStyle','-.','linewidth',2.0,'Color',[0 0 0]);
text((SNR_vec(1)+SNR_vec(snr_ni_index))/2.0,d+0.5,'No information','HorizontalAlignment','center','VerticalAlignment','middle','Rotation',0,'FontSize',12,'FontWeight','bold','BackgroundColor',[.7 .9 .7]);
text((SNR_vec(snr_ni_index)+SNR_vec(snr_th_index))/2.0,d+0.5,'Threshold','HorizontalAlignment','center','VerticalAlignment','middle','Rotation',0,'FontSize',12,'FontWeight','bold','BackgroundColor',[.7 .9 .7]);
text((SNR_vec(snr_th_index)+SNR_vec(end))/2.0,d+0.5,'Asymptotic','HorizontalAlignment','center','VerticalAlignment','middle','Rotation',0,'FontSize',12,'FontWeight','bold','BackgroundColor',[.7 .9 .7]);
xlabel('SNR (dB)');
ylabel('Source number estimate'); % ylabel('d_{eff}, d_{mat}');
legend('d_{eff}','d_{mat}','Location','SouthEast');
title(['M=', num2str(M),', N=',num2str(N),', d=', num2str(d),', \sigma_s^2=',array2string(sigma_s),', \theta=',array2string(theta_in_deg),'^0, \eta=',num2str(eta),'^0, \rho=',num2str(rho)]);
grid on; axis([SNR_vec(1) SNR_vec(end) 0 d+1]); % axis tight;

figure(2);
clf;
semilogy(SNR_vec,rmse_opt,'LineStyle',':','Marker','s','linewidth',1.25);
hold all;
semilogy(SNR_vec,crb_opt,'LineStyle','-.','Marker','^','linewidth',1.25);
hold all;
semilogy(SNR_vec,rmse_best_eff,'LineStyle',':','Marker','o','linewidth',1.25);
hold all;
semilogy(SNR_vec,crb_eff,'LineStyle','--','Marker','v','linewidth',1.25);
hold all;
semilogy(SNR_vec,rmse_all(:,d),'LineStyle','-','Marker','.','linewidth',1.25);
hold all;
semilogy(SNR_vec,rmse_theo,'LineStyle','--','linewidth',2.0);
hold all;
semilogy(SNR_vec,crb,'LineStyle','-','linewidth',2.0,'Color',[0 0 0]);
hold all;
semilogy(SNR_vec,rmse_peak*ones(1,SNR_length),'LineStyle','-.','linewidth',2.0,'Color',[0 0 0]);
hold all;
semilogy([SNR_vec(snr_ni_index) SNR_vec(snr_ni_index)],[crb(end) rmse_theo(1)],'LineStyle','-.','linewidth',2.0,'Color',[0 0 0]);
hold all;
semilogy([SNR_vec(snr_th_index) SNR_vec(snr_th_index)],[crb(end) rmse_theo(1)],'LineStyle','-.','linewidth',2.0,'Color',[0 0 0]);
text((SNR_vec(1)+SNR_vec(snr_ni_index))/2.0,(rmse_peak+rmse_theo(1))/2.0,'No information','HorizontalAlignment','center','VerticalAlignment','middle','Rotation',0,'FontSize',12,'FontWeight','bold','BackgroundColor',[.7 .9 .7]);
text((SNR_vec(snr_ni_index)+SNR_vec(snr_th_index))/2.0,(rmse_peak+rmse_theo(1))/2.0,'Threshold','HorizontalAlignment','center','VerticalAlignment','middle','Rotation',0,'FontSize',12,'FontWeight','bold','BackgroundColor',[.7 .9 .7]);
text((SNR_vec(snr_th_index)+SNR_vec(end))/2.0,(rmse_peak+rmse_theo(1))/2.0,'Asymptotic','HorizontalAlignment','center','VerticalAlignment','middle','Rotation',0,'FontSize',12,'FontWeight','bold','BackgroundColor',[.7 .9 .7]);
xlabel('SNR (dB)');
hold all;
ylabel('RMSE');
legend('Matched','CRB: d_{mat}','BEST: d_{eff}','CRB: d_{eff}','Empi','Theo','CRB','Noise Only','Location','SouthWest');
title(['M=', num2str(M),', N=',num2str(N),', d=', num2str(d),', \sigma_s^2=',array2string(sigma_s),', \theta=',array2string(theta_in_deg),'^0, \eta=',num2str(eta),'^0, \rho=',num2str(rho)]);
grid on; axis tight;

figure(3);
h = semilogy(SNR_vec,rmse_all,'linewidth',2.0);
c={[0 0 1]; [0 1 0]; [0 1 1]; [1 0.5 0]; [1 0 1]};
l={'-';':';'-.';'--';'-'};
set(h, {'Color'}, c(rem((1:numel(h))-1,numel(c))+1),...
    {'LineStyle'}, l(rem((1:numel(h))-1,numel(l))+1))
hold all;
semilogy(SNR_vec,rmse_opt,'Color','r','LineStyle',':','Marker','s','linewidth',1.25);
hold all;
semilogy(SNR_vec,crb,'LineStyle','-','linewidth',2.0,'Color',[0 0 0]);
hold all;
semilogy([SNR_vec(snr_ni_index) SNR_vec(snr_ni_index)],[crb(end) rmse_theo(1)],'LineStyle','-.','linewidth',2.0,'Color',[0 0 0]);
hold all;
semilogy([SNR_vec(snr_th_index) SNR_vec(snr_th_index)],[crb(end) rmse_theo(1)],'LineStyle','-.','linewidth',2.0,'Color',[0 0 0]);
text((SNR_vec(1)+SNR_vec(snr_ni_index))/2.0,(rmse_peak+rmse_theo(1))/2.0,'No information','HorizontalAlignment','center','VerticalAlignment','middle','Rotation',0,'FontSize',12,'FontWeight','bold','BackgroundColor',[.7 .9 .7]);
text((SNR_vec(snr_ni_index)+SNR_vec(snr_th_index))/2.0,(rmse_peak+rmse_theo(1))/2.0,'Threshold','HorizontalAlignment','center','VerticalAlignment','middle','Rotation',0,'FontSize',12,'FontWeight','bold','BackgroundColor',[.7 .9 .7]);
text((SNR_vec(snr_th_index)+SNR_vec(end))/2.0,(rmse_peak+rmse_theo(1))/2.0,'Asymptotic','HorizontalAlignment','center','VerticalAlignment','middle','Rotation',0,'FontSize',12,'FontWeight','bold','BackgroundColor',[.7 .9 .7]);
xlabel('SNR (dB)');
ylabel('RMSE');
hleg = legend('$\hat{d}$=1','$\hat{d}$=2','$\hat{d}$=3','$\hat{d}$=4','$\hat{d}$=5','$d_{\mathrm{mat}}$','CRB');
set(hleg,'interpreter','latex');
title(['M=', num2str(M),', N=',num2str(N),', d=', num2str(d),', \sigma_s^2=',array2string(sigma_s),', \theta=',array2string(theta_in_deg),'^0, \eta=',num2str(eta),'^0, \rho=',num2str(rho)]);
grid on; axis tight;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Step 4: Detection Performance comparison
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

derr2_music = sqrt(mean(abs(dhat_music-repmat(d_opt,[1 NTrials])).^2,2));
derr2_samos = sqrt(mean(abs(dhat_samos-repmat(d_opt,[1 NTrials])).^2,2));
derr2_ester = sqrt(mean(abs(dhat_ester-repmat(d_opt,[1 NTrials])).^2,2));
derr2_ester_combt = sqrt(mean(abs(dhat_ester_combt-repmat(d_opt,[1 NTrials])).^2,2));
derr2_radoi = sqrt(mean(abs(dhat_radoi-repmat(d_opt,[1 NTrials])).^2,2));
derr2_aic = sqrt(mean(abs(dhat_aic-repmat(d_opt,[1 NTrials])).^2,2));
derr2_mdl = sqrt(mean(abs(dhat_mdl-repmat(d_opt,[1 NTrials])).^2,2));
derr2_edc = sqrt(mean(abs(dhat_edc-repmat(d_opt,[1 NTrials])).^2,2));
derr2_re = sqrt(mean(abs(dhat_re-repmat(d_opt,[1 NTrials])).^2,2));
derr2_kn = sqrt(mean(abs(dhat_kn-repmat(d_opt,[1 NTrials])).^2,2));
derr2_eft = sqrt(mean(abs(dhat_eft-repmat(d_opt,[1 NTrials])).^2,2));
derr2_sure = sqrt(mean(abs(dhat_sure-repmat(d_opt,[1 NTrials])).^2,2));

figure(5);
clf;
axes('fontsize',15);
plot(SNR_vec,mean(dhat_aic,2),'LineStyle','-','Marker','.','linewidth',1.25);
hold all;
plot(SNR_vec,mean(dhat_mdl,2),'LineStyle',':','Marker','*','linewidth',1.25);
hold all;
plot(SNR_vec,mean(dhat_edc,2),'LineStyle','-.','Marker','+','linewidth',1.25);
hold all;
plot(SNR_vec,mean(dhat_re,2),'LineStyle','--','Marker','x','linewidth',1.25);
hold all;
plot(SNR_vec,mean(dhat_kn,2),'LineStyle','-','Marker','d','linewidth',1.25);
hold all;
% plot(SNR_vec,mean(dhat_sure,2),'LineStyle','--','Marker','p','linewidth',1.25);
% hold all;
plot(SNR_vec,mean(dhat_eft,2),'LineStyle',':','Marker','o','linewidth',1.25);
hold all;
plot(SNR_vec,mean(dhat_samos,2),'LineStyle','-','Marker','.','linewidth',1.25);
hold all;
plot(SNR_vec,mean(dhat_radoi,2),'LineStyle','-.','Marker','x','linewidth',1.25);
hold all;
plot(SNR_vec,mean(dhat_music,2),'LineStyle','--','Marker','v','linewidth',1.25);
hold all;
plot(SNR_vec,mean(dhat_ester,2),'LineStyle','-.','Marker','s','linewidth',1.25);
hold all;
plot(SNR_vec,mean(dhat_ester_combt,2),'LineStyle','--','Marker','p','linewidth',1.25);
hold all;
plot(SNR_vec,d_opt,'LineStyle','-','linewidth',2,'Color',[0 0 0]);
hold off;
line([SNR_vec(snr_ni_index) SNR_vec(snr_ni_index)],[0 d+1],'LineStyle','-.','linewidth',2.0,'Color',[0 0 0]);
line([SNR_vec(snr_th_index) SNR_vec(snr_th_index)],[0 d+1],'LineStyle','-.','linewidth',2.0,'Color',[0 0 0]);
text((SNR_vec(1)+SNR_vec(snr_ni_index))/2.0,d+0.5,'No information','HorizontalAlignment','center','VerticalAlignment','middle','Rotation',0,'FontSize',12,'FontWeight','bold','BackgroundColor',[.7 .9 .7]);
text((SNR_vec(snr_ni_index)+SNR_vec(snr_th_index))/2.0,d+0.5,'Threshold','HorizontalAlignment','center','VerticalAlignment','middle','Rotation',0,'FontSize',12,'FontWeight','bold','BackgroundColor',[.7 .9 .7]);
text((SNR_vec(snr_th_index)+SNR_vec(end))/2.0,d+0.5,'Asymptotic','HorizontalAlignment','center','VerticalAlignment','middle','Rotation',0,'FontSize',12,'FontWeight','bold','BackgroundColor',[.7 .9 .7]);
xlabel('SNR (dB)');
ylabel('mean $\hat{d}$','interpreter','latex');
legend('AIC','MDL','EDC','NEDC','RMT','EFT','SAMOS','RADOI','MUSIC','ESTER','Combined','d_{mat}');
title(['M=', num2str(M),', N=',num2str(N),', d=', num2str(d),', \sigma_s^2=',array2string(sigma_s),', \theta=',array2string(theta_in_deg),'^0']);
grid on; axis([SNR_vec(1) SNR_vec(end) 0 d+1]);

figure(7);
clf;
% axes('fontsize',15);
plot(SNR_vec,derr2_aic,'LineStyle','-','Marker','.','linewidth',1.25);
hold all;
plot(SNR_vec,derr2_mdl,'LineStyle',':','Marker','*','linewidth',1.25);
hold all;
plot(SNR_vec,derr2_edc,'LineStyle','-.','Marker','+','linewidth',1.25);
hold all;
plot(SNR_vec,derr2_re,'LineStyle','--','Marker','x','linewidth',1.25);
hold all;
plot(SNR_vec,derr2_kn,'LineStyle','-','Marker','d','linewidth',1.25);
hold all;
plot(SNR_vec,derr2_eft,'LineStyle',':','Marker','o','linewidth',1.25);
hold all;
plot(SNR_vec,derr2_samos,'LineStyle','-','Marker','.','linewidth',1.25);
hold all;
plot(SNR_vec,derr2_radoi,'LineStyle','-.','Marker','x','linewidth',1.25);
hold all;
plot(SNR_vec,derr2_music,'LineStyle','--','Marker','v','linewidth',1.25);
hold all;
plot(SNR_vec,derr2_ester,'LineStyle','-.','Marker','s','linewidth',1.25);
hold all;
plot(SNR_vec,derr2_ester_combt,'LineStyle','--','Marker','p','linewidth',1.25);
hold off;
line([SNR_vec(snr_ni_index) SNR_vec(snr_ni_index)],[0 d+1],'LineStyle','-.','linewidth',2.0,'Color',[0 0 0]);
line([SNR_vec(snr_th_index) SNR_vec(snr_th_index)],[0 d+1],'LineStyle','-.','linewidth',2.0,'Color',[0 0 0]);
text((SNR_vec(1)+SNR_vec(snr_ni_index))/2.0,d+0.5,'No information','HorizontalAlignment','center','VerticalAlignment','middle','Rotation',0,'FontSize',12,'FontWeight','bold','BackgroundColor',[.7 .9 .7]);
text((SNR_vec(snr_ni_index)+SNR_vec(snr_th_index))/2.0,d+0.5,'Threshold','HorizontalAlignment','center','VerticalAlignment','middle','Rotation',0,'FontSize',12,'FontWeight','bold','BackgroundColor',[.7 .9 .7]);
text((SNR_vec(snr_th_index)+SNR_vec(end))/2.0,d+0.5,'Asymptotic','HorizontalAlignment','center','VerticalAlignment','middle','Rotation',0,'FontSize',12,'FontWeight','bold','BackgroundColor',[.7 .9 .7]);
xlabel('SNR (dB)');
ylabel('RMSDE');
legend('AIC','MDL','EDC','NEDC','RMT','EFT','SAMOS','RADOI','MUSIC','ESTER','Combined');
title(['M=', num2str(M),', N=',num2str(N),', d=', num2str(d),', \sigma_s^2=',array2string(sigma_s),', \theta=',array2string(theta_in_deg),'^0']);
grid on; axis([SNR_vec(1) SNR_vec(end) 0 4]);
