function var = compute_var2(f,M,N,NTrials)

d = length(f);

mse = zeros(1,NTrials);
for trial = 1:NTrials
    
    X = sqrt(1.0/2)*(randn(M,N) + 1i*randn(M,N));
    
    [U,S,V] = svd(X);
    
    fhat = angle(eig(pinv(U(1:M-1,1:d))*U(2:M,1:d)))';
%     fhat = 2*pi*(rand(1,d)-0.5);
    [f_used,fhat_used] = Rd_mypairing(f,fhat);
    
    mse(trial) = mean(abs(fhat(fhat_used) - f(f_used)).^2);
end
var = mean(mse);

end
