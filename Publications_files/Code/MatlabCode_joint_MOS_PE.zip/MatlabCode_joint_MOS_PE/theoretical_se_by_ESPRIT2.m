function [theo_se ] = theoretical_se_by_ESPRIT2( f,M,N,Rs,sigma )

K = length(f);
if K==0
    theo_se = 0.0;
    return;
end

% lambda_c = 1.0;
% d = 1/2*lambda_c;
% C = lambda_c./(2*pi*d*cos(f));

I = eye(M);
I_up =  I(1:end-1,:);
I_down =  I(2:end,:);

e = eye(K);

A =  exp(1j*(0:M-1)'*f);

A_up =  A(1:end-1,:);
A_down =  A(2:end,:);

alpha = (e*(pinv(A_down)*I_down - pinv(A_up)*I_up))';%diag(C)*
alpha_squared = diag(alpha'*alpha);

beta_squared = diag(1/N*inv(Rs));

theo_se = alpha_squared.*beta_squared*sigma/2.0;

% theo_rmse = sqrt(mean(theo_se));

end