function d_est = ranoi(eig_values)
% Discriminant approach
eig_values = sort(eig_values,'descend');
eig_num = length(eig_values);
% Calculating mu_fct
for kk = 1:(eig_num-1)
    mu_fct(kk) = (1/(eig_num-kk))*sum(eig_values(kk+1:eig_num));
end
% Calculating alpha_c
for kk = 1:(eig_num-1)
   alpha_var(kk) = (eig_values(kk) - mu_fct(kk))/mu_fct(kk);
end
% alpha_const is the position of the element
alpha_const = max(alpha_var);
%
% Calculating ksi
for kk = 1:(eig_num-1)
    ksi(kk) = 1-1/alpha_const*alpha_var(kk);
end
%
for kk = 1:(eig_num-1)
    %
    discr_1(kk) = eig_values(kk+1)/sum(eig_values(2:eig_num));
    %
    discr_2(kk) = ksi(kk)/sum(ksi(1:(eig_num-1)));
    %
    discr_crit(kk) = discr_1(kk) - discr_2(kk);
    %
end
[~,d_vec]= find(discr_crit>0);
d_est = d_vec(end);