%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Demonstration for spectral estimation from time series using ESPRIT
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear; clc; close all
tic;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Step 1: Setup signal parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% true number of harmonics (unknown at the observer)
M = 10; N = 100; d = 5;

UnequalPowerFlag = 0; CloseSpacedFlag = 1;

if UnequalPowerFlag == 1
    % signal powers for the different harmonics
    str1 = 'UnequalPowered\';
else
    str1 = 'EqualPowered\';
end

if CloseSpacedFlag==1
    str2 = 'CloseSpaced\';
else
    str2 = 'WideSpaced\';
end

rand('state',sum(100.*clock));

if UnequalPowerFlag == 1
    % signal powers for the different harmonics
    %sigma_s = [1e3 1];%/1000;%
    %sigma_s = 1.0*randn(1,d).^2;%
    sigma_s = 1.0*randn(1,d).^2;%
    sigma_s_sorted = sort(sigma_s);
    ratio = sigma_s_sorted(2:end)./sigma_s_sorted(1:end-1);
    while min(ratio)<1.5
        sigma_s = 1.0*randn(1,d).^2;%
        sigma_s_sorted = sort(sigma_s);
        ratio = sigma_s_sorted(2:end)./sigma_s_sorted(1:end-1);
    end
else
    sigma_s = 1.0*ones(1,d);%SNR = -10;
end
mean_power = mean(sigma_s);

sigma_n = 1.0;
SNR = 10*log10(mean_power/sigma_n);

if CloseSpacedFlag==1
    % minimum frequency spacing of two harmonics that is allowed for the randomly generated frequencies
    mindelf = 5;
    theta_in_deg = fix(180*(rand(1,d)-0.5));
    while min(diff(sort(theta_in_deg)))>mindelf % assure minimum spacing
        theta_in_deg = fix(180*(rand(1,d)-0.5));
    end
else
    theta_in_deg1 = 180*(round(linspace(1,M+1,d+1))-0.5)/M-90;
    theta_in_deg = theta_in_deg1(1:end-1);
end

theta = theta_in_deg/360*2*pi;
mu = pi*sin(theta);
A =  exp(1j*(0:M-1)'*pi*sin(theta)); % /sqrt(M)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Step 2: RMT and EFT
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% for RMT
alpha = 0.01; % condicience level for RMT criterion
beta = 2; %: indication of real-valued or complex-valued, real-valued: beta=1; complex-valued: beta=2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Find coefficients eta_p
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This is done via Monte-Carlo trials with only noise
% Can be done offline since the coefficients are only a function of M, N
% and the Target PFA (probability of false alarm).
% It is recommended to do this once for a configuration of M and N and then
% to store the cofficients and load them for each simulation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% for EFT, computation of the threshold
Pfa = 0.01; % Probability of false alarm rate
coeff_unit = 1e-3;

filename = ['1-D EFT threshold\eta_p (M=', num2str(M),', Ns=',num2str(N),', Pfa=', num2str(Pfa),...
    ', unit=', num2str(coeff_unit),').mat'];
if exist(filename,'file')==2
    load(filename);
    
elseif exist(filename,'file')==0
    fprintf('Obtaining threshold coefficients...');
    
    % Number of Monte-Carlo trials to find eta_p
    I = Pfa/(min(M,N)-1); % Probability of false alarm rate for each assumed number of signals
    esti_accuracy_of_I = 0.1;
    confidence_level = 0.95;
    upperband = norminv(0.5+confidence_level/2.0);
    q = ceil((upperband/esti_accuracy_of_I)^2/I); % number of Monte Carlo runs for threshold determination
    
    [local_coeff_eft,prob_found_eft] = calc_coef_paper(M,N,I,coeff_unit,q);
    
    fprintf(' done (%g s).\n',toc);
    save(filename,'local_coeff_eft','prob_found_eft');
else
    display('Error!')
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Step 3: Computation of rmse of the estimates and model order selection
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
seed = 10000; randn('state',seed); % for reproducibility. Change the seed for new results

SNR_vec = -30:2.5:75;%0.5
SNR_length = length(SNR_vec);
NTrials = 1e1;

crb_correct = zeros(SNR_length,NTrials);
crb_se_vector = zeros(SNR_length,d,NTrials);
se_all = zeros(SNR_length,d,NTrials);
mu_all = zeros(SNR_length,d,NTrials);
muhat_all = zeros(SNR_length,d,NTrials);

dhat_samos = zeros(SNR_length,NTrials);
dhat_ester = zeros(SNR_length,NTrials);
dhat_ester_combt = zeros(SNR_length,NTrials);
dhat_radoi = zeros(SNR_length,NTrials);
dhat_music = zeros(SNR_length,NTrials);
dhat_aic = zeros(SNR_length,NTrials);
dhat_mdl = zeros(SNR_length,NTrials);
dhat_edc = zeros(SNR_length,NTrials);
dhat_re = zeros(SNR_length,NTrials);
dhat_kn = zeros(SNR_length,NTrials);
dhat_sure = zeros(SNR_length,NTrials);
dhat_eft = zeros(SNR_length,NTrials);

for trial = 1:NTrials
    
    s = sqrt(diag(sigma_s/2))*(randn(d,N) + 1j*randn(d,N));
    Rss = 1/N*(s*s');
    X0 = A*s;
    
    for snr_index = 1:SNR_length
        
        sigma_n = 10^(-SNR_vec(snr_index)/10)*mean_power;
        Z = sqrt(sigma_n/2)*(randn(M,N) + 1i*randn(M,N));
        X = X0+Z;
        
        [U,S,V] = svd(X);
        
        % eigenvalues of the sample covariance matrix
        eig_vec = diag(S).^2/N;
        
        dhat_samos(snr_index,trial) = samos(X,M,N);
        % dhat_ester(snr_index,trial) = ester(X,M,N,d);
        dhat_music(snr_index,trial) = order_orth(U,M);
        dhat_radoi(snr_index,trial) = ranoi(eig_vec);%_app
        
        dhat_aic(snr_index,trial) = akaike_short2(eig_vec,size(X,2));
        dhat_mdl(snr_index,trial) = mdl_short2(eig_vec,size(X,2));
        dhat_edc(snr_index,trial) = edc_short2(eig_vec,size(X,2));
        dhat_re(snr_index,trial) = rank_est_RE(eig_vec,M,N);
        dhat_kn(snr_index,trial) = KN_rankEst(eig_vec,N, beta, alpha); % modification by liu k.f.
        dhat_sure(snr_index,trial) = sure_method(X,M,N);
        dhat_eft(snr_index,trial) = eft_short_paper(eig_vec,local_coeff_eft,M,N);
        dhat_ester(snr_index,trial) = ester(X,M,N,1,M-2);
        
        if N/M<2
            dmin = min([dhat_re(snr_index,trial),dhat_kn(snr_index,trial),dhat_eft(snr_index,trial),dhat_sure(snr_index,trial)]);
            dmax = min([dhat_re(snr_index,trial),dhat_kn(snr_index,trial),dhat_eft(snr_index,trial),dhat_sure(snr_index,trial)]);
        else
            if N/M>=2 && N/M<5
                dmin = max(dhat_edc(snr_index,trial),dhat_sure(snr_index,trial));
                dmax = min(dhat_aic(snr_index,trial),dhat_radoi(snr_index,trial),dhat_music(snr_index,trial));
            elseif N/M>=5 && N/M<10
                dmin = dhat_mdl(snr_index,trial);
            else
                dmin = dhat_edc(snr_index,trial);
                dmax = dhat_aic(snr_index,trial);
            end
        end
        dhat_ester_combt(snr_index,trial) = ester(X,M,N,dmin,dmax);
        
        square_error_matrix = calc_crb(mu, M, SNR_vec(snr_index), N,'det',Rss);
        crb_se_vector(snr_index,:,trial) = sort(diag(square_error_matrix));
        crb_correct(snr_index,trial) = trace(square_error_matrix)/d;
        
        for dhat = 1:d-1
            muhat = angle(eig(pinv(U(1:M-1,1:dhat))*U(2:M,1:dhat)))';
            [mu_used,muhat_used] = Rd_mypairing(mu,muhat);
            se_all(snr_index,dhat,trial) = mean(abs(muhat(muhat_used) - mu(mu_used)).^2);
        end
        
        muhat = angle(eig(pinv(U(1:M-1,1:d))*U(2:M,1:d)))';
        [mu_used,muhat_used] = Rd_mypairing(mu,muhat);
        mu_all(snr_index,:,trial) = mu(mu_used);
        muhat_all(snr_index,:,trial) = muhat(muhat_used);
        se_all(snr_index,d,trial) = mean(abs(muhat_all(snr_index,:,trial) - mu_all(snr_index,:,trial)).^2);
    end
    if mod(trial,10)==0
        fprintf('Trials: %d / %d: done (%g s).\n',trial,NTrials,toc);
    end
end

crb = sqrt(mean(crb_correct,2));

rmse_all = sqrt(mean(se_all,3));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Step 4: Identification of the effective and optimal model order
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% rmse_peak = sqrt(compute_var(mu,NTrials));
d_opt = zeros(SNR_length,1);
for snr_index = 1:SNR_length
    [~,d_opt(snr_index)] = min(rmse_all(snr_index,:));
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Step 5: Display the results
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[~,SNR_index_begin] = min(abs(SNR_vec-(-20)));
%[~,SNR_index_end] = SNR_length;%min(abs(SNR_vec-(30)));
SNR_index_end = SNR_length;
delta = 1;

set(0,'DefaultAxesColorOrder',[0 0 1; 0 1 0; 0 1 1; 1 0 0; 1 0 1; 1 0.6 0; 0.6 0 1; .6 0.6 0; 1 0 0.6]);

% figure(1);
% clf;
% plot(SNR_vec(SNR_index_begin:delta:SNR_index_end),d_opt(SNR_index_begin:delta:SNR_index_end),'LineStyle','-','Color',[0 0 0],'linewidth',2);
% xlabel('SNR (dB)');
% ylabel('d_{mat}');
% legend('d_{mat}','Location','SouthEast');
% title(['M=', num2str(M),', N=',num2str(N),', d=', num2str(d),', \sigma_s^2=',array2string(sigma_s),', \theta=',array2string(theta_in_deg),'^0']);
% grid on; axis([SNR_vec(SNR_index_begin:delta:SNR_index_end)(1) SNR_vec(SNR_index_begin:delta:SNR_index_end)(end) 0 d+1]); % axis tight;
%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % Step 4: Detection Performance comparison
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

derr2_samos = sqrt(mean(abs(dhat_samos(SNR_index_begin:delta:SNR_index_end,:)-repmat(d_opt(SNR_index_begin:delta:SNR_index_end),[1 NTrials])).^2,2));
derr2_ester = sqrt(mean(abs(dhat_ester(SNR_index_begin:delta:SNR_index_end,:)-repmat(d_opt(SNR_index_begin:delta:SNR_index_end),[1 NTrials])).^2,2));
derr2_ester_combt = sqrt(mean(abs(dhat_ester_combt(SNR_index_begin:delta:SNR_index_end,:)-repmat(d_opt(SNR_index_begin:delta:SNR_index_end),[1 NTrials])).^2,2));
derr2_radoi = sqrt(mean(abs(dhat_radoi(SNR_index_begin:delta:SNR_index_end,:)-repmat(d_opt(SNR_index_begin:delta:SNR_index_end),[1 NTrials])).^2,2));
derr2_aic = sqrt(mean(abs(dhat_aic(SNR_index_begin:delta:SNR_index_end,:)-repmat(d_opt(SNR_index_begin:delta:SNR_index_end),[1 NTrials])).^2,2));
derr2_mdl = sqrt(mean(abs(dhat_mdl(SNR_index_begin:delta:SNR_index_end,:)-repmat(d_opt(SNR_index_begin:delta:SNR_index_end),[1 NTrials])).^2,2));
derr2_edc = sqrt(mean(abs(dhat_edc(SNR_index_begin:delta:SNR_index_end,:)-repmat(d_opt(SNR_index_begin:delta:SNR_index_end),[1 NTrials])).^2,2));
derr2_re = sqrt(mean(abs(dhat_re(SNR_index_begin:delta:SNR_index_end,:)-repmat(d_opt(SNR_index_begin:delta:SNR_index_end),[1 NTrials])).^2,2));
derr2_kn = sqrt(mean(abs(dhat_kn(SNR_index_begin:delta:SNR_index_end,:)-repmat(d_opt(SNR_index_begin:delta:SNR_index_end),[1 NTrials])).^2,2));
derr2_eft = sqrt(mean(abs(dhat_eft(SNR_index_begin:delta:SNR_index_end,:)-repmat(d_opt(SNR_index_begin:delta:SNR_index_end),[1 NTrials])).^2,2));
derr2_sure = sqrt(mean(abs(dhat_sure(SNR_index_begin:delta:SNR_index_end,:)-repmat(d_opt(SNR_index_begin:delta:SNR_index_end),[1 NTrials])).^2,2));

figure(5);
clf;
% axes('fontsize',15);
plot(SNR_vec(SNR_index_begin:delta:SNR_index_end),mean(dhat_aic(SNR_index_begin:delta:SNR_index_end,:),2),'LineStyle','-','Marker','.','linewidth',1.25);
hold all;
plot(SNR_vec(SNR_index_begin:delta:SNR_index_end),mean(dhat_mdl(SNR_index_begin:delta:SNR_index_end,:),2),'LineStyle',':','Marker','*','linewidth',1.25);
hold all;
plot(SNR_vec(SNR_index_begin:delta:SNR_index_end),mean(dhat_edc(SNR_index_begin:delta:SNR_index_end,:),2),'LineStyle','-.','Marker','+','linewidth',1.25);
hold all;
plot(SNR_vec(SNR_index_begin:delta:SNR_index_end),mean(dhat_re(SNR_index_begin:delta:SNR_index_end,:),2),'LineStyle','--','Marker','x','linewidth',1.25);
hold all;
plot(SNR_vec(SNR_index_begin:delta:SNR_index_end),mean(dhat_kn(SNR_index_begin:delta:SNR_index_end,:),2),'LineStyle','-','Marker','d','linewidth',1.25);
hold all;
plot(SNR_vec(SNR_index_begin:delta:SNR_index_end),mean(dhat_sure(SNR_index_begin:delta:SNR_index_end,:),2),'LineStyle','--','Marker','p','linewidth',1.25);
hold all;
plot(SNR_vec(SNR_index_begin:delta:SNR_index_end),mean(dhat_eft(SNR_index_begin:delta:SNR_index_end,:),2),'LineStyle',':','Marker','o','linewidth',1.25);
hold all;
plot(SNR_vec(SNR_index_begin:delta:SNR_index_end),mean(dhat_samos(SNR_index_begin:delta:SNR_index_end,:),2),'LineStyle','-','Marker','.','linewidth',1.25);
hold all;
plot(SNR_vec(SNR_index_begin:delta:SNR_index_end),mean(dhat_radoi(SNR_index_begin:delta:SNR_index_end,:),2),'LineStyle','-.','Marker','x','linewidth',1.25);
hold all;
plot(SNR_vec(SNR_index_begin:delta:SNR_index_end),mean(dhat_music(SNR_index_begin:delta:SNR_index_end,:),2),'LineStyle','--','Marker','v','linewidth',1.25);
hold all;
plot(SNR_vec(SNR_index_begin:delta:SNR_index_end),mean(dhat_ester(SNR_index_begin:delta:SNR_index_end,:),2),'LineStyle','-.','Marker','s','linewidth',1.25);
hold all;
plot(SNR_vec(SNR_index_begin:delta:SNR_index_end),mean(dhat_ester_combt(SNR_index_begin:delta:SNR_index_end,:),2),'LineStyle','--','Marker','p','linewidth',1.25);
hold all;
plot(SNR_vec(SNR_index_begin:delta:SNR_index_end),d_opt(SNR_index_begin:delta:SNR_index_end),'LineStyle','-','linewidth',2,'Color',[0 0 0]);
hold off;
% line([SNR_vec(SNR_index_begin:delta:SNR_index_end)(snr_ni_index) SNR_vec(SNR_index_begin:delta:SNR_index_end)(snr_ni_index)],[0 d+1],'LineStyle','-.','linewidth',1.25,'Color',[0 0 0]);
% line([SNR_vec(SNR_index_begin:delta:SNR_index_end)(snr_th_index) SNR_vec(SNR_index_begin:delta:SNR_index_end)(snr_th_index)],[0 d+1],'LineStyle','-.','linewidth',1.25,'Color',[0 0 0]);
% text((SNR_vec(SNR_index_begin:delta:SNR_index_end)(1)+SNR_vec(SNR_index_begin:delta:SNR_index_end)(snr_ni_index))/2.0,d+0.5,'No information','HorizontalAlignment','center','VerticalAlignment','middle','Rotation',0,'FontSize',12,'FontWeight','bold','BackgroundColor',[.7 .9 .7]);
% text((SNR_vec(SNR_index_begin:delta:SNR_index_end)(snr_ni_index)+SNR_vec(SNR_index_begin:delta:SNR_index_end)(snr_th_index))/2.0,d+0.5,'Threshold','HorizontalAlignment','center','VerticalAlignment','middle','Rotation',0,'FontSize',12,'FontWeight','bold','BackgroundColor',[.7 .9 .7]);
% text((SNR_vec(SNR_index_begin:delta:SNR_index_end)(snr_th_index)+SNR_vec(SNR_index_begin:delta:SNR_index_end)(end))/2.0,d+0.5,'Asymptotic','HorizontalAlignment','center','VerticalAlignment','middle','Rotation',0,'FontSize',12,'FontWeight','bold','BackgroundColor',[.7 .9 .7]);
xlabel('SNR (dB)');
ylabel('mean $\hat{d}$','interpreter','latex');
legend('AIC','MDL','EDC','NEDC','RMT','EFT','SAMOS','RADOI','MUSIC','ESTER','Combined','d_{mat}');
legend('AIC','MDL','EDC','NEDC','RMT','SURE','EFT','SAMOS','RADOI','MUSIC','ESTER','Combined','d_{mat}');
title(['M=', num2str(M),', N=',num2str(N),', d=', num2str(d),', \sigma_s^2=',array2string(sigma_s),', \theta=',array2string(theta_in_deg),'^0']);
grid on; axis([SNR_vec(SNR_index_begin) SNR_vec(SNR_index_end) 0 d+1])