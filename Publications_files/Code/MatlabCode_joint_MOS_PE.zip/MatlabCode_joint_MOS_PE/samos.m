function d_est = samos(X_mat,M,N)
% Model order selection
[U,S,V] = svd(X_mat);
% Calculating U up and U down
min_M = min([floor((M-1)/2) N]);
for kk = 1:min_M
    U_up = U(2:M,1:kk);
    U_down = U(1:(M-1),1:kk);
    U_tb = [U_up U_down];
    psi = svd(U_tb);
    E_est(kk) = (1/kk)*(sum(psi((kk+1):2*kk)));
end
inv_E_est = (E_est).^(-1);
[value,d_est] = max(inv_E_est);