function d_est = ester(X_mat,M,N,dmin,dmax)
% Model order selection
[U,S,V] = svd(X_mat);
% Calculating U up and U down
U_up = U(2:M,:);
U_down = U(1:(M-1),:);
dmax = min(min(M,N)-2,dmax);
if dmax==0
    d_est = 0;
    return;
else
    dmin = max(1,dmin);
    if dmin>=dmax
        d_est = dmax;
    else
        E_est = zeros(1,dmax-dmin+1);
        for kk = dmin:dmax
            phi_est = pinv(U_down(:,1:kk))*U_up(:,1:kk);
            E_aux = (U_down(:,1:kk)*phi_est-U_up(:,1:kk));
            E_est(kk-dmin+1) = norm(E_aux,2)^2;
        end
        [value,d_est] = min(E_est);
        d_est = d_est+dmin-1;
    end
end
end