% dhat = [0:2*d ];%min(M,N)-2*d-1:min(M,N)-1
Khat = 0:Kmax;

ColorOrder = [1 0 0; 0 1 0; 0 0 1; 1 0 1; 1 0 1; 1 0.6 0; 0.6 0 1; .6 0.6 0; 1 0 0.6; 0 0 0];%get(gcf,'DefaultAxesColorOrder');

[~,SNR_index] = min(abs(SNR-25));
%edge = 5;
figure(10+1);
clf;
h = hist(Khat0(SNR_index,:),Khat);
indices =0:Kmax;
bar(indices,h,0.95,'FaceColor',ColorOrder(1,:),'EdgeColor','w');
% h = findobj(gca,'Type','patch');
% set(h,'FaceColor','g','EdgeColor','w');
xlabel('$\hat{K}_{\mathrm{CC}}$','interpreter','latex');
ylabel('Number of estimates');
%title(['Histogram: ','M=' array2string(M),', K=' num2str(K),', SNR= ', num2str(SNR(SNR_index)),' dB, NTrials= ', num2str(NTrials)]);
legend('CORCONDIA (12.5%)',2);
grid on; axis tight;%axis([-edge,edge,0,NTrials]);%


figure(10+2);
clf;
h = hist(Khat3(SNR_index,:),Khat);
indices =0:Kmax;
bar(indices,h,0.95,'FaceColor',ColorOrder(2,:),'EdgeColor','w');
% h = findobj(gca,'Type','patch');
% set(h,'FaceColor','g','EdgeColor','w');
xlabel('$\hat{K}_{\mathrm{CC}}$','interpreter','latex');
ylabel('Number of estimates');
%title(['Histogram: ','M=' array2string(M),', K=' num2str(K),', SNR= ', num2str(SNR(SNR_index)),' dB, NTrials= ', num2str(NTrials)]);
legend('CORCONDIA (75%)',2);
grid on; axis tight;%axis([-edge,edge,0,NTrials]);%

figure(10+3);
clf;
h = hist(Khat7(SNR_index,:),Khat);
indices =0:Kmax;
bar(indices,h,0.95,'FaceColor',ColorOrder(3,:),'EdgeColor','w');
% h = findobj(gca,'Type','patch');
% set(h,'FaceColor','g','EdgeColor','w');
xlabel('$\hat{K}_{\mathrm{CC}}$','interpreter','latex');
ylabel('Number of estimates');
%title(['Histogram: ','M=' array2string(M),', K=' num2str(K),', SNR= ', num2str(SNR(SNR_index)),' dB, NTrials= ', num2str(NTrials)]);
legend('CORCONDIA (99%)',2);
grid on; axis tight;%axis([-edge,edge,0,NTrials]);%

figure(10+4);
clf;
h = hist(KhatAdapEta(SNR_index,:),Khat);
indices =0:Kmax;
bar(indices,h,0.95,'FaceColor',ColorOrder(4,:),'EdgeColor','w');
% h = findobj(gca,'Type','patch');
% set(h,'FaceColor','g','EdgeColor','w');
xlabel('$\hat{K}_{\mathrm{CC-RE}}$','interpreter','latex');
ylabel('Number of estimates');
%title(['Histogram: ','M=' array2string(M),', K=' num2str(K),', SNR= ', num2str(SNR(SNR_index)),' dB, NTrials= ', num2str(NTrials)]);
legend('Proposed',2);
grid on; axis tight;%axis([-edge,edge,0,NTrials]);%