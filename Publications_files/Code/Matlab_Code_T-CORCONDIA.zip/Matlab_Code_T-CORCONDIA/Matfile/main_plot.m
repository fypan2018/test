close all;clc

load('R=3, M=[5, 7, 8], K=4, Kmax=5, NTrials= 1000.mat')

% figure(1);
% clf;
% plot(SNR,p_CORCONDIA0,'LineStyle','-.','Marker','^');
% hold all;
% plot(SNR,p_CORCONDIA1,'LineStyle','-','Marker','.');
% hold all;
% plot(SNR,p_CORCONDIA2,'LineStyle',':','Marker','x');
% hold all;
% plot(SNR,p_CORCONDIA3,'LineStyle','-.','Marker','>');
% hold all;
% plot(SNR,p_CORCONDIA4,'LineStyle','--','Marker','+');
% hold all;
% plot(SNR,p_CORCONDIA5,'LineStyle','-','Marker','d');
% hold all;
% plot(SNR,p_CORCONDIA6,'LineStyle',':','Marker','*');
% hold all;
% plot(SNR,p_CORCONDIA7,'LineStyle','-.','Marker','o');
% hold all;
% plot(SNR,p_CORCONDIAAdapEta,'LineStyle','--','Marker','s');
% hold off;
% xlabel('SNR (dB)');
% ylabel('Pr ($\hat{K}_{CC} = K$','interpreter','Latex');
% legend('CORCONDIA (12.5%)','CORCONDIA (25%)','CORCONDIA (50%)','CORCONDIA (75%)','CORCONDIA (90%)','CORCONDIA (95%)','CORCONDIA (98%)','CORCONDIA (99%)','CORCONDIA (Adaptive Threshold)');
% % legend('CORCONDIA (50%)','CORCONDIA (60%)','CORCONDIA (70%)','CORCONDIA (80%)','CORCONDIA (90%)','CORCONDIA (Proposed)');
% title(['R=' num2str(R),', M=' array2string(M),', K=' num2str(K),', K_{max}=' num2str(Kmax),', NTrials= ', num2str(NTrials)]);
% grid on; axis tight; % axis([SNR(1) SNR(end) 0 1]); % 
% 
% figure(2);
% clf;
% plot(SNR,p_CORCONDIA0,'LineStyle','-.','Marker','^');
% hold all;
% % plot(SNR,p_CORCONDIA1,'LineStyle','-','Marker','.');
% % hold all;
% plot(SNR,p_CORCONDIA2,'LineStyle',':','Marker','x');
% hold all;
% plot(SNR,p_CORCONDIA3,'LineStyle','-.','Marker','>');
% hold all;
% plot(SNR,p_CORCONDIA4,'LineStyle','--','Marker','+');
% hold all;
% % plot(SNR,p_CORCONDIA5,'LineStyle','-','Marker','d');
% % hold all;
% % plot(SNR,p_CORCONDIA6,'LineStyle',':','Marker','*');
% % hold all;
% plot(SNR,p_CORCONDIA7,'LineStyle','-.','Marker','o');
% hold all;
% plot(SNR,p_CORCONDIAAdapEta,'LineStyle','--','Marker','s');
% hold off;
% xlabel('SNR (dB)');
% ylabel('Pr ($\hat{K}_{CC} = K$','interpreter','Latex');
% legend('CORCONDIA (12.5%)','CORCONDIA (50%)','CORCONDIA (75%)','CORCONDIA (90%)','CORCONDIA (99%)','Proposed');
% % legend('CORCONDIA (50%)','CORCONDIA (60%)','CORCONDIA (70%)','CORCONDIA (80%)','CORCONDIA (90%)','CORCONDIA (Proposed)');
% title(['R=' num2str(R),', M=' array2string(M),', K=' num2str(K),', K_{max}=' num2str(Kmax),', NTrials= ', num2str(NTrials)]);
% grid on; axis tight; % axis([SNR(1) SNR(end) 0 1]); % 

figure(3);
clf;
set(gcf,'DefaultAxesColorOrder',[1 0 0; 0 1 0; 0 0 1; 1 0 1; 1 0 1; 1 0.6 0; 0.6 0 1; .6 0.6 0; 1 0 0.6; 0 0 0]);
plot(SNR,p_CORCONDIA0,'LineStyle','--','Marker','^');
hold all;
% plot(SNR,p_CORCONDIA1,'LineStyle','-','Marker','.');
% hold all;
% plot(SNR,p_CORCONDIA2,'LineStyle',':','Marker','x');
% hold all;
plot(SNR,p_CORCONDIA3,'LineStyle','-.','Marker','>');
hold all;
% plot(SNR,p_CORCONDIA4,'LineStyle','--','Marker','+');
% hold all;
% plot(SNR,p_CORCONDIA5,'LineStyle','-','Marker','d');
% hold all;
% plot(SNR,p_CORCONDIA6,'LineStyle',':','Marker','*');
% hold all;
plot(SNR,p_CORCONDIA7,'LineStyle',':','Marker','o');
hold all;
plot(SNR,p_CORCONDIAAdapEta,'LineStyle','-','Marker','s','linewidth',2.0);
hold off;
xlabel('SNR (dB)');
ylabel('Pr ($\hat{K}_{CC}$ = $K$)','interpreter','Latex');
legend('CORCONDIA (12.5%)','CORCONDIA (75%)','CORCONDIA (99%)','Proposed',2);
% legend('CORCONDIA (50%)','CORCONDIA (60%)','CORCONDIA (70%)','CORCONDIA (80%)','CORCONDIA (90%)','CORCONDIA (Proposed)');
% title(['R=' num2str(R),', M=' array2string(M),', K=' num2str(K),', K_{max}=' num2str(Kmax),', NTrials= ', num2str(NTrials)]);
grid on; axis tight; % axis([SNR(1) SNR(end) 0 1]); % 

Khat = 0:Kmax+1;

Khat0_histogram = zeros(length(Khat),SNR_length+1);
Khat3_histogram = zeros(length(Khat),SNR_length+1);
Khat7_histogram = zeros(length(Khat),SNR_length+1);
KhatAdapEta_histogram = zeros(length(Khat),SNR_length+1);

for k=1:length(Khat)
    for snr_index=1:SNR_length
        Khat0_histogram(k,snr_index) = length(find(Khat0(snr_index,:)==Khat(k))) / NTrials;
        Khat3_histogram(k,snr_index) = length(find(Khat3(snr_index,:)==Khat(k))) / NTrials;
        Khat7_histogram(k,snr_index) = length(find(Khat7(snr_index,:)==Khat(k))) / NTrials;
        KhatAdapEta_histogram(k,snr_index) = length(find(KhatAdapEta(snr_index,:)==Khat(k))) / NTrials;
    end
end

SNR = [SNR 2*SNR(end)-SNR(end-1)];

figure(3+1);
clf;
[X,Y] = meshgrid(SNR, Khat);
Khat0_histogram(Khat0_histogram<=0.5/NTrials)=NaN;
pcolor(X, Y-1/2, Khat0_histogram);
shading flat; colorbar;
xlabel('SNR (dB)');
ylabel('$\hat{K}$','interpreter','latex');
% zlabel('Number of estimates');
title(['CORCONDIA (12.5%): ','M=' array2string(M),', K=' num2str(K),', NTrials= ', num2str(NTrials)]);
grid on; axis([SNR(1),SNR(end),0,Kmax+1/2]);%axis tight;

figure(3+2);
clf;
[X,Y] = meshgrid(SNR, Khat);
Khat3_histogram(Khat3_histogram<=0.5/NTrials)=NaN;
pcolor(X, Y-1/2, Khat3_histogram);
shading flat; colorbar;
xlabel('SNR (dB)');
ylabel('$\hat{K}$','interpreter','latex');
% zlabel('Number of estimates');
title(['CORCONDIA (75%): ','M=' array2string(M),', K=' num2str(K),', NTrials= ', num2str(NTrials)]);
grid on; axis([SNR(1),SNR(end),0,Kmax+1/2]);%axis tight;

figure(3+3);
clf;
[X,Y] = meshgrid(SNR, Khat);
Khat7_histogram(Khat7_histogram<=0.5/NTrials)=NaN;
pcolor(X, Y-1/2, Khat7_histogram);
shading flat; colorbar;
xlabel('SNR (dB)');
ylabel('$\hat{K}$','interpreter','latex');
% zlabel('Number of estimates');
title(['CORCONDIA (99%): ','M=' array2string(M),', K=' num2str(K),', NTrials= ', num2str(NTrials)]);
grid on; axis([SNR(1),SNR(end),0,Kmax+1/2]);%axis tight;

figure(3+4);
clf;
[X,Y] = meshgrid(SNR, Khat);
KhatAdapEta_histogram(KhatAdapEta_histogram<=0.5/NTrials)=NaN;
pcolor(X, Y-1/2, KhatAdapEta_histogram);
shading flat; colorbar;
xlabel('SNR (dB)');
ylabel('$\hat{K}$','interpreter','latex');
% zlabel('Number of estimates');
title(['Proposed: ','M=' array2string(M),', K=' num2str(K),', NTrials= ', num2str(NTrials)]);
grid on; axis([SNR(1),SNR(end),0,Kmax+1/2]);%axis tight;