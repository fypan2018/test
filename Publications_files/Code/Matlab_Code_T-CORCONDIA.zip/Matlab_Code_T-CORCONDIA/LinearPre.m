function ErrPred = LinearPre(ErrVec)

k = (1:length(ErrVec))';
c = [k,ones(length(ErrVec),1)] \ ErrVec.';

ErrPred = (length(ErrVec)+1)*c(1)+c(2);

end

