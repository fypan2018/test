function [ Khat ] = rank_est_CORCONDIA_basic( Y, Kmax, eta)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
Consistency = zeros(1,Kmax);
% detection from the lowest candidate rank

Khat = 1;
Factors = parafac(Y,1);
Consistency(1) = corcond(Y,Factors);%,[],2
% [~,~,~,Consistency(1)] = parafac(Y,1);
if Consistency(1)<eta
    Khat = 0;
else
    for k = Kmax:-1:2
        Factors = parafac(Y,k);
        Consistency(k) = corcond(Y,Factors);%,[],2
%         [~,~,~,Consistency(k)] = parafac(Y,k);
        if Consistency(k)>=eta
            Khat = k;
            break;
        end
    end
end

% figure
% plot(1:Kmax,Consistency);
% pause
% [~,Khat] = max(2*Consistency(1:end-1)- Consistency(2:end));
end