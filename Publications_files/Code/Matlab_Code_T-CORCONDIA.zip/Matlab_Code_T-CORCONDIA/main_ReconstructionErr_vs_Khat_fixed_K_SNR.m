
clear all;close all;clc
tic;

N = 7; M = [7 7 N]; R = length(M);
Kmax = max(M); K = 3; 
SNR = 0;%-15:0.1:5;-0:2.5:

Options(5)=NaN; % For use in parafac function

it = zeros(1,Kmax);
Err = zeros(1,Kmax);
Consistency = zeros(1,Kmax);
sigma_n = 1.0;

while(1)
    
    if K>0
        F = cell(1,R);
        for r=1:R
            F{r} = randn(M(r),K);%sqrt(1/2)*(randn(M(r),K) + 1j*randn(M(r),K));
        end
        
        core = nident(K,R);
        X = nmodel(F,[]);% core
        
        X = X/sltensor_norm(X)*sqrt(prod(M)*sigma_n)*10^(SNR/20);
        Z = sqrt(sigma_n)*randn(M);% sqrt(sigma_n/2)*(randn(M) + 1i*randn(M));
        Y = X+Z;
    else
        sigma_n = 1.0;
        Y = sqrt(sigma_n)*randn(M);
    end
    
    for k = 1:Kmax%
        [Factors,it(k),Err(k),Consistency(k)] = parafac(Y,k,Options);
    end
    
    if Consistency(K)>12.5 && Consistency(K)<=75 && Consistency(K+1)<12.5
        break;
    end
end

NoiseEst = Err/prod(M);

filename = ['Matfile\ReconstructionErr_vs_Khat\R=' num2str(R),', M=' array2string(M),', K=' num2str(K),', Kmax=' num2str(Kmax),', SNR=' num2str(SNR),'dB.mat'];
save(filename);

figure(1);
clf;
plot(1:Kmax,NoiseEst,'r-.','LineWidth',2,'Marker','o');
hold on
plot(1:Kmax,sigma_n*ones(1,Kmax),'k-','LineWidth',2);
hold off
legend('r(k)','\sigma_z^2');
xlabel('# Components k');
ylabel('Reconstruction Error');
%title(['Reconstruction Error: R=' num2str(R),', M=' array2string(M),', K=' num2str(K),', K_{max}=' num2str(Kmax),', SNR=' num2str(SNR),' dB']);
axis([1 Kmax 0 max(NoiseEst)]); %  grid on; axis tight; %

figure(8);
clf;
plot(1:Kmax,Consistency,'k:s','LineWidth',1,...
    'MarkerEdgeColor','k',...
    'MarkerFaceColor',[.49 1 .63]);
line([1 Kmax],[Consistency(K) Consistency(K)],'LineStyle','--','linewidth',2.0,'Color',[1 0 0]);
line([1 Kmax],[Consistency(K+1) Consistency(K+1)],'LineStyle','--','linewidth',2.0,'Color',[0 0 1]);
xlabel('k');
ylabel('Core Consistency (%)');
%title(['Consistency Curve: R=' num2str(R),', M=' array2string(M),', K=' num2str(K),', K_{max}=' num2str(Kmax),', SNR=' num2str(SNR),' dB']);
axis tight; % axis([SNR(1) SNR(end) 0 1]); %grid on; 
