function [threshold,prob] = calc_thre_coeff(M,Pfa,coeff_unit,NRuns)
% EFT_CALCCOEFF    Obtain threshold coefficients eta_p for EFT via Monte Carlo
%
% Syntax:
%   coeff = eft_calccoeff(M,N,Pfa,coeff,NRuns)
%
% Input:
%    M, N : problem dimensions (M x N matrix)
%    Pfa  : desired target Pfa (probability of false alarm)
%    coeff: values for the coefficients to try (e.g., 0:0.001:10)
%    NRuns    : number of Monte Carlo trials to estimate the Pfas (e.g., 10000)
%
% Output:
%    coeff: vector with the threshold coefficients eta_p
%
% Credits:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Program to generate the coefficients for the EFT method %
% Joao Paulo C. L. da Costa                               %
% slightly rewritten by F. Roemer                         %
% CRL, TU Ilmenau, Nov 2010                               %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% References:
%
% A. Quinlan, J. Barbot, P. Larzabal, and M. Haardt, ``Model order
% selection for short data: An exponential fitting test (EFT),'' EURASIP
% Journal on Advances in Signal Processing, 2007, Special Issue on Advances
% in Subspace-based Techniques for Signal Processing and Communications,
%
% J. P. C. L. da Costa, M. Haardt, F. R�mer, and G. Del Galdo, ``Enhanced
% model order estimation using higher-order arrays,'' in Proc. 41-st
% Asilomar Conf. on Signals, Systems, and Computers, (Pacific Grove, CA),
% pp. 412-416, Nov. 2007, invited paper
% sigma_n = 10^(-SNR/10);
if nargin<4
    NRuns = 1e3;
end
if nargin<3
    NRuns = 1e3;
    coeff_unit = 0.01;
end
coeff = 0.0:coeff_unit:1.0;
L = length(coeff);
sigma_n = 1.0;
NoiseEst = [sigma_n*prod(M),zeros(1,ceil(min(M)/2.0))];
FlaseAlarmFlag = zeros(NRuns,L,ceil(min(M)/2.0));

barra = waitbar(0,'Calculating thresholds for CORCONDIA');

for ii = 1:NRuns
    Z = randn(M);
    
    RelaDiff = zeros(1,ceil(min(M)/2.0));
    for kk = 1:ceil(min(M)/2.0)
        [~,~,NoiseEst(kk+1),~] = parafac(Z,kk);
        RelaDiff(kk) = (NoiseEst(kk) - NoiseEst(kk+1))/NoiseEst(kk+1);
        FlaseAlarmFlag(ii,:,kk) = RelaDiff(kk)>=coeff;
    end
    waitbar(ii/NRuns,barra);
end
close(barra);

prob_fim = zeros(L,ceil(min(M)/2.0));
threshold = zeros(1,ceil(min(M)/2.0));
prob = zeros(1,ceil(min(M)/2.0));
for kk = 1:ceil(min(M)/2.0)
    prob_fim(:,kk) = squeeze(sum(FlaseAlarmFlag(:,:,kk),1)) / NRuns;
    where = find(prob_fim(:,kk)<=Pfa);
    if isempty(where)
        display('Two small range of threshold coefficients!');
        pause;
    end
    threshold(kk) = coeff(where(1));
    prob(kk) = prob_fim(where(1),kk);
%     prob_fim(:,kk) = squeeze(sum(FlaseAlarmFlag(:,:,kk),1)) / NRuns;
%     [~,where] = min(abs(prob_fim(:,kk)-Pfa));
%     threshold(kk) = coeff(where);
%     prob(kk) = prob_fim(where);
end

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%