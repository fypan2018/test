function [ threshold ] = find_threshold(filename,SNR,K)

load(filename);
[~,SNR_index] = min(abs(SNR_vec-SNR));
K_index = find(K_vec==K);
if(isempty(K_index))
    display('Number of components cannot be found in Table!')
end
threshold = thresh_table(SNR_index,K_index);

end