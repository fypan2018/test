function [ Khat ] = rank_est_CORCONDIA_adaptive_threshold( Y, Kmax, eta_lb, eta_ub, threshold)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
Consistency = zeros(1,Kmax);
Err = zeros(1,Kmax);
% Options(5) = NaN; % For use in parafac function
for k = 1:Kmax
    [~,~,Err(k),Consistency(k)] = parafac(Y,k);%,Options
end
Err = [sltensor_norm(Y)^2,Err];

% if Consistency(1)<eta_lb
%     Khat = 0;
%     return;
% else
%     for k = Kmax:-1:1
%         if Consistency(k)>=eta_lb
%             Khat_ub = k;
%             break;
%         end
%     end
%     for k = Khat_ub:-1:1
%         if Consistency(k)>=eta_ub
%             Khat_lb = k;
%             break;
%         end
%     end
    
flag_find = 0;
for k = 1:Kmax
    if Consistency(k)<eta_ub
        Khat_lb = k-1;
        flag_find = 1;
        break;
    end
end
if flag_find == 0
    display('Conditions (Lower Bound) cannot be satisfied!');
    Khat_lb = Kmax;
    %     figure;
%     plot(1:Kmax,Consistency,'k.-','LineWidth',2);
%     pause
end

flag_find = 0;
for k = Khat_lb+1:Kmax
    if Consistency(k)<eta_lb% || Consistency(k-1)<Consistency(k)
        Khat_ub = k-1;
        flag_find = 1;
        break;
    end
end
if flag_find == 0
    display('Conditions (Upper Bound) cannot be satisfied!');

    Khat_ub = Kmax;
end

if Khat_lb==0
    Khat = 0;
else
    flag = 1;
    for k = Khat_ub:-1:Khat_lb
        ratio = (Err(k) - Err(k+1))/Err(k+1); % (Err(k) - Err(k+1));
        if ratio>= max(threshold) % 2.0 threshold(k-Khat_lb+1)
            Khat = k;
            flag = 0;
            break;
        end
    end
    if flag==1
        Khat = Khat_ub;
    end
end

% if Khat~=3
%     M = size(Y);
%     figure(1);
%     clf;
%     plot(1:Kmax,Err/prod(M),'LineStyle','-.','LineWidth',2,'Marker','s','Color',[1 0 0]);
%     hold on
%     plot(1:Kmax,1.0*ones(1,Kmax),'k.-','LineWidth',2);
%     hold off
%     legend('Estimate','True');
%     xlabel('k');
%     ylabel('Reconstruction Error');
%     grid on; % axis tight; %NoiseEst(12)axis([1 Kmax 0 sigma_n]); %
%     
%     NoiseEst = Err/prod(M);
%     RelaDiff = zeros(1,Kmax);
%     for k = 2:Kmax
%         RelaDiff(k) = (NoiseEst(k-1) - NoiseEst(k))/NoiseEst(k);
%     end
%     figure(2);
%     clf;
%     plot(2:Kmax,RelaDiff(2:end),'LineStyle','-.','LineWidth',2,'Marker','s','Color',[1 0 0]);
%     hold all
%     plot(2:Kmax,threshold(1)*ones(1,Kmax-1),'k.-','LineWidth',2);
%     hold all
%     plot(2:Kmax,threshold(2)*ones(1,Kmax-1),'ko-','LineWidth',2);
%     hold all
%     plot(2:Kmax,threshold(3)*ones(1,Kmax-1),'ks-','LineWidth',2);
%     hold all
%     plot(Khat_lb*ones(1,2),[min(RelaDiff(2:end)),max(RelaDiff(2:end))],'k-','LineWidth',2);
%     hold all
%     plot(Khat_ub*ones(1,2),[min(RelaDiff(2:end)),max(RelaDiff(2:end))],'k-','LineWidth',2);
%     hold off
%     xlabel('k');
%     ylabel('Relative Diff');
%     legend('Relative Diff','Threshold 1','Threshold 2','Threshold 3','Lower bound','Upper bound');
%     title(['Khat=',num2str(Khat),', Khat_{lb}=',num2str(Khat_lb),', Khat_{ub}=',num2str(Khat_ub)]);
%     grid on; % axis tight; % axis([1 Kmax 0 1]); %
%     
%     figure(3);
%     clf;
%     plot(1:Kmax,Consistency,'k.-','LineWidth',2);
%     xlabel('k');
%     ylabel('Consistency (%)');
%     grid on; % axis tight; % axis([SNR(1) SNR(end) 0 1]); %
%     
%     Khat_lb,Khat_ub,Khat
%     pause
% end
    
end

