
clear all;close all;clc
tic;

N = 5; M = [5 5 5 N]; R = length(M);
K = 3; Kmax = min(M); % K = 2; Kmax = max(M);

beta = 1;   % beta=1 for real valued observations. Change to beta=2 for complex valued data and noise.
Options(5)=NaN; % For use in parafac function

% for EFT, computation of the threshold
Pfa = 0.01; NRuns = 1e4; coeff_unit = 0.001;
thresh_file_name = ['T-CORCONDIA Threshold\R=', num2str(R), ', M=' array2string(M),', Pfa=', num2str(Pfa),', NRuns=', num2str(NRuns),', coeff_unit=', num2str(coeff_unit),'.mat'];
if exist(thresh_file_name,'file')==2
    load(thresh_file_name);
elseif exist(thresh_file_name,'file')==0
   
    [threshold,prob] = calc_thre_coeff(M,Pfa,coeff_unit,NRuns);
    save(thresh_file_name,'threshold','prob');
else
    display('Error!')
end

seed = 10000; randn('state',seed); % for reproducibility. Change the seed for new results
NTrials = 1000;  % number of iterations per each value of p,n

SNR = -25:2.5:50;%-15:0.1:5;-0:2.5:-20:2.5:
SNR_length = length(SNR);

Khat0 = zeros(SNR_length,NTrials);
Khat1 = zeros(SNR_length,NTrials);
Khat2 = zeros(SNR_length,NTrials);
Khat3 = zeros(SNR_length,NTrials);
Khat4 = zeros(SNR_length,NTrials);
Khat5 = zeros(SNR_length,NTrials);
Khat6 = zeros(SNR_length,NTrials);
Khat7 = zeros(SNR_length,NTrials);

KhatAdapEta = zeros(SNR_length,NTrials);

barra = waitbar(0,'Running Simulations');

for nTrial = 1:NTrials
    F = cell(1,R);
    %     for r=1:R
    %         F{r} =  exp(1j*(0:M(r)-1)'*(2*pi*rand(1,K)-pi));%/sqrt(M(r));
    %     end
    
    for r=1:R
        F{r} = randn(M(r),K);%sqrt(1/2)*(randn(M(r),K) + 1j*randn(M(r),K));
    end
    
    core = nident(K,R);
    X = nmodel(F,[]);% core
    
    for SNR_index=1:SNR_length
        
        Z = sltensor_norm(X)/sqrt(prod(M))*10^(-SNR(SNR_index)/20)*randn(M);% sqrt(sigma_n/2)*(randn(M) + 1i*randn(M));
        Y = X+Z;
        
        Khat0(SNR_index,nTrial) = rank_est_CORCONDIA_basic( Y, Kmax, 12.5);
%         Khat1(SNR_index,nTrial) = rank_est_CORCONDIA_basic( Y, Kmax, 25);
%         Khat2(SNR_index,nTrial) = rank_est_CORCONDIA_basic( Y, Kmax, 50);
        Khat3(SNR_index,nTrial) = rank_est_CORCONDIA_basic( Y, Kmax, 75);
%         Khat4(SNR_index,nTrial) = rank_est_CORCONDIA_basic( Y, Kmax, 90);
%         Khat5(SNR_index,nTrial) = rank_est_CORCONDIA_basic( Y, Kmax, 95);
%         Khat6(SNR_index,nTrial) = rank_est_CORCONDIA_basic( Y, Kmax, 98);
        Khat7(SNR_index,nTrial) = rank_est_CORCONDIA_basic( Y, Kmax, 99);
        
        KhatAdapEta(SNR_index,nTrial) = rank_est_CORCONDIA_adaptive_threshold( Y, Kmax, 12.5, 99, threshold);
        
        waitbar(((nTrial-1)*SNR_length+SNR_index)/(SNR_length*NTrials),barra);
    end
%     if mod(nTrial,1)==0
        fprintf('%d / %d: done (%g s).\n',nTrial,NTrials,toc);
%     end
%     nTrial
%     pause
end
close(barra);
toc

p_CORCONDIA0 = zeros(1,SNR_length);
p_CORCONDIA1 = zeros(1,SNR_length);
p_CORCONDIA2 = zeros(1,SNR_length);
p_CORCONDIA3 = zeros(1,SNR_length);
p_CORCONDIA4 = zeros(1,SNR_length);
p_CORCONDIA5 = zeros(1,SNR_length);
p_CORCONDIA6 = zeros(1,SNR_length);
p_CORCONDIA7 = zeros(1,SNR_length);
p_CORCONDIAAdapEta = zeros(1,SNR_length);
for SNR_index=1:SNR_length
    p_CORCONDIA0(SNR_index) = length(find(Khat0(SNR_index,:)==K)) / NTrials;
    p_CORCONDIA1(SNR_index) = length(find(Khat1(SNR_index,:)==K)) / NTrials;
    p_CORCONDIA2(SNR_index) = length(find(Khat2(SNR_index,:)==K)) / NTrials;
    p_CORCONDIA3(SNR_index) = length(find(Khat3(SNR_index,:)==K)) / NTrials;
    p_CORCONDIA4(SNR_index) = length(find(Khat4(SNR_index,:)==K)) / NTrials;
    p_CORCONDIA5(SNR_index) = length(find(Khat5(SNR_index,:)==K)) / NTrials;
    p_CORCONDIA6(SNR_index) = length(find(Khat6(SNR_index,:)==K)) / NTrials;
    p_CORCONDIA7(SNR_index) = length(find(Khat7(SNR_index,:)==K)) / NTrials;
    p_CORCONDIAAdapEta(SNR_index) = length(find(KhatAdapEta(SNR_index,:)==K)) / NTrials;
end

filename = ['Matfile\R=' num2str(R),', M=' array2string(M),', K=' num2str(K),', Kmax=' num2str(Kmax),', NTrials= ', num2str(NTrials),'.mat'];
save(filename);

% figure(1);
% clf;
% plot(SNR,p_CORCONDIA0,'LineStyle','-.','Marker','^');
% hold all;
% plot(SNR,p_CORCONDIA1,'LineStyle','-','Marker','.');
% hold all;
% plot(SNR,p_CORCONDIA2,'LineStyle',':','Marker','x');
% hold all;
% plot(SNR,p_CORCONDIA3,'LineStyle','-.','Marker','>');
% hold all;
% plot(SNR,p_CORCONDIA4,'LineStyle','--','Marker','+');
% hold all;
% plot(SNR,p_CORCONDIA5,'LineStyle','-','Marker','d');
% hold all;
% plot(SNR,p_CORCONDIA6,'LineStyle',':','Marker','*');
% hold all;
% plot(SNR,p_CORCONDIA7,'LineStyle','-.','Marker','o');
% hold all;
% plot(SNR,p_CORCONDIAAdapEta,'LineStyle','--','Marker','s');
% hold off;
% xlabel('SNR (dB)');
% ylabel('Pr ($\hat{K}_{CC} = K$','interpreter','Latex');
% legend('CORCONDIA (12.5%)','CORCONDIA (25%)','CORCONDIA (50%)','CORCONDIA (75%)','CORCONDIA (90%)','CORCONDIA (95%)','CORCONDIA (98%)','CORCONDIA (99%)','CORCONDIA (Adaptive Threshold)');
% % legend('CORCONDIA (50%)','CORCONDIA (60%)','CORCONDIA (70%)','CORCONDIA (80%)','CORCONDIA (90%)','CORCONDIA (Proposed)');
% title(['R=' num2str(R),', M=' array2string(M),', K=' num2str(K),', K_{max}=' num2str(Kmax),', NTrials= ', num2str(NTrials)]);
% grid on; axis tight; % axis([SNR(1) SNR(end) 0 1]); % 
% 
% figure(2);
% clf;
% plot(SNR,p_CORCONDIA0,'LineStyle','-.','Marker','^');
% hold all;
% % plot(SNR,p_CORCONDIA1,'LineStyle','-','Marker','.');
% % hold all;
% plot(SNR,p_CORCONDIA2,'LineStyle',':','Marker','x');
% hold all;
% plot(SNR,p_CORCONDIA3,'LineStyle','-.','Marker','>');
% hold all;
% plot(SNR,p_CORCONDIA4,'LineStyle','--','Marker','+');
% hold all;
% % plot(SNR,p_CORCONDIA5,'LineStyle','-','Marker','d');
% % hold all;
% % plot(SNR,p_CORCONDIA6,'LineStyle',':','Marker','*');
% % hold all;
% plot(SNR,p_CORCONDIA7,'LineStyle','-.','Marker','o');
% hold all;
% plot(SNR,p_CORCONDIAAdapEta,'LineStyle','--','Marker','s');
% hold off;
% xlabel('SNR (dB)');
% ylabel('Pr ($\hat{K}_{CC} = K$','interpreter','Latex');
% legend('CORCONDIA (12.5%)','CORCONDIA (50%)','CORCONDIA (75%)','CORCONDIA (90%)','CORCONDIA (99%)','Proposed');
% % legend('CORCONDIA (50%)','CORCONDIA (60%)','CORCONDIA (70%)','CORCONDIA (80%)','CORCONDIA (90%)','CORCONDIA (Proposed)');
% title(['R=' num2str(R),', M=' array2string(M),', K=' num2str(K),', K_{max}=' num2str(Kmax),', NTrials= ', num2str(NTrials)]);
% grid on; axis tight; % axis([SNR(1) SNR(end) 0 1]); % 

figure(3);
clf;
set(gcf,'DefaultAxesColorOrder',[1 0 0; 0 1 0; 0 0 1; 1 0 1; 1 0 1; 1 0.6 0; 0.6 0 1; .6 0.6 0; 1 0 0.6; 0 0 0]);
plot(SNR,p_CORCONDIA0,'LineStyle','--','Marker','^');
hold all;
% plot(SNR,p_CORCONDIA1,'LineStyle','-','Marker','.');
% hold all;
% plot(SNR,p_CORCONDIA2,'LineStyle',':','Marker','x');
% hold all;
plot(SNR,p_CORCONDIA3,'LineStyle','-.','Marker','>');
hold all;
% plot(SNR,p_CORCONDIA4,'LineStyle','--','Marker','+');
% hold all;
% plot(SNR,p_CORCONDIA5,'LineStyle','-','Marker','d');
% hold all;
% plot(SNR,p_CORCONDIA6,'LineStyle',':','Marker','*');
% hold all;
plot(SNR,p_CORCONDIA7,'LineStyle',':','Marker','o');
hold all;
plot(SNR,p_CORCONDIAAdapEta,'LineStyle','-','Marker','s');
hold off;
xlabel('SNR (dB)');
ylabel('Pr ($\hat{K}_{CC}$ = $K$)','interpreter','Latex');
legend('CORCONDIA (12.5%)','CORCONDIA (75%)','CORCONDIA (99%)','Proposed');
% legend('CORCONDIA (50%)','CORCONDIA (60%)','CORCONDIA (70%)','CORCONDIA (80%)','CORCONDIA (90%)','CORCONDIA (Proposed)');
% title(['R=' num2str(R),', M=' array2string(M),', K=' num2str(K),', K_{max}=' num2str(Kmax),', NTrials= ', num2str(NTrials)]);
grid on; axis tight; % axis([SNR(1) SNR(end) 0 1]); % 

Khat = 0:Kmax+1;

Khat0_histogram = zeros(length(Khat),SNR_length+1);
Khat3_histogram = zeros(length(Khat),SNR_length+1);
Khat7_histogram = zeros(length(Khat),SNR_length+1);
KhatAdapEta_histogram = zeros(length(Khat),SNR_length+1);

for k=1:length(Khat)
    for snr_index=1:SNR_length
        Khat0_histogram(k,snr_index) = length(find(Khat0(snr_index,:)==Khat(k))) / NTrials;
        Khat3_histogram(k,snr_index) = length(find(Khat3(snr_index,:)==Khat(k))) / NTrials;
        Khat7_histogram(k,snr_index) = length(find(Khat7(snr_index,:)==Khat(k))) / NTrials;
        KhatAdapEta_histogram(k,snr_index) = length(find(KhatAdapEta(snr_index,:)==Khat(k))) / NTrials;
    end
end

SNR = [SNR 2*SNR(end)-SNR(end-1)];

figure(3+1);
clf;
[X,Y] = meshgrid(SNR, Khat);
Khat0_histogram(Khat0_histogram<=0.5/NTrials)=NaN;
pcolor(X, Y-1/2, Khat0_histogram);
shading flat; colorbar;
xlabel('SNR (dB)');
ylabel('$\hat{K}$','interpreter','latex');
% zlabel('Number of estimates');
title(['CORCONDIA (12.5%): ','M=' array2string(M),', K=' num2str(K),', NTrials= ', num2str(NTrials)]);
grid on; axis([SNR(1),SNR(end),0,Kmax+1/2]);%axis tight;

figure(3+2);
clf;
[X,Y] = meshgrid(SNR, Khat);
Khat3_histogram(Khat3_histogram<=0.5/NTrials)=NaN;
pcolor(X, Y-1/2, Khat3_histogram);
shading flat; colorbar;
xlabel('SNR (dB)');
ylabel('$\hat{K}$','interpreter','latex');
% zlabel('Number of estimates');
title(['CORCONDIA (75%): ','M=' array2string(M),', K=' num2str(K),', NTrials= ', num2str(NTrials)]);
grid on; axis([SNR(1),SNR(end),0,Kmax+1/2]);%axis tight;

figure(3+3);
clf;
[X,Y] = meshgrid(SNR, Khat);
Khat7_histogram(Khat7_histogram<=0.5/NTrials)=NaN;
pcolor(X, Y-1/2, Khat7_histogram);
shading flat; colorbar;
xlabel('SNR (dB)');
ylabel('$\hat{K}$','interpreter','latex');
% zlabel('Number of estimates');
title(['CORCONDIA (99%): ','M=' array2string(M),', K=' num2str(K),', NTrials= ', num2str(NTrials)]);
grid on; axis([SNR(1),SNR(end),0,Kmax+1/2]);%axis tight;

figure(3+4);
clf;
[X,Y] = meshgrid(SNR, Khat);
KhatAdapEta_histogram(KhatAdapEta_histogram<=0.5/NTrials)=NaN;
pcolor(X, Y-1/2, KhatAdapEta_histogram);
shading flat; colorbar;
xlabel('SNR (dB)');
ylabel('$\hat{K}$','interpreter','latex');
% zlabel('Number of estimates');
title(['Proposed: ','M=' array2string(M),', K=' num2str(K),', NTrials= ', num2str(NTrials)]);
grid on; axis([SNR(1),SNR(end),0,Kmax+1/2]);%axis tight;


Khat = 0:Kmax;

ColorOrder = [1 0 0; 0 1 0; 0 0 1; 1 0 1; 1 0 1; 1 0.6 0; 0.6 0 1; .6 0.6 0; 1 0 0.6; 0 0 0];%get(gcf,'DefaultAxesColorOrder');

[~,SNR_index] = min(abs(SNR-35));
%edge = 5;
figure(10+1);
clf;
h = hist(Khat0(SNR_index,:),Khat);
indices =0:Kmax;
bar(indices,h,0.95,'FaceColor',ColorOrder(1,:),'EdgeColor','w');
% h = findobj(gca,'Type','patch');
% set(h,'FaceColor','g','EdgeColor','w');
xlabel('$\hat{K}$','interpreter','latex');
ylabel('Number of estimates');
title(['Histogram: ','M=' array2string(M),', K=' num2str(K),', SNR= ', num2str(SNR(SNR_index)),' dB, NTrials= ', num2str(NTrials)]);
legend('CORCONDIA (12.5%)',2);
grid on; axis tight;%axis([-edge,edge,0,NTrials]);%


figure(10+2);
clf;
h = hist(Khat3(SNR_index,:),Khat);
indices =0:Kmax;
bar(indices,h,0.95,'FaceColor',ColorOrder(2,:),'EdgeColor','w');
% h = findobj(gca,'Type','patch');
% set(h,'FaceColor','g','EdgeColor','w');
xlabel('$\hat{K}$','interpreter','latex');
ylabel('Number of estimates');
title(['Histogram: ','M=' array2string(M),', K=' num2str(K),', SNR= ', num2str(SNR(SNR_index)),' dB, NTrials= ', num2str(NTrials)]);
legend('CORCONDIA (75%)',2);
grid on; axis tight;%axis([-edge,edge,0,NTrials]);%

figure(10+3);
clf;
h = hist(Khat7(SNR_index,:),Khat);
indices =0:Kmax;
bar(indices,h,0.95,'FaceColor',ColorOrder(3,:),'EdgeColor','w');
% h = findobj(gca,'Type','patch');
% set(h,'FaceColor','g','EdgeColor','w');
xlabel('$\hat{K}$','interpreter','latex');
ylabel('Number of estimates');
title(['Histogram: ','M=' array2string(M),', K=' num2str(K),', SNR= ', num2str(SNR(SNR_index)),' dB, NTrials= ', num2str(NTrials)]);
legend('CORCONDIA (99%)',2);
grid on; axis tight;%axis([-edge,edge,0,NTrials]);%

figure(10+4);
clf;
h = hist(KhatAdapEta(SNR_index,:),Khat);
indices =0:Kmax;
bar(indices,h,0.95,'FaceColor',ColorOrder(4,:),'EdgeColor','w');
% h = findobj(gca,'Type','patch');
% set(h,'FaceColor','g','EdgeColor','w');
xlabel('$\hat{K}$','interpreter','latex');
ylabel('Number of estimates');
title(['Histogram: ','M=' array2string(M),', K=' num2str(K),', SNR= ', num2str(SNR(SNR_index)),' dB, NTrials= ', num2str(NTrials)]);
legend('Proposed',2);
grid on; axis tight;%axis([-edge,edge,0,NTrials]);%