
clear all;close all;clc
tic;

N = 7; M = [7 7 N]; R = length(M);
K = 0; Kmax = 15;
SNR = -50;%-15:0.1:5;-0:2.5:

core_values = cell(1,Kmax);
for k = 1:Kmax
    core_values{k} = zeros(k,1);
end
it = zeros(1,Kmax);
err = zeros(1,Kmax);
Consistency = zeros(1,Kmax);

if K>0
    F = cell(1,R);
    for r=1:R
        F{r} = randn(M(r),K);%sqrt(1/2)*(randn(M(r),K) + 1j*randn(M(r),K));
    end
    
    core = nident(K,R);
    X = nmodel(F,[]);% core
    
    sigma_n = sltensor_norm(X)^2/prod(M)*10^(-SNR/10);
    Z = sqrt(sigma_n)*randn(M);% sqrt(sigma_n/2)*(randn(M) + 1i*randn(M));
    Y = X+Z;
else
    Y = randn(M);
end

for k = 1:Kmax%
    [Factors,it(k),err(k),Consistency(k)] = parafac(Y,k)
    for l = 1:k
        core_values{k}(l) = norm(Factors{1}(:,l));
    end
    k
%     pause
%     
    Xrec = nmodel(Factors,[]);% core
    NoiseEsti = Y - Xrec;
    err2(k) = sltensor_norm(NoiseEsti)^2
end

filename = ['Matfile\NoiseEst_vs_Khat\R=' num2str(R),', M=' array2string(M),', K=' num2str(K),', SNR=' num2str(SNR),'dB.mat'];
save(filename);

% figure(1);
% clf;
% plot(1:Kmax,err2/prod(M),'LineStyle','-.','LineWidth',2,'Marker','s','Color',[1 0 0]);
% hold on
% plot(1:Kmax,sigma_n*ones(1,Kmax),'k.-','LineWidth',2);
% hold off
% legend('Estimate','True');
% xlabel('$\hat{K}$','interpreter','Latex');
% ylabel('Noise Power');
% title(['Estimated Noise Power versus Khat: R=' num2str(R),', M=' array2string(M),', K=' num2str(K),', SNR=' num2str(SNR),' dB']);
% grid on; axis tight; % axis([1 Kmax 0 2*sigma_n]); % 
% 
% ratio = abs(err/prod(M)-sigma_n)/sigma_n;
% figure(2);
% clf;
% plot(1:Kmax,ratio,'k.-','LineWidth',2);
% xlabel('$\hat{K}$','interpreter','Latex');
% ylabel('Relative Error');
% title(['Estimate Relative Error: R=' num2str(R),', M=' array2string(M),', K=' num2str(K),', SNR=' num2str(SNR),' dB']);
% grid on; axis tight; % axis([1 Kmax 0 1]); %

figure(3);
clf;
plot(1:Kmax,Consistency,'k.-','LineWidth',2);
xlabel('$\hat{K}$','interpreter','Latex');
ylabel('Consistency (%)');
title(['Consistency Curve: R=' num2str(R),', M=' array2string(M),', K=' num2str(K),', SNR=' num2str(SNR),' dB']);
grid on; axis tight; % axis([SNR(1) SNR(end) 0 1]); %

% close all;
for k = Kmax %1:
    figure;
    clf;
    plot(1:k,core_values{k},'k.-','LineWidth',2);
    xlabel('index');
    ylabel('Core Values');
    title(['Core Values: R=' num2str(R),', M=' array2string(M),', K=' num2str(K),', K_{hat}=' num2str(k),', SNR=' num2str(SNR),' dB']);
    grid on; axis tight; % axis([SNR(1) SNR(end) 0 1]); %
end