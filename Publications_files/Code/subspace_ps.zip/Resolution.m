clc
clear all
close all
%================================================================
% Parameters Setting
%================================================================
% Frequencies
w1 = [0.1*pi, 0.25*pi, 0.4*pi];   % component 1
w2 = [0.25*pi, 0.4*pi, 0.1*pi];   % component 2

w = [w1; w2];
%=================================================================
A = [1  exp(1j*0.3*pi)];   % amplitude
phi = angle(A);                 % phase
K= length(A);                   % Component number
%=================================================================
% Sampling setting
M1 = 15;     % Dim1
M2 = 15;     % Dim2
M3 = 15;     % Dim3

Q = M1*M2*M3;     % Snapshot Number
%========================================================
snr = 10;
test_num = 200;

P = 30;
tol = 0.01;
Delta = (0:P-1)*tol;
delta = w(1,1) + Delta*pi;
P = length(delta);
%===============================================================
mse_f1  = zeros(K, 3, P);       % Root MUSIC
mse_f2  = zeros(K, 3, P);       % FB Root MUSIC
mse_f3  = zeros(K, 3, P);       % IMDF
mse_f4  = zeros(K, 3, P);       % HOSVD
mse_f5  = zeros(K, 3, P);       % Theory MSE

CRLB_1 = zeros(K,P);       CRLB_2 = zeros(K,P);      CRLB_3 = zeros(K,P);
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Runtime1 = 0;
Runtime2 = 0;
Runtime3 = 0;
Runtime4 = 0;
%===============================================================

for k_delta = 1:length(delta)
    w(2,1) = delta(k_delta);
    Signal_data = zeros(M1, M2,M3);
    for m1=1: M1
        for m2 =1: M2
            for m3 =1: M3
                m = [m1; m2; m3];
                Signal_data(m1, m2, m3) =  A* exp(1j*w*m);
            end
        end
    end
    Signal_power = sum(sum(sum(abs(Signal_data).^2)))/Q;
    %==============================================================
    error_f1 = 0;    % Root-MUSIC
    error_f2 = 0;    % FB Root-MUSIC
    error_f3 = 0;    % IMDF
    error_f4 = 0;    % HOSVD
    error_f5 = 0;    % Theory MSE
    
    for k_test = 1 : test_num
        fprintf('k_delta=%d\t k_test=%d\n',k_delta,k_test)
        %==============================================================
        % Add noise
        Noise_power = Signal_power*10^(-snr/10);
        Signal = Signal_data+sqrt(Noise_power/2)*(randn(M1, M2, M3)+1j*randn(M1, M2, M3));
        %==============================================================
        % Alogrithms comparation
        %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        % Root-MUSIC
        tic;
        f1 = MD_RootMUSIC3D(Signal,K);
        s = toc;
        Runtime1 = Runtime1 + s;
        fprintf('Root-MUSIC done\n')
        %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        % FB Root-MUSIC
        tic;
        f2 = MD_FB_RootMUSIC(Signal, K);
        s = toc;
        Runtime2 = Runtime2+s;
        fprintf('FB Root-MUSIC done\n')
        %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        % IMDF
        tic;
        f3 = IMDF_3D(Signal, K);
        s = toc;
        Runtime3 = Runtime3 + s;
        fprintf('IMDF done\n')
        %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        % HOSVD
        tic;
        f4 = HOSVD_3D(Signal, K);
        s = toc;
        Runtime4 = Runtime4 + s;
        fprintf('HOSVD done\n')
        %=============================================================
        % Error accumulation
        %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        error_f1 = error_f1 + (w - f1).^2;    % Root MUSIC
        error_f2 = error_f2 + (w - f2).^2;    % FB Root MUSIC
        error_f3 = error_f3 + (w - f3).^2;    % IMDF
        error_f4 = error_f4 + (sort(w) - f4).^2;    % HOSVD
        
    end
    %===============================================================
    % MSE of each SNR
    %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    mse_f1(:, :,  k_delta) = error_f1 / test_num;
    mse_f2(:, :,  k_delta) = error_f2 / test_num;
    mse_f3(:, :, k_delta) =  error_f3 / test_num;
    mse_f4(:, :, k_delta) =  error_f4 / test_num;
    
    %==============================================================
    % Theory MSE
    %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    mse_f5(:, :, k_delta) =  theoryMSE_3D(Signal_data, A, w, M1, M2,M3, Noise_power);
    %==============================================================
    % CRLB
    %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    CRLB = CRB3D(w, M1, M2, M3, A, Noise_power);
    CRLB_1(:, k_delta) = CRLB(1:K);
    CRLB_2(:, k_delta) = CRLB (K+1:2*K);
    CRLB_3(:, k_delta) = CRLB (2*K+1:3*K);
    %==============================================================
end
%================================================================
% Alogrithms run time comparation
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Time_RootMUSIC = Runtime1/(test_num*P)
% Time_FB_RootMUSIC = Runtime2/(test_num*P)
% Time_MD_IMDF = Runtime3/(test_num*P)
% Time_HOSVD = Runtime4/(test_num*P)
%================================================================
% Simulation results
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Legend Location
Location = 1;

% Dimension 1
figure(8)
hold on
grid on
plot(Delta, 10*log10(squeeze(mean(mse_f1(:, 1, :)))),'*')     %Root-MUSIC
plot(Delta,10*log10(squeeze(mean(mse_f2(:, 1, :)))),'or')    % FB Root-MUSIC
plot(Delta,10*log10(squeeze(mean(mse_f3(:, 1, :)))),'^m')   % IMDF
plot(Delta,10*log10(squeeze(mean(mse_f4(:, 1, :)))), 's', 'color', [0 .75 .75])     % HOSVD
plot(Delta,10*log10(squeeze(mean(mse_f5(:, 1, :)))), '--r')    % Theory MSE (38)
plot(Delta,10*log10(mean(CRLB_1)),'g-')
xlabel('Dimension1 frequency separation (\omega/\pi)   SNR=10dB')
ylabel('AMSE_1 (dB)');
xlim([min(Delta),max(Delta)])
legend('root MUSIC', 'FB root-MUSIC',  'IMDF', 'HOSVD', '(38)', 'CRLB', Location)
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Dimension 2
figure(9)
hold on
grid on
plot(Delta, 10*log10(squeeze(mean(mse_f1(:, 2, :)))),'*')     %Root-MUSIC
plot(Delta,10*log10(squeeze(mean(mse_f2(:, 2, :)))),'or')    % FB Root-MUSIC
plot(Delta,10*log10(squeeze(mean(mse_f3(:, 2, :)))),'^m')   % IMDF
plot(Delta,10*log10(squeeze(mean(mse_f4(:, 2, :)))), 's', 'color', [0 .75 .75])     % HOSVD
plot(Delta,10*log10(squeeze(mean(mse_f5(:, 2, :)))), '--r')    % Theory MSE (39)
plot(Delta,10*log10(mean(CRLB_2)),'g-')
xlabel('Dimension1 frequency separation (\omega/\pi)   SNR=10dB')
ylabel('AMSE_2 (dB)');
xlim([min(Delta),max(Delta)])
legend('root MUSIC', 'FB root-MUSIC',  'IMDF', 'HOSVD', '(39)', 'CRLB', Location)
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Dimension 3
figure(10)
hold on
grid on
plot(Delta, 10*log10(squeeze(mean(mse_f1(:, 3, :)))),'*')     %Root-MUSIC
plot(Delta,10*log10(squeeze(mean(mse_f2(:, 3, :)))),'or')    % FB Root-MUSIC
plot(Delta,10*log10(squeeze(mean(mse_f3(:, 3, :)))),'^m')   % IMDF
plot(Delta,10*log10(squeeze(mean(mse_f4(:, 3, :)))), 's', 'color', [0 .75 .75])     % HOSVD
plot(Delta,10*log10(squeeze(mean(mse_f5(:, 3, :)))), '--r')    % Theory MSE (39)
plot(Delta,10*log10(mean(CRLB_3)),'g-')
xlabel('Dimension1 frequency separation (\omega/\pi)   SNR=10dB')
ylabel('AMSE_3 (dB)');
xlim([min(Delta),max(Delta)])
legend('root MUSIC', 'FB root-MUSIC',  'IMDF', 'HOSVD', '(39)', 'CRLB', Location)
%==========================================================================
save(strcat('3D_Resolution_w1_', 'SNR=', num2str(snr), 'dB', '_', date))


