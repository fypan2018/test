function MSE = theoryMSE_4D(Signal_data, A, w, M1, M2, M3, M4, Noise_power)

K = length(A);
MSE = zeros(K, 4);

R1 = 0;
for m3 = 1:M3
    for m4 = 1: M4
        R1 = R1 + squeeze(Signal_data(:, :, m3, m4))*squeeze(Signal_data(:, :, m3, m4))';
    end
end
R1 = R1/(M3*M4) + Noise_power*eye(M1);
J = flipud(eye(M1));
R1 = 1/2*(R1+ J*R1.''*J) ;
[u, s0] = svd(R1);
Us = u(:,1: K);
Un = u(:, K+1: end);
s = diag(s0(1: K, 1: K));

for k = 1: K
    a = exp(1j*w(k, 1)*(1:M1)');
    da = 1j*(1:M1)'.*a;
    MSE(k, 1) =  Noise_power*(s./ (s - Noise_power).^2).' * (abs(Us' * a).^2)/...
        (2*(M3*M4)*da'*(Un*Un') *da);
end
%===============================================================
% Second Dimension
G = exp(1i*(1:M1)'*w(:,1)');
for k = 1:K
    Gt = G;
    Gt(:,k) = [];
    Pt = eye(M1)-Gt/(Gt'*Gt)*Gt';
    Rt = 0;
    for m3 = 1:M3
        for m4 = 1: M4
            Xt=Pt*(squeeze(Signal_data(:, :, m3, m4)));
            Rt=Rt+Xt'*Xt;
        end
    end
    Rt=Rt/(M3*M4) + Noise_power*eye(M2);
    J = flipud(eye(M2));
    Rt = 1/2*(Rt+ J*Rt.''*J);
    [u,s] = svd(Rt);
    Us = u(:,1);
    Un = u(:, 2: end);
    s = s(1,1);
    a = exp(-1j*w(k, 2)*(1:M2)');
    da = 1j*(1:M2)'.*a;
    MSE(k, 2) =  Noise_power*(s./ (s - Noise_power).^2).' * (abs(Us' * a).^2)/...
        (2*(M3*M4) *da'*(Un*Un') *da);
end
% Third Dimension
for k = 1:K
    Gt =G;
    Gt(:,k) = [];
    Pt = eye(M1)-Gt/(Gt'*Gt)*Gt';
   Rt=0;
    for m2=1:M2
        for m4 = 1: M4
            Xt=Pt*squeeze(Signal_data(:, m2, :, m4));
            Rt=Rt+Xt'*Xt;
        end
    end
    Rt=Rt/(M2*M4)+ Noise_power*eye(M3);
    J = flipud(eye(M3));
    Rt = 1/2*(Rt+ J*Rt.''*J);
    [u,s] = svd(Rt);
    Us = u(:,1);
    Un = u(:, 2: end);
    s = s(1,1);
    a = exp(-1j*w(k, 3)*(1:M3)');
    da = 1j*(1:M3)'.*a;
    MSE(k, 3) =  Noise_power*(s./ (s - Noise_power).^2).' * (abs(Us' * a).^2)/...
        (2*(M2*M4)*da'*(Un*Un') *da);
end
% Fourth Dimension
for k = 1:K
    Gt =G;
    Gt(:,k) = [];
    Pt = eye(M1)-Gt/(Gt'*Gt)*Gt';
   Rt=0;
    for m2=1:M2
        for m3 = 1: M3
            Xt=Pt*squeeze(Signal_data(:, m2, m3, :));
            Rt=Rt+Xt'*Xt;
        end
    end
    Rt=Rt/(M2*M3)+ Noise_power*eye(M4);
    J = flipud(eye(M4));
    Rt = 1/2*(Rt+ J*Rt.''*J);
    [u,s] = svd(Rt);
    Us = u(:,1);
    Un = u(:, 2: end);
    s = s(1,1);
    a = exp(-1j*w(k, 4)*(1:M4)');
    da = 1j*(1:M4)'.*a;
    MSE(k, 4) =  Noise_power*(s./ (s - Noise_power).^2).' * (abs(Us' * a).^2)/...
        (2*(M2*M3)*da'*(Un*Un') *da);
end
end


