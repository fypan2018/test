clc
close all
clear all

load 3D_Resolution_w1_151515_18-Mar-2012
%================================================================
% Simulation results
display('-------------------------------------------------------------------------------------')
display('MD frequency estimation computational time comparation')
display('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
fprintf('f1 = [ %f  %f  %f ]\n', w1/pi)
fprintf('f2 = [ %f  %f  %f ]\n', w2/pi)
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Legend Location
Location = 1;
%================================================================
% Simulation results
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Dimension 1
figure(8)
hold on
grid on
plot(Delta, 10*log10(squeeze(mean(mse_f1(:, 1, :)))),'*')     %Root-MUSIC
plot(Delta,10*log10(squeeze(mean(mse_f2(:, 1, :)))),'or')    % FB Root-MUSIC
plot(Delta,10*log10(squeeze(mean(mse_f3(:, 1, :)))),'^m')   % IMDF
plot(Delta,10*log10(squeeze(mean(mse_f4(:, 1, :)))), 's', 'color', [0 .75 .75])     % HOSVD
plot(Delta,10*log10(squeeze(mean(mse_f5(:, 1, :)))), '--r')    % Theory MSE (38)
plot(Delta,10*log10(mean(CRLB_1)),'g-')
xlabel('Dimension1 frequency separation (\omega/\pi)   SNR=10dB')
ylabel('AMSE_1 (dB)');
xlim([min(Delta),max(Delta)])
legend('root MUSIC', 'FB root-MUSIC',  'IMDF', 'HOSVD', '(38)', 'CRLB', Location)
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Dimension 2
figure(9)
hold on
grid on
plot(Delta, 10*log10(squeeze(mean(mse_f1(:, 2, :)))),'*')     %Root-MUSIC
plot(Delta,10*log10(squeeze(mean(mse_f2(:, 2, :)))),'or')    % FB Root-MUSIC
plot(Delta,10*log10(squeeze(mean(mse_f3(:, 2, :)))),'^m')   % IMDF
plot(Delta,10*log10(squeeze(mean(mse_f4(:, 2, :)))), 's', 'color', [0 .75 .75])     % HOSVD
plot(Delta,10*log10(squeeze(mean(mse_f5(:, 2, :)))), '--r')    % Theory MSE (39)
plot(Delta,10*log10(mean(CRLB_2)),'g-')
xlabel('Dimension1 frequency separation (\omega/\pi)   SNR=10dB')
ylabel('AMSE_2 (dB)');
xlim([min(Delta),max(Delta)])
legend('root MUSIC', 'FB root-MUSIC',  'IMDF', 'HOSVD', '(39)', 'CRLB', Location)
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Dimension 3
figure(10)
hold on
grid on
plot(Delta, 10*log10(squeeze(mean(mse_f1(:, 3, :)))),'*')     %Root-MUSIC
plot(Delta,10*log10(squeeze(mean(mse_f2(:, 3, :)))),'or')    % FB Root-MUSIC
plot(Delta,10*log10(squeeze(mean(mse_f3(:, 3, :)))),'^m')   % IMDF
plot(Delta,10*log10(squeeze(mean(mse_f4(:, 3, :)))), 's', 'color', [0 .75 .75])     % HOSVD
plot(Delta,10*log10(squeeze(mean(mse_f5(:, 3, :)))), '--r')    % Theory MSE (39)
plot(Delta,10*log10(mean(CRLB_3)),'g-')
xlabel('Dimension1 frequency separation (\omega/\pi)   SNR=10dB')
ylabel('AMSE_3 (dB)');
xlim([min(Delta),max(Delta)])
legend('root MUSIC', 'FB root-MUSIC',  'IMDF', 'HOSVD', '(39)', 'CRLB', Location)
%==========================================================================