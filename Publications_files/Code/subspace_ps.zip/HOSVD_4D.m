function w = HOSVD_4D(Signal, F)
%================================================
% An Eigenvector-Based Approach for Multidimensional 
% Frequency Estimation With Improved Identifiability
% Signal: data matrix
% F: number of signal components
% f1: frequency estimate in first dimension
% f2: frequency estimate in second dimension
% f3: frequency estimate in third dimension
% f4: frequency estimate in fourth dimension
% alpha: amplitude estimate
% 2011.04.05
%=================================================
M=size(Signal);           
R=length(M);                
X=tensor(Signal);
L=ceil(M/2);
Msub=M-L+1;

Ys=tenzeros([Msub prod(L)]);
i=1;
for l4=1:L(4)
    for l3=1:L(3)
        for l2=1:L(2)
            for l1=1:L(1)
                J={ };
                l=[l1 l2 l3 l4];
                for r=1:R
                    J=[J, [ zeros(Msub(r), l(r)-1) eye(Msub(r)) zeros(Msub(r), L(r)-l(r))] ];
                end
                Ys(:,:,:,:,i)=ttensor(X,J);
                i=i+1;
            end
        end
    end
end
Y= tucker_als(Ys, [Msub prod(L)],'printitn',0);
core=tensor(Y.core(1:F,1:F,1:F,1:F,1:F));
U={Y.U{1}(:,1:F), Y.U{2}(:,1:F), Y.U{3}(:,1:F) Y.U{4}(:,1:F) Y.U{5}(:,1:F)};
S=ttensor(core,U);
Us=tensor(S);
M=size(Us);

U0=double(reshape(permute(Us,[R+1:-1:1]), [M(R+1), prod(M(1:R))]));
w=zeros(F,R);
for r=1:R
     J1=kron(kron(eye(prod(Msub(1:r-1))), [ eye(Msub(r)-1) zeros(Msub(r)-1,1)]), eye(prod(Msub(r+1:end))));
     J2=kron(kron(eye(prod(Msub(1:r-1))), [ zeros(Msub(r)-1,1) eye(Msub(r)-1) ]), eye(prod(Msub(r+1:end))));
     Phi=pinv(J1*U0.')*J2*U0.';
     [~,s]=eig(Phi);
     w(:,r)=sort(angle(diag(s(1:F,1:F))));
end
end