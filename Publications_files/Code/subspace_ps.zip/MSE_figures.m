clc
close all
clear all
warning off
% load 3D_MSE1_151515_26-Mar-2012; Location = 1;    % 3D distinct freq
% load 3D_MSE2_151515_26-Mar-2012 ;  Location = 3;   % 3D identical freq
load 4D_MSE1_15777_28-Mar-2012; Location = 1;         % 4D
%================================================================
display('-------------------------------------------------------------------------------------')
display('MD Frequency estimation MSE')
display('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
if length(w1) == 3
    fprintf('f1 = [ %f  %f  %f ]\n', w1/pi)
    fprintf('f2 = [ %f  %f  %f ]\n', w2/pi)
    fprintf('f3 = [ %f  %f  %f ]\n', w3/pi)
    T = 0;
end

if length(w1) == 4
    fprintf('f1 = [ %f  %f  %f  %f ]\n', w1/pi)
    fprintf('f2 = [ %f  %f  %f  %f ]\n', w2/pi)
    fprintf('f3 = [ %f  %f  %f  %f ]\n', w3/pi)
    T = 1;
end
%================================================================
% Simulation results
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
for k = 1: length(w1)
    figure(10*T+k)
    hold on
    grid on
    
    plot(SNR, 10*log10(squeeze(mean(mse_f1(:, k, :)))),'*')     % Root-MUSIC
    plot(SNR,10*log10(squeeze(mean(mse_f2(:, k, :)))),'or')    % FB Root-MUSIC
    plot(SNR,10*log10(squeeze(mean(mse_f3(:, k, :)))),'^m')     % IMDF
    plot(SNR,10*log10(squeeze(mean(mse_f4(:, k, :)))), 's', 'color', [0 .75 .75])     % HOSVD
    plot(SNR,10*log10(squeeze(mean(mse_f5(:, k, :)))), '--r')    % Theory MSE
    plot(SNR,10*log10(mean(eval(strcat('CRLB_', num2str(k))))),'g-')
    xlabel('SNR (dB)')
    ylabel(strcat('AMSE_', num2str(k), '(dB)'));
    if k >1
        legend('root MUSIC', 'FB root-MUSIC',  'IMDF', 'HOSVD', '(39)', 'CRLB', Location)
    else
        legend('root MUSIC', 'FB root-MUSIC',  'IMDF', 'HOSVD', '(38)', 'CRLB', Location)
    end
end
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
