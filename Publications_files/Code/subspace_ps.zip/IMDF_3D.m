function f = IMDF_3D(X, P)

[N1, N2, N3]=size(X);

K1=round(N1/2);
K2=round(N2/2);
K3=round(N3/2);

L1=N1-K1;
L2=N2-K2+1;
L3=N3-K3+1;

X1=X(1:end-1, :, :);
X2=X(2:end, :, :);
X1s=IMDFS3(X1, N1-1, N2, N3, K1, K2, K3);
X2s=IMDFS3(X2, N1-1, N2, N3, K1, K2, K3);

[LL1,LL2]=size(X1s);
x1s=reshape(X1s, LL1*LL2, 1);
x2s=reshape(X2s, LL1*LL2, 1);
y1s=conj(x1s(end:-1:1));
y2s=conj(x2s(end:-1:1));
Y1s=reshape(y2s, LL1, LL2);
Y2s=reshape(y1s, LL1, LL2);


Z1=[X1s; Y1s];
Z2=[X2s; Y2s];
Z=[Z1; Z2];

[U, S, V]=svd(Z);
Us=U(:, 1:P);
Ss=S(1:P, 1:P);
Vs=V(:, 1:P);
[UM, ~]=size(U);
U1=Us(1:UM/2, :);
U2=Us(UM/2+1:end, :);
[Tsp, ~]=eig((U1'*U1)\U1'*U2);
HK=Us*Tsp;
HL=(Tsp\Ss*Vs').';
Ka=K1*K2*K3;
La=L1*L2*L3;

w1o=zeros(1,P);w2o=zeros(1,P);w3o=zeros(1,P);
for p=1:P
    w=[];
    for inp=1:4
        HKn=HK((inp-1)*Ka+1:inp*Ka, p);
        for ik=K2*K3+1:Ka
            w=[w, HKn(ik)/HKn(ik-K2*K3)];
        end
    end
    for il=L2*L3+1:La
        w=[w, HL(il, p)/HL(il-L2*L3, p)];
    end
    w1o(p)=angle(mean(w));
  %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  
    w=[];
    for inp=1:4*K1
        HKn=HK((inp-1)*K2*K3+1:inp*K2*K3, p);
        for ik=K3+1:K2*K3
            w=[w, HKn(ik)/HKn(ik-K3)];
        end
    end
    for inp=1:L1
        HLn=HL((inp-1)*L2*L3+1:inp*L2*L3, p);
    for il=L3+1:L2*L3
        w=[w, HLn(il)/HLn(il-L3)];
    end
    end
    w2o(p)=angle(mean(w));
    %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    w=[];
    for inp=1:4*K1*K2
        HKn=HK((inp-1)*K3+1:inp*K3, p);
        for ik=2:K3
            w=[w, HKn(ik)/HKn(ik-1)];
        end
    end
    for inp=1:L1*L2
        HLn=HL((inp-1)*L3+1:inp*L3, p);
    for il=2:L3
        w=[w, HLn(il)/HLn(il-1)];
    end
    end
    w3o(p)=angle(mean(w));
end

[f(:, 1), index]=sort(w1o);
f(:, 2) = w2o(index);
f(:, 3) = w3o(index);
end
function Z=IMDFS3(X, N1, N2, N3, K1, K2, K3)

L1=N1-K1+1;
L2=N2-K2+1;
L3=N3-K3+1;

for i1=1:L1
    X1(:,:,:,i1)=X(i1:N1-L1+i1,:,:);
end
for i2=1:L2
    X2(:,:,:,:,i2)=X1(:,i2:N2-L2+i2,:,:);
end
for i3=1:L3
    Y(:,:,:,:,:,i3)=X2(:,:,i3:N3-L3+i3,:,:);
end

Y2=permute(Y, [3,2,1,6,5,4]);

Z=reshape(Y2, K1*K2*K3, L1*L2*L3);

end

