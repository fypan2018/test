clc
clear all
close all
warning off

%================================================================
% Parameters Setting
%================================================================

% Frequencies
w1 = [0.1*pi, 0.25*pi, 0.4*pi];   % component 1
w2 = [0.24*pi, 0.4*pi, 0.1*pi];   % component 2
w3 = [0.4*pi, 0.1*pi, 0.25*pi];   % component 3

w = [w1; w2; w3];
%=================================================================
A = [1  exp(1j*0.3*pi)  exp(1j*0.5*pi)];   % amplitude
phi = angle(A);                 % phase
K= length(A);                   % Component number
%=================================================================

Cubic = 8 :1 :16;
test_num = 200;
P = length(Cubic);
snr = 10;

Runtime1=zeros(P,1);
Runtime2=zeros(P,1);
Runtime3=zeros(P,1);
Runtime4=zeros(P,1);
%==================================================================
for k_cubic=1:P;
    for k_test=1:test_num
        fprintf('Cubic=%d\t k_test=%d\n',Cubic(k_cubic),k_test)
        M1=Cubic(k_cubic);  M2=Cubic(k_cubic); M3=Cubic(k_cubic);
        Q = M1*M2*M3;     % Snapshot Number
        %==============================================================
        Signal_data = zeros(M1, M2,M3);
        for m1=1: M1
            for m2 =1: M2
                for m3 =1: M3
                    m = [m1; m2; m3];
                    Signal_data(m1, m2, m3) =  A* exp(1j*w*m);
                end
            end
        end
        Signal_power = sum(sum(sum(abs(Signal_data).^2)))/Q;
        %==============================================================
        % Add noise
        Noise_power = Signal_power*10^(-snr/10);
        Signal = Signal_data+sqrt(Noise_power/2)*(randn(M1, M2, M3)+1j*randn(M1, M2, M3));
        %==============================================================
        % Alogrithms comparation
        %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        % Root-MUSIC
        tic;
        f1 = MD_RootMUSIC3D(Signal,K);
        s = toc;
        Runtime1(k_cubic) = Runtime1(k_cubic) + s;
        fprintf('Root-MUSIC done\n')
        %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        % FB Root-MUSIC
        tic;
        f2 = MD_FB_RootMUSIC(Signal, K);
        s = toc;
        Runtime2(k_cubic) = Runtime2(k_cubic) + s;
        fprintf('FB Root-MUSIC done\n')
        %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        % IMDF
        tic;
        f3 = IMDF_3D(Signal, K);
        s = toc;
        Runtime3(k_cubic)=Runtime3(k_cubic)+s;
        fprintf('IMDF done\n')
        %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        %HOSVD
        tic;
        f4 = HOSVD_3D(Signal, K);
        s = toc;
        Runtime4(k_cubic) = Runtime4(k_cubic) + s;
        fprintf('HOSVD done\n')
        %=============================================================
        
    end
    %==============================================================
    
end
%============================================================
Time1 = Runtime1 /test_num ;
Time2= Runtime2 /test_num ;
Time3= Runtime3 /test_num ;
Time4= Runtime4 /test_num ;
%=============================================================
figure(7)
axes1 = axes('YScale','log','YMinorTick','on');
hold(axes1,'all');
plot(Cubic, Time1 ,'*')  %Root-MUSIC
plot(Cubic, Time2 ,'ro') % FB Root-MUSIC
plot(Cubic, Time3 ,'^m') %IMDF
plot(Cubic, Time4 ,'s','color',   [0 .75 .75]) % HOSVD
xlabel('M_1 (M_1=M_2=M_3)')
ylabel('Runtime (Second)');
legend('root MUSIC', 'FB root-MUSIC',  'IMDF', 'HOSVD', 2)
%===========================================================
save(strcat('3D_Runtime_', num2str(M1), num2str(M2), num2str(M3), '_', date))

