
clc
clear all
close all
warning off

%================================================================
% Parameters Setting
%================================================================

% Frequencies
w1 = [0.1, 0.25, 0.4, 0.1]*pi;   % component 1
w2 = [0.25, 0.4, 0.4, 0.1]*pi;    % component 2
w3 = [0.4, 0.25, 0.45, 0.15]*pi;    % component 3
w = [w1; w2; w3];
%=================================================================
A = [1  exp(1j*0.3*pi)  exp(1j*0.5*pi)];   % amplitude
phi = angle(A);                 % phase
K= length(A);                   % Component number
%=================================================================
% Sampling setting
M1 = 15;    % Dim1
M2 = 7;      % Dim2
M3 = 7;      % Dim3
M4 = 7;      % Dim4

Q = M1*M2*M3*M4;     % Snapshot Number
Steering = 0:0.001*pi:pi;
%=================================================================
Signal_data = zeros(M1, M2,M3);
for m1=1: M1
    for m2 =1: M2
        for m3 =1: M3
            for m4 = 1: M4
                m = [m1; m2; m3; m4];
                Signal_data(m1, m2, m3, m4) =  A* exp(1j*w*m);
            end
        end
    end
end
Signal_power = mean(abs(Signal_data(:)).^2);
%===============================================================
% Simulation setting
SNR = -10: 5: 30;
test_num = 200;
P = length(SNR);
%===============================================================
mse_f1  = zeros(K, 4, P);       % Root MUSIC
mse_f2  = zeros(K, 4, P);       % FB Root MUSIC
mse_f3  = zeros(K, 4, P);       % IMDF
mse_f4  = zeros(K, 4, P);       % HOSVD
mse_f5  = zeros(K, 4, P);       % Theory MSE

CRLB_1 = zeros(K,P);   CRLB_2 = zeros(K,P);
CRLB_3 = zeros(K,P);   CRLB_4 = zeros(K,P);
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Runtime1 = 0;
Runtime2 = 0;
Runtime3 = 0;
Runtime4 = 0;
%===============================================================
for k_snr = 1:length(SNR)
    snr = SNR(k_snr);
    %==============================================================
    % Starting a new SNR
    error_f1 = 0;    % Root-MUSIC
    error_f2 = 0;    % FB Root-MUSIC
    error_f3 = 0;    % IMDF
    error_f4 = 0;    % HOSVD
    error_f5 = 0;    % Theory MSE
    
    for k_test = 1 : test_num
        fprintf('snr=%d\t k_test=%d\n',snr,k_test)
        %==============================================================
        % Add noise
        Noise_power = Signal_power*10^(-snr/10);
        Signal = Signal_data+sqrt(Noise_power/2)*(randn(M1, M2, M3, M4)+1j*randn(M1, M2, M3, M4));
        
        %==============================================================
        % Alogrithms comparation
        %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        % Root-MUSIC
        tic;
        f1 = MD_RootMUSIC4D(Signal,K);
        s = toc;
        Runtime1 = Runtime1 + s;
        fprintf('Root-MUSIC done\n')
        %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        % FB Root-MUSIC
        tic;
        f2 = MD_FB_RootMUSIC4D(Signal, K);
        s = toc;
        Runtime2 = Runtime2+s;
        fprintf('FB Root-MUSIC done\n')
        %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        % IMDF
        tic;
        f3 = IMDF_4D(Signal, K);
        s = toc;
        Runtime3 = Runtime3 + s;
        fprintf('IMDF done\n')
        %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        % HOSVD
        tic;
        f4 = HOSVD_4D(Signal, K);
        s = toc;
        Runtime4 = Runtime4 + s;
        fprintf('HOSVD done\n')
        %=============================================================
        % Error accumulation
        %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        error_f1 = error_f1 + (w - f1).^2;    % Root MUSIC
        error_f2 = error_f2 + (w - f2).^2;    % FB Root MUSIC
        error_f3 = error_f3 + (w - f3).^2;    % IMDF
        error_f4 = error_f4 + (sort(w) - f4).^2;    % HOSVD
    end
    %===============================================================
    % MSE of each SNR
    %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    mse_f1(:, :,  k_snr) = error_f1 / test_num;
    mse_f2(:, :,  k_snr) = error_f2 / test_num;
    mse_f3(:, :, k_snr) =  error_f3 / test_num;
    mse_f4(:, :, k_snr) =  error_f4 / test_num;
    
    %==============================================================
    % Theory MSE
    %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    mse_f5(:, :, k_snr) =  theoryMSE_4D(Signal_data, A, w, M1, M2,M3, M4, Noise_power);
    %==============================================================
    % CRLB
    %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    CRLB = CRLB_4D(A, w, phi, M1, M2, M3, M4, Noise_power);
    CRLB_1(:, k_snr) = CRLB(1: K);
    CRLB_2(:, k_snr) = CRLB (K+1: 2*K);
    CRLB_3(:, k_snr) = CRLB (2*K+1: 3*K);
    CRLB_4(:, k_snr) = CRLB (3*K+1: 4*K);
    %==============================================================
end
%================================================================
% Alogrithms run time comparation
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Time_RootMUSIC = Runtime1/(test_num*P)
Time_FB_RootMUSIC = Runtime2/(test_num*P)
Time_MD_IMDF = Runtime3/(test_num*P)
Time_HOSVD = Runtime4/(test_num*P)
%================================================================
% Simulation results
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Dimension 1
Location = 1;
for k = 1: length(w1)
    figure(10+k)
    hold on
    grid on
    
    plot(SNR, 10*log10(squeeze(mean(mse_f1(:, k, :)))),'*')     % Root-MUSIC
    plot(SNR,10*log10(squeeze(mean(mse_f2(:, k, :)))),'or')    % FB Root-MUSIC
    plot(SNR,10*log10(squeeze(mean(mse_f3(:, k, :)))),'^m')    % IMDF
    plot(SNR,10*log10(squeeze(mean(mse_f4(:, k, :)))), 's', 'color', [0 .75 .75])     % HOSVD
    plot(SNR,10*log10(squeeze(mean(mse_f5(:, k, :)))), '--r')    % Theory MSE
    plot(SNR,10*log10(mean(eval(strcat('CRLB_', num2str(k))))),'g-')
    xlabel('SNR (dB)')
    ylabel(strcat('AMSE_', num2str(k), '(dB)'));
    if k >1
        legend('root MUSIC', 'FB root-MUSIC',  'IMDF', 'HOSVD', '(39)', 'CRLB', Location)
    else
        legend('root MUSIC', 'FB root-MUSIC',  'IMDF', 'HOSVD', '(38)', 'CRLB', Location)
    end
end
% %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
save(strcat('4D_MSE_', num2str(M1), num2str(M2), num2str(M3), num2str(M4), '_', date))



