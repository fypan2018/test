function F = CRLB_4D(A, w, phi, N1, N2,N3,N4, sigma2)

n1 = 1:N1;
n2 = 1:N2;
n3 = 1:N3;
n4 = 1:N4;
M = length(A);

T1  = n1'*ones(1, M);
T2  = n2'*ones(1, M);
T3  = n3'*ones(1, M);
T4  = n4'*ones(1, M);

U = exp(1i*n1'*w(:, 1)');
V = exp(1i*n2'*w(:, 2)');
W = exp(1i*n3'*w(:, 3)');
Y = exp(1i*n4'*w(:, 4)');
B = (A.*exp(1i*phi)).';

% dA = khatri(V, U)*diag(exp(1i*phi));
% dphi = khatri(V, U)*diag(1i*B);

dBr = khatri(khatri(khatri(V, U),W), Y);
dBi = dBr*1i*diag(B);


dw1 = khatri(khatri(khatri( V,1i*T1.*U),W), Y)*diag(B);
dw2 = khatri(khatri(khatri(1i*T2.*V, U),W),Y)*diag(B);
dw3 = khatri(khatri(khatri(V,U),1i*T3.*W),Y)*diag(B);
dw4 = khatri(khatri(khatri(V,U),W),1i*T4.*Y)*diag(B);

D = [dw1, dw2, dw3,dw4, dBr, dBi];
I = real(D'*D);
F = diag(inv(I))*sigma2/2;
end

