function w=findmax(x,K,Steering)
 xL=x(1:end-2);
 xM=x(2:end-1);
 xR=x(3:end);
 qM= find(xM>xL&xM>xR)+1;
 [w,index]=sort(-x(qM));
 w= Steering(qM(index(1:K)));
end