function f = MD_RootMUSIC3D(Signal, K)
[M1,M2,M3]=size(Signal);
%===================================================================
%First Dimension
f = zeros(K,3);
R1=0;
for iDim3=1:M3
    R1=R1+Signal(:,:,iDim3)*Signal(:,:,iDim3)';
end
R1=R1/M3;
[v,~]=svd(R1);

v=v(:,1:K);
E=eye(M1)-v*v';
s=zeros(2*M1-1,1);
for k=-(M1-1):(M1-1)
    s(k+M1)=sum(diag(E,-k));
end
ra=roots(s);
rb=ra(abs(ra)<1);
[~,I]=sort(abs(abs(rb)-1));
f0=angle(rb(I(1:K)));
f(:, 1)=sort(f0);
%======================================================
%Second Dimension
G=exp(1i*(1:M1)'*f(:,1)');
for k=1:K
    Gt=G;
    Gt(:,k)=[];
    Pt=eye(M1)-Gt/(Gt'*Gt)*Gt';
    Rt=0;
    for iDim3=1:M3
        Xt=Pt*(Signal(:,:,iDim3));
        Rt=Rt+Xt'*Xt;
    end
    Rt=Rt/M3;
    
    [u,~]=svd(Rt);
    u=u(:,1);
    E=eye(M2)-u*u';
    s=zeros(2*M2-1,1);
    for iRoot=-(M2-1):(M2-1)
        s(iRoot+M2)=sum(diag(E,-iRoot));
    end
    ra=roots(s);
    rb=ra(abs(ra)<1);
    [~,I]=min(abs(abs(rb)-1));
    f(k, 2)=-angle(rb(I));
%===============================================================
   Rt=0;
    for iDim2=1:M2
        Xt=Pt*squeeze(Signal(:,iDim2,:));
        Rt=Rt+Xt'*Xt;
    end
    Rt=Rt/M3;
    [u,~]=svd(Rt);
    u=u(:,1);
    E=eye(M3)-u*u';
    s=zeros(2*M3-1,1);
    for iRoot=-(M3-1):(M3-1)
        s(iRoot+M3)=sum(diag(E,-iRoot));
    end
    ra=roots(s);
    rb=ra(abs(ra)<1);
    [~,I]=min(abs(abs(rb)-1));
    f(k, 3)=-angle(rb(I));
end
end