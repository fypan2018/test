clc
close all
clear all

load 3D_Runtime_161616_17-Mar-2012
%================================================================
% Simulation results
display('-------------------------------------------------------------------------------------')
display('MD Frequency estimation Computational time comparation')
display('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
fprintf('f1 = [ %f  %f  %f ]\n', w1/pi)
fprintf('f2 = [ %f  %f  %f ]\n', w2/pi)
fprintf('f3 = [ %f  %f  %f ]\n', w3/pi)
%================================================================
figure(7)
axes1 = axes('YScale','log','YMinorTick','on');
hold(axes1,'all');
plot(Cubic, Time1 ,'*')  %Root-MUSIC
plot(Cubic, Time2 ,'ro') % FB Root-MUSIC
plot(Cubic, Time3 ,'^m') %IMDF
plot(Cubic, Time4 ,'s','color',   [0 .75 .75]) % HOSVD
xlabel('M_1 (M_1=M_2=M_3)')
ylabel('Computational Time (Second)');
legend('root MUSIC', 'FB root-MUSIC',  'IMDF', 'HOSVD', 2)
% %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
