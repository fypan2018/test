function CRB = CRB3D(w, M1, M2, M3, c, Noise_power)
% CRLB of Multidimensional frequency estimation
% Derived from "An eigenvectior-based approach for multidimensional 
% frequncy estimation with improved identifiability"
% w: frequcnies, the rows denoted for components and the column denoted for  dimension
% M1: first dimension sampling number
% M2: second dimension sampling number
% M3: third dimension sampling number
% A: amplitude for each components 
% 
M = M1*M2*M3;
A1 = exp(1j*(1: M1)'*w(:, 1)');
A2 = exp(1j*(1: M2)'*w(:, 2)');
A3 = exp(1j*(1: M3)'*w(:, 3)');
A = khatri(A1, khatri(A2, A3));
P = eye(M) - A/(A'*A)*A';

C = kron(eye(3), diag(c));

dA1 = khatri(1j*diag(1:M1)*A1, khatri(A2, A3));
dA2 = khatri(A1, khatri(1j*diag(1:M2)*A2, A3));
dA3 = khatri(A1, khatri(A2, 1j*diag(1:M3)*A3));

R = [dA1, dA2, dA3];
Fisher = real(C'*R'*P*R*C);
CRB = Noise_power*diag(inv(Fisher)/2);
end
function X = khatri(A, B)
[r, c] = size(A);
for i = 1:c
    X(:, i) = kron(A(:, i), B(:, i));
end
end