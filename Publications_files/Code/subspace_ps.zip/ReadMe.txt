Please first install tensor_toolbox.

SEE: ...\tensor_toolbox\INSTALL.txt

More details please visit the Tensor Toolbox homepage at:

http://csmr.ca.sandia.gov/~tgkolda/TensorToolbox/

Thanks.

13/June/2012
