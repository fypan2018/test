function w = HOSVD_3D(Signal, K)
%================================================
% An Eigenvector-Based Approach for Multidimensional 
% Frequency Estimation With Improved Identifiability
% Signal: data matrix
% K: number of signal components
% f1: frequency estimate in first dimension
% f2: frequency estimate in second dimension
% f3: frequency estimate in third dimension
% alpha: amplitude estimate
% 2011.02.19
%=================================================
M=size(Signal);                                  
R=length(M);                                      
X=tensor(Signal);
L=4*ones(1,R);
Msub=M-L+1;
Ys=tenzeros([Msub prod(L)]);
i=1;
for l3=1:L(3)
      for l2=1:L(2)
            for l1=1:L(1)
                  J={ };
                  l=[l1 l2 l3];
                  for r=1:R
                        J=[J, [ zeros(Msub(r), l(r)-1) eye(Msub(r)) zeros(Msub(r), L(r)-l(r))] ];
                  end
                  Ys(:,:,:,i)=ttensor(X,J);
                  i=i+1;
            end
      end
end
Y= tucker_als(Ys, [Msub prod(L)],'printitn',0);
core=tensor(Y.core(1:K,1:K,1:K,1:K));
U={Y.U{1}(:,1:K), Y.U{2}(:,1:K), Y.U{3}(:,1:K) Y.U{4}(:,1:K)};
S=ttensor(core,U);
Us=tensor(S);
M=size(Us);
U0=double(reshape(permute(Us, [R+1:-1:1]), [M(R+1), prod(M(1:R))]));
w=zeros(K,R);
for r=1:R
     J1=kron(kron(eye(prod(Msub(1:r-1))), [ eye(Msub(r)-1) zeros(Msub(r)-1,1)]), eye(prod(Msub(r+1:end))));
     J2=kron(kron(eye(prod(Msub(1:r-1))), [ zeros(Msub(r)-1,1) eye(Msub(r)-1) ]), eye(prod(Msub(r+1:end))));
     Phi=pinv(J1*U0.')*J2*U0.';
     [~,s]=eig(Phi);
     w(:,r)=sort(angle(diag(s(1:K,1:K))));
end
end