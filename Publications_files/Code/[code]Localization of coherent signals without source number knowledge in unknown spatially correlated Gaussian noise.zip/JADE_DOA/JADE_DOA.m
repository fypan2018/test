function [Power] = JADE_DOA(x, theta)
% Cheng Qian, Harbin Institute of Technology.
% Data: Feb.26, 2015
%
% Free to use. Please cite our paper:
%
% C.Qian, L.Huang, Y.Xiao and H.C.So, "Localization of coherent signals 
% without source number knowledge in unknown spatially correlated Gaussian 
% noise," Signal Processing, vol.111, no.6, pp.170-178, June 2015
%
% if the code is used in publications.


[M, ~] = size(x);
R_tot = cum4(x);
L = length(R_tot);
m = floor(M/2); 
Power = zeros(1,length(theta));
for iTheta = 1:length(theta)
    a = exp(1j*pi*[0:m]'*sind(theta(iTheta)));
    max_eig = 0; 
    for iR = 1:L
        R_hat = R_tot{iR};
        F = zeros(m+1); G = [];
        for iF = 1:m+1,%M
            F_tmp = toeplitz(fliplr(R_hat(iF,1:m+1)),R_hat(iF,m+1:end));
            F = F + F_tmp'*F_tmp;
            G = [G, F_tmp'*a];
        end
        max_eig = max( eig(G'*pinv(F)*G) ) + max_eig;
    end
    P_tmp = L*(m+1) - max_eig;
    Power(iTheta) = 1/abs(P_tmp);
    Power(iTheta) = 10*log10(1/real(P_tmp));
end
Power = Power - min(Power);
Power = Power / max(Power);
end


%%
function [R_tot] = cum4(x)
[M,N] = size(x);
R_tot = cell(1,M*(M+1)/2);
x = x - mean(x,2) * ones(1,N);
n = 0;
for k3 = 1:M,
    for k4 = 1:M,
        R = zeros(M);
        if k3<=k4,
            for i = 1:M,
                for j = 1:M,
                    R(i,j) = cum4x(x(j,:), x(k3,:), x(k4,:), x(i,:));
                end
            end
            n = n + 1;
            R_tot{n} = R;
        end
    end
end
end
