function x = StatSigGenerate(M, N, DOA, SNR, P, Q, mode)
% Cheng Qian, Harbin Institute of Technology.
% Data: Feb.26, 2015
%
% Free to use. Please cite our paper:
%
% C.Qian, L.Huang, Y.Xiao and H.C.So, "Localization of coherent signals 
% without source number knowledge in unknown spatially correlated Gaussian 
% noise," Signal Processing, vol.111, no.6, pp.170-178, June 2015
%
% if the code is used in publications.

warning off;
if nargin == 6
    mode = 'color';
end

m = floor(M/2);
K = length(DOA);
G = length(P);


st = [];
for i = 1:G
    x_tmp = randint(1,N,4); st_tmp = qammod(x_tmp,4);
    st = [st; st_tmp];
end
st = Q*st;

st = st/sqrt(trace(st*st'/N)/K);

if strcmp(mode,'white')
    nt = sqrt(0.5)*( randn(M,N) + 1j*randn(M,N) );
elseif strcmp(mode, 'color')
    nt = sqrt(0.5)*( randn(M,N) + 1j*randn(M,N) );
    Rn = zeros(M);
    for i = 1:M,
        for j = 1:M,
            Rn(i,j) = 0.7^(abs(i-j)) * exp(1j*pi/2*(i-j));
        end
    end
    nt = Rn^(0.5)*nt;
end
nt = nt/sqrt(trace(nt*nt'/N)/M);


A = exp(1j*pi*[-m:m]'*sind(DOA));

SNR = ones(1,K)*SNR;
Amp = diag(10.^(SNR/20));
x = A*Amp*st + nt;

end