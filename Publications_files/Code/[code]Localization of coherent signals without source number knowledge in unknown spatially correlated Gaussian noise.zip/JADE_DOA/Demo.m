% Cheng Qian, Harbin Institute of Technology.
% Data: Feb.26, 2015
%
% Free to use. Please cite our paper:
%
% C.Qian, L.Huang, Y.Xiao and H.C.So, "Localization of coherent signals 
% without source number knowledge in unknown spatially correlated Gaussian 
% noise," Signal Processing, vol.111, no.6, pp.170-178, June 2015
%
% if the code is used in publications.
%
% To use this code, please install the 'hosa' toolbox for higher-order cumulant analysis.
%--------------------------------------------------------------

clc; clear all; close all;

M = 7;
DOA = [-23,-1,30];
SNR = 10;
N = 100;
theta = -90:0.5:90;
noDOA = length(DOA);

x = StatSigGenerate(M, N, DOA, SNR, [2,1], [0,1;0,1;1,0], 'color');
P_cum = JADE_DOA(x, theta);


figure
plot(theta, P_cum,'b'); hold on;
plot([DOA(1),DOA(1)],[0,1],'r', [DOA(2),DOA(2)],[0,1],'r', [DOA(3),DOA(3)], [0,1], 'r')
xlabel('\theta (degree)'); ylabel('Normalized Power'); title('Proposed');axis tight;


