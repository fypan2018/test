% Cheng Qian, Harbin Institute of Technology.
% Data: Oct.12, 2014
%
% Free to use. Please cite our paper:
%
% C.Qian, L.Huang, W.-J.Zeng and H.C.So, "Direction-of-arrival estimation 
% for coherent signals without knowledge of source number," IEEE Sensors Journal,
% vol.14, no.9, pp.3267-3273, September 2014
%
% if the code is used in publications.

function Power = JADE_DOA(x, theta)

[M, N] = size(x);

R_hat = 1/N * x * x';

m = floor(M/2); F = zeros(m+1); F_cell = cell(1, M);
for i = 1:M
    F_cell{i} = toeplitz(fliplr(R_hat(i,1:m+1)),R_hat(i,m+1:end));
    F = F + F_cell{i}'*F_cell{i};
end

Power = zeros(1,length(theta));
for i  = 1:length(theta),
    a = exp(1j*pi*[0:m]'*sind(theta(i)));
    G = [];
    for j = 1:M,
        F_tmp = F_cell{j};
        G = [G, F_tmp'*a];
    end
    max_eig = max( eig(G'*pinv(F)*G) );
    P_tmp = real(m+1 - max_eig);
    Power(i) = 10*log10(1/P_tmp);
    
end

Power = Power - min(Power);
Power = Power / max(Power);

end