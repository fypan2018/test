function x = StatSigGenerate(M, N, DOA, SNR, SignalMode, NoiseMode)
% Cheng Qian, Harbin Institute of Technology.
% Data: Oct.12, 2014
%
% Free to use. Please cite our paper:
%
% C.Qian, L.Huang, W.-J.Zeng and H.C.So, "Direction-of-arrival estimation 
% for coherent signals without knowledge of source number," IEEE Sensors Journal,
% vol.14, no.9, pp.3267-3273, September 2014
%
% if the code is used in publications.

if nargin<7
    SNR_ArrayError = 0;
end

m = floor(M/2);
d = length(DOA);


%---------Signal----------------------
if strcmp(SignalMode, 'Independent')
    st = randn(d,N) + 1j*randn(d,N);
elseif strcmp(SignalMode, 'Coherent')
    st = [];
    st1 = randn(1,N) + 1j*randn(1,N);
    for k = 1:d,
        st = [st; st1];
    end
end
st = st/sqrt(trace(st*st'/N)/d);
%----------------------------------------


%--------------Noise----------------------
if strcmp(NoiseMode, 'white')
    nt = randn(M,N) + 1j*randn(M,N);
elseif strcmp(NoiseMode, 'color')
    nt = randn(M,N) + 1j*randn(M,N);
    Rn = zeros(M);
    for k = 1:M,
        for l = 1:M,
            Rn(k,l) = 0.99^(abs(k-l)) * exp(1j*pi/2*(k-l));
%             Rn1(k,l) = sinc(pi*abs(k-l)) * exp(1j*pi/2*(k-l));
        end
    end
    nt = Rn^0.5*nt;
end
nt = nt/sqrt(trace(nt*nt'/N)/M);
%----------------------------------------


SNR = ones(1,d)*SNR;
Amp = diag( 10.^(SNR/20) );

A = exp(1j*pi*[-m:m]'*sind(DOA));

x = A*Amp*st + nt;


end