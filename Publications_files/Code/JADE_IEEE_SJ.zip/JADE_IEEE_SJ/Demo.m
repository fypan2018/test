% Cheng Qian, Harbin Institute of Technology.
% Data: Oct.12, 2014
%
% Free to use. Please cite our paper:
%
% C.Qian, L.Huang, W.-J.Zeng and H.C.So, "Direction-of-arrival estimation 
% for coherent signals without knowledge of source number," IEEE Sensors Journal,
% vol.14, no.9, pp.3267-3273, September 2014
%
% if the code is used in publications.

clc; clear all; close all;


M = 5;
DOA = [-36,6,44];
SNR = 10;
N = 400;
theta = -90:0.1:90;
noDOA = length(DOA);
%-----------------------------

x = StatSigGenerate(M, N, DOA, SNR, 'Independent', 'white');
Power = real(JADE_DOA(x, theta));

figure
plot(theta, Power); hold on;
xlabel('DOA (\circ)'); ylabel('Normalized spectrum');
axis tight;
plot([DOA(1),DOA(1)], [0,1], 'r', [DOA(2),DOA(2)], [0,1], 'r',  [DOA(3),DOA(3)], [0,1], 'r'); hold on
plot(DOA(1), 1, 'r^', DOA(2), 1, 'r^',  DOA(3), 1, 'r^');
%-----------------------------------------------------------
