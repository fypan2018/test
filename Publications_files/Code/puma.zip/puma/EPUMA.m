function [doa_hat] = EPUMA(x, K, L, maxIter)

%% If you find the code is useful, please cite our paper
% C. Qian, L. Huang, N. D. Sidiropoulos and H. C. So, 
% "Enhanced PUMA for direction-of-arrival estimation and its performance analysis," 
% IEEE Transactions on Signal Processing, vol.64, no.16, pp.4127-4137, 2016. 
%%

warning off;

if nargin<3
    L = K + 1;
    maxIter = 3; 
elseif nargin<4
    maxIter = 3;
end

[M,N] = size(x);
R     =  x*x'/N;
J     =  fliplr(eye(M));
R     =  0.5*(R + J*conj(R)*J);
[U,S] =  svd(R);
U     =  U(:,1:K);
S     =  diag(S);

DOA_Cand = pumaUpdate(U, S, L, K, maxIter);

DOA_bank = combntns(DOA_Cand,K);
for i = 1:size(DOA_bank,1)
    A = exp(1j*pi*[0:M-1]'*sind(DOA_bank(i,:)))/sqrt(M);
    mlObjVal(i) = trace((eye(M)-A/(A'*A)*A')*R);
end
[~,I] = min(mlObjVal);

doa_hat = sort(DOA_bank(I,:));

end



function DOA = pumaUpdate(U,S,L,K,maxitr)
M = size(U,1);
D = [];
for i = 1:K
    D = [D; toeplitz(U(L:M-1,i), U(L:-1:1,i))];
end
f = -vec(U(L+1:end,:));

sigman2 = mean(S(K+1:M));
SS = S(1:K) + 1e-10;
c = D\f;
for i = 1:maxitr
    A = toeplitz([c(L),zeros(1,M-L-1)].', [fliplr(c.'),1,zeros(1,M-L-1)]);
    W = kron(diag((SS - sigman2).^2./SS), inv(A*A'));
    c = (D'*W*D)\D'*W*f;
end
c1 = c;

c = [1, c1.'];
rs = roots(c);

DOA = asin(angle(rs)/pi)*180/pi;
end