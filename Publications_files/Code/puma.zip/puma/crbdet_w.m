function sig = crbdet_w(A,R_idl,Rs,doa,N,noisePower)
% *****************************************************************************
%   *  DBT, A Matlab Toolbox for Radar Signal Processing  *
% (c) FOA 1994-2000. See the file dbtright.m for copyright notice.
%
%  function sig = crbdet_m(msensor,doas,S,N)
%
%  Computes the Deterministic Cramer-Rao Bound
%
%  sig      RealVectorT CRB, standard deviations [radians]
%  antenna  AntDefT
%  doas     Vector of DoaT  Directions of arrival
%  S     RealMatrixT Source signal covariance matrix
%  N     IntScalarT  Number of snapshots
%  lambda       RealScalarT     Wavelength [m].

%  Start        : 961120 Fredrik Athley (freath).
%  Latest change: $Date: 2000/10/16 15:20:17 $ $Author: svabj $.
%  $Revision: 1.8 $
% *****************************************************************************
Shat = Rs*A'*inv(R_idl)*A*Rs;
[m,n] = size(A);
D = 1j*[0:m-1]'*pi*cosd(doa).*A;
[Q,R] = qr(A);
Q2 = Q(:,n+1:m);
Paperp = Q2*Q2';
%R = A*S*A' + noisePower*eye(m);
B = noisePower/(2*N)*inv(real((D'*Paperp*D).*(Shat.')));
sig = trace(B);