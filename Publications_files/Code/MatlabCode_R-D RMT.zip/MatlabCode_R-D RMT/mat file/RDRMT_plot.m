close all; clc;

% figure;
% set(gcf,'DefaultAxesColorOrder',[0 0 0; 0 0 1; 0 1 0; 0 1 1; 1 0 0; 1 0 1; 1 1 0]);
% plot(SNR,p_MDL(:,1),'*-');
% hold all
% for r=2:ndim
%     plot(SNR,p_MDL(:,r),'+-.');
%     hold all
% end
% hold off
% legend('MDL:\bf{Y}\rm^{(1)}','MDL:other unfolded matrix');
% xlabel('SNR (dB)');
% ylabel('Pr(K_{est} =  K)'); grid on;
% %title(['R=' num2str(R),', M=[' num2str(M),'], K=' num2str(K), ', \alpha= ' num2str(alpha_KN) ]);
% grid on; axis tight
% 
% figure;
% set(gcf,'DefaultAxesColorOrder',[0 0 0; 0 0 1; 0 1 0; 0 1 1; 1 0 0; 1 0 1; 1 1 0]);
% plot(SNR,p_AIC(:,1),'*-');
% hold all
% for r=2:ndim
%     plot(SNR,p_AIC(:,r),'+-.');
%     hold all
% end
% hold off
% legend('AIC:\bf{Y}\rm^{(1)}','AIC:other unfolded matrix');
% xlabel('SNR (dB)');
% ylabel('Pr(K_{est} =  K)'); grid on;
% %title(['R=' num2str(R),', M=[' num2str(M),'], K=' num2str(K), ', \alpha= ' num2str(alpha_KN) ]);
% grid on; axis tight

figure;
% set(gcf,'DefaultAxesColorOrder',[0 0 0; 0 0 1; 0 1 0; 0 1 1; 1 0 0; 1 0 1; 1 1 0]);
plot(SNR,p_KN1(:,1),'ro-');
hold all
for r=2:ndim
    plot(SNR,p_KN1(:,r),'bx-.');
    hold all
end
hold off
legend('RMT:\bf{Y}\rm^{(1)}','RMT:other unfolded matrices',4);
xlabel('SNR (dB)');
ylabel('Pr(K_{est} =  K)'); grid on;
%title(['R=' num2str(R),', M=[' num2str(M),'], K=' num2str(K), ', \alpha= ' num2str(alpha_KN1) ]);
grid on; axis tight

figure;
% set(gcf,'DefaultAxesColorOrder',[0 0 0; 0 0 1; 0 1 0; 0 1 1; 1 0 0; 1 0 1; 1 1 0]);
plot(SNR,p_KN2(:,1),'ro-');
hold all
for r=2:ndim
    plot(SNR,p_KN2(:,r),'bx-.');
    hold all
end
hold off
legend('RMT:\bf{Y}\rm^{(1)}','RMT:other unfolded matrices',4);
xlabel('SNR (dB)');
ylabel('Pr(K_{est} =  K)'); grid on;
%title(['R=' num2str(R),', M=[' num2str(M),'], K=' num2str(K), ', \alpha= ' num2str(alpha_KN2) ]);
grid on; axis tight

% figure;
% % set(gcf,'DefaultAxesColorOrder',[0 0 0; 0 0 1; 0 1 0; 0 1 1; 1 0 0; 1 0 1; 1 1 0]);
% plot(SNR,p_ModKN(:,1),'ro-');
% hold all
% for r=2:ndim
%     plot(SNR,p_ModKN(:,r),'bx-.');
%     hold all
% end
% hold off
% legend('Modified RMT:\bf{Y}\rm^{(1)}','Modified RMT:other unfolded matrices');
% xlabel('SNR (dB)');
% ylabel('Pr(K_{est} =  K)'); grid on;
% %title(['R=' num2str(R),', M=[' num2str(M),'], K=' num2str(K), ', \alpha= ' num2str(alpha_KN) ]);
% grid on; axis tight


% figure;
% set(gcf,'DefaultAxesColorOrder',[0 0 0; 0 0 1; 0 1 0; 0 1 1; 1 0 0; 1 0 1; 1 1 0]);
% plot(SNR,p_Rev1KN(:,1),'*-');
% hold all
% for r=2:ndim
%     plot(SNR,p_Rev1KN(:,r),'+-.');
%     hold all
% end
% hold off
% legend('modified RMT I:\bf{Y}\rm^{(1)}','modified RMT I:other unfolded matrix');
% xlabel('SNR (dB)');
% ylabel('Pr(K_{est} =  K)'); grid on;
% %title(['R=' num2str(R),', M=[' num2str(M),'], K=' num2str(K), ', \alpha= ' num2str(alpha_KN) ]);
% grid on; axis tight
%
% figure;
% set(gcf,'DefaultAxesColorOrder',[0 0 0; 0 0 1; 0 1 0; 0 1 1; 1 0 0; 1 0 1; 1 1 0]);
% plot(SNR,p_Rev2KN(:,1),'*-');
% hold all
% for r=2:ndim
%     plot(SNR,p_Rev2KN(:,r),'+-.');
%     hold all
% end
% hold off
% legend('modified RMT II:\bf{Y}\rm^{(1)}','modified RMT II:other unfolded matrix');
% xlabel('SNR (dB)');
% ylabel('Pr(K_{est} =  K)'); grid on;
% %title(['R=' num2str(R),', M=[' num2str(M),'], K=' num2str(K), ', \alpha= ' num2str(alpha_KN) ]);
% grid on; axis tight

figure;
% set(gcf,'DefaultAxesColorOrder',[0 0 0; 0 0 1; 0 1 0; 0 1 1; 1 0 0; 1 0 1; 1 1 0]);
plot(SNR,p_MDL,'k.-');
hold all
plot(SNR,p_AIC,'mx:');
hold all
plot(SNR,p_KN1(:,1),'b+-.');
hold all
plot(SNR,p_KN2(:,1),'gs--');
hold all
plot(SNR,p_ModKN(:,1),'ro-');
% hold all
% plot(SNR,p_Rev1KN(:,1),'gx-.');
% hold all
% plot(SNR,p_Rev2KN(:,1),'b*--');
RMT1 = ['R-D RMT(\alpha_1= ' num2str(alpha_KN1),')'];
RMT2 = ['R-D RMT(\alpha_2= ' num2str(alpha_KN2),')'];
legend('MDL','AIC',RMT1,RMT2,'Adaptive R-D RMT',4);%,'modified RMT II');
xlabel('SNR (dB)');
ylabel('Pr(K_{est} =  K)'); grid on;
%title(['R=' num2str(R),', M=[' num2str(M),'], K=' num2str(K)]);
grid on; axis tight

% figure;
% % set(gcf,'DefaultAxesColorOrder',[0 0 0; 0 0 1; 0 1 0; 0 1 1; 1 0 0; 1 0 1; 1 1 0]);
% plot(SNR,p_MDL,'k-');
% hold all
% plot(SNR,p_AIC,'mx:');
% hold all
% plot(SNR,p_KN1(:,1),'bo-.');
% legend('MDL','AIC','R-D RMT');%,'modified RMT II');
% xlabel('SNR (dB)');
% ylabel('Pr($\hat{d} = d$)','interpreter','latex'); grid on;
% %title(['R=' num2str(R),', M=[' num2str(M(1:end-1)),'], N=' num2str(N),', d=' num2str(K)]);
% grid on; axis tight

% figure;
% set(gcf,'DefaultAxesColorOrder',[0 0 0; 0 0 1; 0 1 0; 0 1 1; 1 0 0; 1 0 1; 1 1 0]);
% plot(SNR,p_MDL(:,1),'*-');
% hold all
% plot(SNR,p_KN(:,1),'+-.');
% % hold all
% % plot(SNR,p_Rev1KN(:,1),'+-.');
% hold all
% plot(SNR,p_Rev2KN(:,1),'+-.');
% legend('MDL','RMT','modified RMT');% I','RMT modified II');
% xlabel('SNR (dB)');
% ylabel('Pr(K_{est} =  K)'); grid on;
% %title(['R=' num2str(R),', M=[' num2str(M),'], K=' num2str(K), ', \alpha= ' num2str(alpha_KN) ]);
% grid on; axis tight


% n=1000:1e5;
% for i=1:length(n)
%     alpha=0.1/n(i)^2;
%     s_Wishart(i) = KN_s_Wishart(alpha,beta);
% end
% plot(n,s_Wishart./sqrt(n))
% grid on; axis tight