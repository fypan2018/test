function alpha = compute_alpha(kk,max_kk,alpha_min,alpha_max)
% function [K sigma_hat] = KN_rankEst(ell,n,beta,alpha,max_kk)
%
% Code by Shira Kritchman and Boaz Nadler
% 2008, Weizmann Institute of Science
 % --------------------------------------------
% DESCRIPTION:
%  This function gets as input the eigenvalues of an SCM
%   (sample covariance matrix), and outputs an estimation of its
%   pseudorank, under the assumption of uncorrelated homoscedastic noise.
 %
% INPUT:
%   ell     -  vector of eigenvalues of the SCM, of length p
%   n       -  number of samples
%   beta    -  indicator for real (1) or complex (2) valued observations
%   alpha   -  confidence level, given in percents
 %   max_kk  -  maximal possible value for pseudorank
%
% DEFAULT:
%   if nargin<4 alpha = 0.5
%   if nargin<5 max_kk = min(n,p)-1
%
% OUTPUT:
%   K - pseudorank estimation for the SCM
% sigma_hat - estimate of noise variance.
 % --------------------------------------------
% FOR MORE DETAILS SEE:
%   S. Kritchman and B. Nadler. Determining the number of components in a factor model
%   from limited noisy data, Chem. Int. Lab. Sys. 2008
 % --------------------------------------------

% alpha_min = 0.001;
% alpha_max = 0.100;
% alpha = alpha_min + (kk-1)*(alpha_max-alpha_min)/(max_kk-1);

% alpha_unit = 0.5/max_kk^2;
% alpha = kk^2*alpha_unit;
 
% alpha_min = 1e-3;
% alpha_max = 0.5;
%
% mid = fix((max_kk+1)/2);
%
% if kk <= mid
%     log_alpha = log(alpha_min)+(kk-1)*(log(alpha_max)-log(alpha_min))/(mid-1);
%     alpha = exp(log_alpha);
 % else
%     kk = (max_kk+1) - kk;
%     alpha_min = 1e-5;
%     log_alpha = log(alpha_min)+(kk-1)*(log(alpha_max)-log(alpha_min))/(mid-1);
%     alpha = 1-exp(log_alpha);
% end

% alpha_min = 1e-3;
 % alpha_max = 0.1;
% alpha = alpha_min + (kk-1)*(alpha_max-alpha_min)/(max_kk-1);
% log_alpha = log(alpha_min)+(kk-1)*(log(alpha_max)-log(alpha_min))/(max_kk-1);
% alpha = exp(log_alpha);
% alpha = alpha1 + (alpha2-alpha1)*(kk-1)^1/(max_kk-1)^1;
 
mid = fix((max_kk+1)/2);
alpha_mid = (alpha_min+alpha_max)/2.0;

if kk <= mid
    log_alpha = log(alpha_min)+(kk-1)*(log(alpha_mid)-log(alpha_min))/(mid-1);
    alpha = exp(log_alpha);
else
    kk = (max_kk+1) - kk;
    log_alpha = log(alpha_min)+(kk-1)*(log(alpha_mid)-log(alpha_min))/(mid-1);
    alpha = (alpha_min+alpha_max)-exp(log_alpha);
end

% if alpha1==1e-4
%     al = alpha1*[1 5 10 50 100*(1:10)];
 % elseif alpha1==1e-3
%     al_left = alpha1*[1 5 10*(1:5)];
%     al_right = (alpha1+alpha2)-fliplr(al_left(1:end-1));
%     al = [al_left al_right];
% else
%         al_left = alpha1*[1 5 10*(1:5)];
%     al_right = (alpha1+alpha2)-fliplr(al_left(1:end-1));
 %     al = [al_left al_right];
% end
%
% alpha = al(1 + fix((length(al)-1)*(kk-1)/(max_kk-1)));

% exp_alpha = exp(alpha_min)+(kk-1)*(exp(alpha_max)-exp(alpha_min))/(max_kk-1);
% alpha = log(exp_alpha);

% alpha_min = 1e-4;
% alpha_max = 1-alpha_min; 
% max_kk = 24;
% kk=1:max_kk;
% alpha = zeros(1,length(kk));
% for i=1:length(kk)
%     alpha(i) = compute_alpha(kk(i),max_kk,alpha_min,alpha_max);
% end
% figure
% plot(kk,alpha);
% legend('MDL','AIC',RMT1,RMT2,'modified RMT');%,'modified RMT II');
% xlabel('k','fontsize',11);
% ylabel('\alpha(k)','fontsize',11);
% % titlename = ['\alpha_{min}= ', num2str(alpha_min), ', alpha_{max}= ', num2str(alpha_max)];
% title(['\alpha_{min}= ', num2str(alpha_min), ', \alpha_{max}= ', num2str(alpha_max)]);
% grid on; axis tight
