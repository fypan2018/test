%demo_n

% simple performance curve of rank estimation using the algorithm proposed
% in Kritchman & Nadler,
% and compared to the MDL-based rank estimator, proposed by Wax & Kailath.

% YOU CAN CHANGE THE VALUES OF THE FOLLOWING 3 QUANTITIES:
% p  - number of sensors / dimensionality of each sample
% N  - array of values of number of samples n.
% lambda_population = % (noise-free) population eigenvalues

clear all;close all;clc
tic,

K = 54; N = 10; M = [9 8 7 N]; % K=5
R = length(M);
M_total = prod(M(1:R));

ndim = 2^(R-1)-1;
dim2 = zeros(ndim,1);
for r=1:ndim
    bin = dec2binxarray( r, R );
    dim_index = find(bin==1);
    M_rows = prod(M(dim_index));
    dim2(r) = min(M_rows,M_total/M_rows);
end
[dim2,I2] = sort(dim2,1,'descend');

for r=1:ndim
    bin = dec2binxarray( I2(r), R );
    dim_index = find(bin==1);
    if prod(M(dim_index))~=dim2(r)
        I2(r) = 2^R-1-I2(r);
    end
end

seed = 97289342856; randn('state',seed); % for reproducibility. Change the seed for new results
NTrials = 2000;  % number of iterations per each value of p,n
beta = 2;   % beta=1 for real valued observations. Change to beta=2 for complex valued data and noise.
alpha_KN1 = 1e-2;%5/(dim2(1)^2*K^2; % confidence level for the algorithm by KN.
alpha_KN2 = 0.25;%5/(dim2(1)^2*K^2; % confidence level for the algorithm by KN.

display_alpha(dim2(1)-1, beta, alpha_KN1, alpha_KN2);

sigma_n = 1.0;
SNR = 10:0.5:50; %-20:0.5:10; %
L = length(SNR);

MDL  = zeros(L,NTrials);
AIC  = zeros(L,NTrials);
KN1 = zeros(L,NTrials,ndim);
KN2 = zeros(L,NTrials,ndim);
ModKN = zeros(L,NTrials,ndim);
sigma_hat1 = zeros(L,NTrials,ndim);
sigma_hat2 = zeros(L,NTrials,ndim);

p_MDL = zeros(L,1);
p_AIC = zeros(L,1);
p_KN1 = zeros(L,ndim);
p_KN2 = zeros(L,ndim);
p_ModKN = zeros(L,ndim);

for nTrial = 1:NTrials
    A = cell(1,R-1);
    for r=1:R-1
        A{r} =  exp(1j*(0:M(r)-1)'*(2*pi*rand(1,K)-pi));%/sqrt(M(r));
    end
    
    S = sqrt(1/2)*(randn(N,K) + 1j*randn(N,K));
    
    coef = ones(K,1);
    X = tensor(ktensor(coef,A{1},A{2},A{3},S));
    
    for l=1:L
        
        sigma_n = 10^(-SNR(l)/10);
        Z = tensor(sqrt(sigma_n/2)*(randn(M(1),M(2),M(3),N) + 1i*randn(M(1),M(2),M(3),N)));
        Y = X+Z;
        
        E2 = cell(1,ndim);
        dim_index = find(dec2binxarray( I2(1), R )==1);
        E2{1} = dim2(1)/M_total*svd(double(tenmat(Y, dim_index))).^2;
        p = dim2(1);n = M_total/dim2(1);
        AIC(l,nTrial) = rank_est_AIC(E2{1},p,n);
        MDL(l,nTrial) = rank_est_WK(E2{1},p,n);
        [KN1(l,nTrial,1),sigma_hat1(l,nTrial,1)] = KN_rankEst(E2{1},n,beta,alpha_KN1);
        [KN2(l,nTrial,1),sigma_hat2(l,nTrial,1)] = KN_rankEst(E2{1},n,beta,alpha_KN2);
        
        ModKN(l,nTrial,1) = ModKN_rankEst(E2{1},n,beta,alpha_KN1,alpha_KN2);
        
        for r=2:ndim
            dim_index = find(dec2binxarray( I2(r), R )==1);
            E2{r} = dim2(r)/M_total*svd(double(tenmat(Y, dim_index))).^2;
            p = dim2(r);n = M_total/dim2(r);
            [KN1(l,nTrial,r),sigma_hat1(l,nTrial,r)] = KN_rankEst(E2{r},n,beta,alpha_KN1);
            [KN2(l,nTrial,r),sigma_hat2(l,nTrial,r)] = KN_rankEst(E2{r},n,beta,alpha_KN2);
        end
    end
    if mod(nTrial,100)==0
        fprintf('%d / %d: done (%g s).\n',nTrial,NTrials,toc);
    end
end

for l=1:L  
    p_MDL(l) = length(find(MDL(l,:)==K)) / NTrials;
    p_AIC(l) = length(find(AIC(l,:)==K)) / NTrials;
    p_ModKN(l,1) = length(find(ModKN(l,:,1)==K)) / NTrials;
    
    for r=1:ndim       
        p_KN1(l,r) = length(find(KN1(l,:,r)==K)) / NTrials;
        p_KN2(l,r) = length(find(KN2(l,:,r)==K)) / NTrials;
    end
end

filename = ['mat file\R=', num2str(R-1),', M=[', num2str(M(1:end-1)),'], N= ',num2str(N),', K=', num2str(K),', alpha1= ', num2str(alpha_KN1), ', alpha2= ', num2str(alpha_KN2) ', NTrials= ' num2str(NTrials),'.mat'];
save(filename);

figure;
% set(gcf,'DefaultAxesColorOrder',[0 0 0; 0 0 1; 0 1 0; 0 1 1; 1 0 0; 1 0 1; 1 1 0]);
plot(SNR,p_KN1(:,1),'ro-');
hold all
for r=2:ndim
    plot(SNR,p_KN1(:,r),'bx-.');
    hold all
end
hold off
legend('RMT:\bf{Y}\rm^{(1)}','RMT:other unfolded matrices');
xlabel('SNR (dB)','fontsize',11);
ylabel('Pr(K_{est} =  K)','fontsize',11); grid on;
title(['R=' num2str(R),', M=[' num2str(M),'], K=' num2str(K), ', \alpha= ' num2str(alpha_KN1) ]);
grid on; axis tight

figure;
% set(gcf,'DefaultAxesColorOrder',[0 0 0; 0 0 1; 0 1 0; 0 1 1; 1 0 0; 1 0 1; 1 1 0]);
plot(SNR,p_KN2(:,1),'ro-');
hold all
for r=2:ndim
    plot(SNR,p_KN2(:,r),'bx-.');
    hold all
end
hold off
legend('RMT:\bf{Y}\rm^{(1)}','RMT:other unfolded matrices');
xlabel('SNR (dB)','fontsize',11);
ylabel('Pr(K_{est} =  K)','fontsize',11); grid on;
title(['R=' num2str(R),', M=[' num2str(M),'], K=' num2str(K), ', \alpha= ' num2str(alpha_KN2) ]);
grid on; axis tight

figure;
% set(gcf,'DefaultAxesColorOrder',[0 0 0; 0 0 1; 0 1 0; 0 1 1; 1 0 0; 1 0 1; 1 1 0]);
plot(SNR,p_MDL,'k.-');
hold all
plot(SNR,p_AIC,'mx:');
hold all
plot(SNR,p_KN1(:,1),'b+-.');
hold all
plot(SNR,p_KN2(:,1),'gs--');
hold all
plot(SNR,p_ModKN(:,1),'ro-');
% hold all
% plot(SNR,p_Rev1KN(:,1),'gx-.');
% hold all
% plot(SNR,p_Rev2KN(:,1),'b*--');
RMT1 = ['R-D RMT(\alpha_1= ' num2str(alpha_KN1),')'];
RMT2 = ['R-D RMT(\alpha_2= ' num2str(alpha_KN2),')'];
legend('MDL','AIC',RMT1,RMT2,'Adaptive R-D RMT');%,'modified RMT II');
xlabel('SNR (dB)','fontsize',11);
ylabel('Pr(K_{est} =  K)','fontsize',11); grid on;
title(['R=' num2str(R),', M=[' num2str(M),'], K=' num2str(K)]);
grid on; axis tight