function display_Wishart(beta)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

% alpha_min = 1e-4;
% alpha_max = 1-alpha_min; 
% max_kk = 24;
alpha_min=1e-32;
alpha = alpha_min:0.01:1-alpha_min;
x = zeros(1,length(alpha));

for i=1:length(alpha)
    x(i) = KN_s_Wishart(alpha(i),beta);
end
figure
plot(alpha,x);
% legend(['\alpha_{min}= ', num2str(alpha_min), ', \alpha_{max}= ', num2str(alpha_max)]);
xlabel('\alpha','fontsize',11);
ylabel('x','fontsize',11);
title('Inverse of the TW (Tracy-Widom) distribution F_{\beta}');
grid on; axis tight

if beta == 1
    load TW_beta1.mat
end

if beta == 2
    load TW_beta2.mat
end
figure
plot(x,TW_s);
% legend(['\alpha_{min}= ', num2str(alpha_min), ', \alpha_{max}= ', num2str(alpha_max)]);
xlabel('x','fontsize',11);
ylabel('TW(x)','fontsize',11);
title(['TW (Tracy-Widom) distribution F_{', num2str(beta),'}']);
grid on; axis tight

end
