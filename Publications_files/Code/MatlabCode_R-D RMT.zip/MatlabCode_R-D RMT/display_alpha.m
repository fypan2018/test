function display_alpha(max_kk, beta, alpha_min, alpha_max)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

% alpha_min = 1e-4;
% alpha_max = 1-alpha_min; 
% max_kk = 24;
kk=1:max_kk;
L = length(kk);
alpha = zeros(1,L);
for i=1:L
    alpha(i) = compute_alpha(kk(i),max_kk,alpha_min,alpha_max);
end
figure
plot(kk,alpha);
str = ['\leftarrow [\alpha_{min}, \alpha_{max}] = [', num2str(alpha_min),', ', num2str(alpha_max),']'];
idx = find(alpha-eps<=(alpha(1)+alpha(L))/2.0); i = idx(end);
text(i,alpha(i),str);
xlabel('k','fontsize',11);
ylabel('\alpha(k)','fontsize',11);
% title('Confidence level as a function of the number of signals');
grid on; axis tight

% beta = 2;
x = zeros(1,L);
for i=1:L
    x(i) = KN_s_Wishart(alpha(i),beta);
end
figure
plot(alpha,x);
% legend(['\alpha_{min}= ', num2str(alpha_min), ', \alpha_{max}= ', num2str(alpha_max)]);
xlabel('\alpha','fontsize',11);
ylabel('x','fontsize',11);
title(['Inverse of the TW (Tracy-Widom) distribution F_{', num2str(beta),'}']);
grid on; axis tight

figure
plot(kk,x);
% legend(['\alpha_{min}= ', num2str(alpha_min), ', \alpha_{max}= ', num2str(alpha_max)]);
xlabel('k','fontsize',11);
ylabel('x','fontsize',11);
title('Threshold level as a function of the number of signals');
grid on; axis tight

if beta == 1
    load TW_beta1.mat
end
if beta == 2
    load TW_beta2.mat
end
figure
plot(x,TW_s);
% legend(['\alpha_{min}= ', num2str(alpha_min), ', \alpha_{max}= ', num2str(alpha_max)]);
xlabel('x','fontsize',11);
ylabel('TW(x)','fontsize',11);
title(['TW (Tracy-Widom) distribution F_{', num2str(beta),'}']);
grid on; axis tight

end

