function K = rank_est_AIC(lambda,p,n)
% function K = rank_est_WK(lambda,p,n)
% AIC estimator for number of signals

a   = zeros(min(p,n),1); 
AIC = zeros(min(p,n),1); 

for k=0:min(p,n)-1
    a(k+1) = 1/(p-k) * sum(lambda(k+1:p)); 
    AIC(k+1) = -(p-k)*n*(  1/(p-k) * sum(log(lambda(k+1:p))) - log(a(k+1)) ) ; 
    AIC(k+1) = AIC(k+1) + k * (2*p-k) ;
end

[val, loc] = min(AIC); 

K = loc-1;

return; 
