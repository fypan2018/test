%% Implementation of the Truncated Amplitude Flow algorithm proposed in the paper
%  `` Solving Systems of Random Quadratic Equations via Truncated Amplitude
%  Flow'' by G. Wang, G. B. Giannakis, and Y. C. Eldar.
%  The code below is adapted from implementation of the (Truncated) Wirtinger Flow 
% algorithms implemented by E. Candes, X. Li, M. Soltanolkotabi, and Y. Chen.

function [z, time, t] = TAF2D(Y, Masks, x, z)

[n1,n2] = size(x);

%% TAF/STAF parameters
if exist('Params', 'var')         == 0,  Params.n2           = n2;    end
if isfield(Params, 'n1')          == 0,  Params.n1           = n1; end             % signal dimension

if isfield(Params, 'K')           == 0,  Params.K            = 6;   end
if isfield(Params, 'gamma')       == 0,  Params.gamma        = .7;   end	% thresholding of throwing small entries of Az 0.3 is a good one
if isfield(Params, 'imax')        == 0,  Params.T            = 1000;   end	% 
if isfield(Params, 'npower_iter') == 0,  Params.npower_iter  = 200;   end		% number of power iterations
if isfield(Params, 'mu')          == 0,  Params.mu           = 0.6;  end		% step size / learning parameter % originally 0.2

L = size(Masks,3);

A = @(I)  fft2(conj(Masks) .* reshape(repmat(I,[1 L]), size(I,1), size(I,2), L));
At = @(Y) sum(Masks .* ifft2(Y), 3) * size(Y,1) * size(Y,2);
obj = @(ax) sum(abs(Y(:).^0.5-abs(ax(:))).^2);
tic;

M   = numel(Y);

for t = 1:Params.T
        
    % TAF updates
    Az = A(z);
    ind = (abs(Az) ./ Y >= 1 / (1 + Params.gamma)); % gradient truncation
    grad = At(ind .* (Az - Y .* exp(1i * angle(Az)))) / M;
    
    z = z - Params.mu * real(grad);
    obj_val(t) = obj(Az);
    if t>150 && abs(obj_val(t)-obj_val(t-1))/obj_val(t-1) < 1e-7
        break;
    end
end

time = toc;

z = exp(1j*angle(trace(z'*x)))*z;