
function [xhat,time,niter] = FastAltGD_2D(y, Masks, x, z, p)

% C. Qian, X. Fu, N. D. Sidiropoulos, L. Huang and J. Xie,
% "Inexact alternating optimization for phase retrieval in the presence of outliers," 
% IEEE Transactions on Signal Processing, vol. 65, no. 22, pp. 6069-6082, 2017.


tic;

[n1,n2,L] = size(Masks);
m = n1*n2*L;

% if p>1
%     z = BSG_tmp(y, Masks, z, 1.7, 50, 1e-5);
% end
[z,niter] = BSG_tmp(y, Masks, z, p, 1000, 1e-7);


time = toc;

xhat = exp(1j*angle(trace(z'*x)))*z;
end

function [xhat,t] = BSG_tmp(y, Masks, z0, p, iter, eps)
L = size(Masks,3);
A = @(I)  fft2(conj(Masks) .* reshape(repmat(I,[1 L]), size(I,1), size(I,2), L));
At = @(Y) sum(Masks .* ifft2(Y), 3) * size(Y,1) * size(Y,2);
obj = @(ax) sum(abs(y(:)-abs(ax(:))).^2);

fl = @(tt) (1+sqrt(1+4*tt^2))/2;
y_s = z0;
for t = 1:iter,
    
    Bz = A(z0);
    r = Bz - y.*exp(1j*angle(A(z0)));
    r2 = abs(r).^(p-2);
    g = p/2*At(r2.*r);
    step = p/2*sum(r2(:));
    
    y_s1 = z0 - 1/step*real(g);
    
    if t==1
        lambda0 = 0;
        lambda1 = fl(lambda0);
        lambda2 = fl(lambda1);
    else
        lambda1 = lambda2;
        lambda2 = fl(lambda1);
    end
    gamma = (1-lambda1)/lambda2;
    z = (1-gamma)*y_s1 + gamma*y_s;
    
    obj_val(t) = obj(Bz);
    if t>2 && abs(obj_val(t)-obj_val(t-1))/obj_val(t-1) < eps
        break;
    end
    y_s = y_s1;
    z0 = real(z);
end
xhat = z;
end


