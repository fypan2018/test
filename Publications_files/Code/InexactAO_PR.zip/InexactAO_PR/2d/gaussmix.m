function x = gaussmix(M,N,a,v1,v2)

Ls = ceil(a*M);
x = zeros(M,N);
for i = 1:N
    [~, index] = sort(rand(M,1));
    x(index(1:Ls),i) = sqrt(v2)*randn(Ls,1);
    x(index(Ls+1:end),i) = sqrt(v1)*randn(M-Ls,1);
end    
