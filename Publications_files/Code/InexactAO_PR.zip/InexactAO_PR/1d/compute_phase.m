function b = compute_phase(a1, x1)

N = length(a1);
a = angle(a1);
x = angle(x1);
b = zeros(N,1);

for i = 1:N
%     tt = [abs(a(i) - x(i)), abs(a(i)+pi - x(i)), abs(a(i)-pi - x(i)),...
%         abs(a(i)+ 2*pi - x(i)), abs(a(i)-2*pi - x(i))];
%     tt2 = [a(i), a(i)+pi, a(i)-pi, a(i) + 2*pi, a(i) - 2*pi];
    tt = [abs(a(i) - x(i)), abs(a(i)+2*pi - x(i)), abs(a(i)-2*pi - x(i))];
    tt2 = [a(i), a(i)+2*pi, a(i)-2*pi];
   [~, I] = min(tt);
   b(i) = tt2(I);
end