%% Implementation of the truncated Wirtinger Flow (TWF) algorithm proposed in the paper
%  ``Solving Random Quadratic Systems of Equations Is Nearly as Easy as Solving Linear Systems'' by Y. Chen and E. J. Cand�s.
%  The code below is adapted from implementation of the Wirtinger Flow algorithm written by M. Soltanolkotabi and E. Candes

function [xhat,time, relerr] = TWF(y, Amatrix, x, eps, z, maxiter)
tic;

A  = @(I) Amatrix  * I;
At = @(Y) Amatrix' * Y;

% [Params.n1, Params.m] = size(Amatrix);

if exist('Params')                == 0,  Params.n2          = 1;    end
if isfield(Params, 'n1')          == 0,  Params.n1          = size(Amatrix,2); end             % signal dimension
if isfield(Params, 'm')           == 0,  Params.m           = size(Amatrix,1);  end     % number of measurements
if isfield(Params, 'cplx_flag')   == 0,  Params.cplx_flag   = 1;    end             % real: cplx_flag = 0;  complex: cplx_flag = 1;
if isfield(Params, 'grad_type')   == 0,  Params.grad_type   = 'TWF_Poiss';  end     % 'TWF_Poiss': Poisson likelihood

if isfield(Params, 'alpha_lb')    == 0,  Params.alpha_lb    = 0.3;  end
if isfield(Params, 'alpha_ub')    == 0,  Params.alpha_ub    = 5;    end
if isfield(Params, 'alpha_h')     == 0,  Params.alpha_h     = 5;    end
if isfield(Params, 'alpha_y')     == 0,  Params.alpha_y     = 3;    end
if isfield(Params, 'T')           == 0,  Params.T           = maxiter;  end    	% number of iterations
if isfield(Params, 'mu')          == 0,  Params.mu          = 0.2;  end		% step size / learning parameter
if isfield(Params, 'npower_iter') == 0,  Params.npower_iter = 50;   end		% number of power iterations

n           = Params.n1;
m           = Params.m;
cplx_flag	= Params.cplx_flag;

%% Initialization
npower_iter = Params.npower_iter;           % Number of power iterations
% z0 = randn(Params.n1,Params.n2); z0 = z0/norm(z0,'fro');    % Initial guess
normest = sqrt(sum(y(:))/numel(y(:)));    % Estimate norm to scale eigenvector

% for tt = 1:npower_iter,                     % Truncated power iterations
%     ytr = y.* (abs(y) <= Params.alpha_y^2 * normest^2 );
%     z0 = At( ytr.* (A(z0)) ); z0 = z0/norm(z0,'fro');
% end
% 
% z = normest * z0;                   % Apply scaling
Relerrs = norm(x - exp(-1i*angle(trace(x'*z))) * z, 'fro')/norm(x,'fro'); % Initial rel. error

%% Loop
grad_type = Params.grad_type;
if strcmp(grad_type, 'TWF_Poiss') == 1
    mu = @(t) Params.mu; % Schedule for step size
elseif strcmp(grad_type, 'WF_Poiss') == 1
    tau0 = 330;                         % Time constant for step size
    mu = @(t) min(1-exp(-t/tau0), 0.2); % Schedule for step size
end

relerr = [];
for t = 1: Params.T,
    z_old = z;
    grad = compute_grad(z, y, Params, A, At);
    z = z - mu(t) * grad;             % Gradient update
    Relerrs = [Relerrs, norm(x - exp(-1i*angle(trace(x'*z))) * z, 'fro')/norm(x,'fro')];
    obj1 = norm(y - abs( Amatrix*z).^2)^2;
    obj2 = norm(y - abs( Amatrix*z_old).^2)^2;
    err = abs(obj1 - obj2)/obj2;
    relerr = [relerr, err];
    if err<eps || t>Params.T
        break;
    end 
end

theta = angle(z'*x);
xhat = z * exp(1j*theta);

time = toc;
end

%%  Compute the truncated gradient based on the Poisson log-likelihood function

function grad = compute_grad(z, y, Params, A, At)
m = Params.m;
yz = A(z);
Kt = 1/m* norm(abs(yz(:)).^2 - y(:), 1);

if strcmp(Params.grad_type,'TWF_Poiss') == 1   % truncated gradient / Wirtinger flow
    % truncation rules
    Eub =  abs(yz) / norm(z)   <= Params.alpha_ub;
    Elb =  abs(yz) / norm(z)   >= Params.alpha_lb;
    Eh  =  abs(y - abs(yz).^2) <= Params.alpha_h * Kt / norm(z) * abs(yz);
    
    grad  = 1/m* At( 2* ( abs(yz).^2-y ) ./ (abs(yz).^2) .*yz ...
        .* Eub .* Elb .* Eh );    % truncated Poisson gradient
    
elseif strcmp(Params.grad_type,'WF_Poiss') == 1    % untruncated gradient / Wirtinger flow
    grad  = 1/m* At( 2* ( abs(yz).^2-y ) ./ (abs(yz).^2) .*yz ); % Poisson gradient
end

end
