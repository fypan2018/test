clc; clear all; close all; warning off;

N    = 16;
k    = 8;
M    = k*N;
prob = linspace(0,0.5,10);
SNR  = 10;
eps  = 1e-7;
p    = 0.4;
eta  = 1e-4;
x    = exp(1j*pi*0.16*[1:N]')/sqrt(N);

maxiter = 1000;
nT = 20;
for iP = 1:length(prob)
    
    Prob_of_outlier = prob(iP);
        
    parfor iT = 1:nT
        
        if ~rem(iT,nT/2)
            fprintf('dB = %d, Trials = %d\n', iP, iT)
        end
        
        %--------------Signal generate----------------------
        A  = Generate_Mask_A(N,k);
        SP = sum(abs(A*x).^2);
        nt = gaussmix(M,1,Prob_of_outlier,0,100);
        if Prob_of_outlier==0, 
            NP = 0; 
        else
            NP = SP/10^(SNR/10)/norm(nt)^2; 
        end;
        y = abs( A*x ) + sqrt(NP)*nt;
        %===================================================
        
        %------------Initialization: Power method-----------
        y2 = y.^2;
        z0 = randn(N,1); z0 = z0/norm(z0,'fro');
        normest = sqrt(median(y2(:))/0.455);
        for tt  = 1:50
            ytr = y2.* (abs(y2) <= 3^2 * normest^2 );
            z0  = A'*( ytr.* (A*z0) ); z0 = z0/norm(z0,'fro');
        end
        x_init = normest * z0;
        %===================================================
        
        x_TWF   = TWF(y2, A, x, eps, x_init, maxiter);
        x_IRLS  = AltIRLS(y, A, x, p, x_init, eps, maxiter);
        x_AltGD = FastAltGD(y, A, x, x_init, p, eps, maxiter);
        x_TAF   = TAF1D(y.^2, x, A);
        x_mTWF  = medianTWF(y.^2, x, A);
        
        MSE_IRLS_tmp(iT)  = norm(x_IRLS - x).^2;
        MSE_AltGD_tmp(iT) = norm(x_AltGD - x).^2;
        MSE_TWF_tmp(iT)   = norm(x_TWF - x).^2;
        MSE_TAF_tmp(iT)   = norm(x_TAF - x).^2;
        MSE_mTWF_tmp(iT)  = norm(x_mTWF - x).^2;

        
    end
    
    MSE_IRLS(iP)  = sum(MSE_IRLS_tmp<eta)/nT;
    MSE_AltGD(iP) = sum(MSE_AltGD_tmp<eta)/nT;
    MSE_TWF(iP)   = sum(MSE_TWF_tmp<eta)/nT;
    MSE_TAF(iP)   = sum(MSE_TAF_tmp<eta)/nT;
    MSE_mTWF(iP)  = sum(MSE_mTWF_tmp<eta)/nT;
     
end


ms = 8;
figure
plot(prob, MSE_IRLS,  'r-o',  'linewidth', 2, 'markersize', ms); hold on
plot(prob, MSE_AltGD, 'r-*',  'linewidth', 2, 'markersize', ms);
plot(prob, MSE_mTWF,  'm-x',  'linewidth', 2, 'markersize', ms);
plot(prob, MSE_TAF,   'b-s',  'linewidth', 2, 'markersize', ms);
plot(prob, MSE_TWF,   'g-p',  'linewidth', 2, 'markersize', ms);
xlabel('Outliers fraction'); ylabel('Success rate');
legend('AltIRLS', 'AltGD', 'MTWF', 'TAF', 'TWF')


