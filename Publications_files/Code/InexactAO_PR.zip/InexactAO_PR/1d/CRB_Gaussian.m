function crb = CRB(A, x, sigma2)
% y_i = |a_i^Hx| + n_i

% C. Qian, X. Fu, N. D. Sidiropoulos, L. Huang and J. Xie,
% "Inexact alternating optimization for phase retrieval in the presence of outliers," 
% IEEE Transactions on Signal Processing, vol. 65, no. 22, pp. 6069-6082, 2017.


F = [real(A'*diag(A*x)); imag(A'*diag(A*x))] / diag(abs(A*x).^2) * [real(A'*diag(A*x)); imag(A'*diag(A*x))]';

F = F/sigma2;

crb = trace(pinv(F));