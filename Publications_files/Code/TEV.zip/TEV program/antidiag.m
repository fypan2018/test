function ma=antidiag(M)

piM=eye(M,M);
ma=piM(end:-1:1,:);