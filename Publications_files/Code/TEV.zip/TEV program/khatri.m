function X = khatri(A, B)

[r, c] = size(A);

for i = 1:c
    X(:, i) = kron(A(:, i), B(:, i));
end