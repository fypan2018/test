function w = TEV1SLS(x, max_iter, kappa)

M=length(x);
J1=[eye(M-1), zeros(M-1,1)];
J2=[zeros(M-1,1), eye(M-1)];

x1=x(1:end-1);
x2=x(2:end);
ro=(x1'*x1)\x1'*x2;

xsk=zeros(M,1);
for i=1:max_iter
    Rk=x(1:end-1)*ro-x(2:end);
    f=-[Rk; kappa*xsk];
    
    F=[x(1:end-1), J1*ro-J2; zeros(M,1), kappa*eye(M)];
    delta_all=(F'*F)\F'*f;
    ro=ro+delta_all(1);
    x=x+delta_all(2:end);
    xsk=xsk+delta_all(2:end);
end
w=angle(ro);
