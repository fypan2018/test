W.Sun, H.C.So, F.K.W.Chan and L.Huang, "Tensor approach for eigenvector-based multi-dimensional harmonic retrieval," IEEE Transactions on Signal Processing, vol.61, no.13, pp.3378-3388, July 2013

1.
For ease of computation, please download the 'tptool' (tensor toolbox for MATLAB) from

http://tptool.sztaki.hu/

for the following files:

hosvd.m
ndim_unfold.m
tprod.m

2.
TEV_3DN: the main program (forward only)
TEV_FB_3DN: the main program (forward-backward)





