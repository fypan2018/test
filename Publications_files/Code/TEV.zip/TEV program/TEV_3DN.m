function [w1, w2, w3] = TEV_3DN(Y, P, max_iter, max_iter3, iteralpha2, Dim)
% TEV for 
% W.Sun, H.C.So, F.K.W.Chan and L.Huang, "Tensor approach for eigenvector-based multi-dimensional harmonic retrieval," IEEE Transactions on Signal Processing, vol.61, no.13, pp.3378-3388, July 2013

% input:
% Y: the measured 4D tensor: the last dimension is for snapshot information
% P: number of sources
% max_iter: \iota_2 in Table 1 of the paper
% max_iter3: \iota_1 in Table 1 of the paper
% iteralpha2: \kappa_2 in (38) of the paper, can be set to 1 for simplification
% Dim: No. of dimensions excluding the one for snapshot information, here Dim = 3

[L1,L2,L3,N]=size(Y);

[Score U sv tol] = HOSVD(Y);
u1=double(U{1}(:,1:P));
u2=double(U{2}(:,1:P));
u3=double(U{3}(:,1:min(P, L3)));
CoreT=double(Score(1:P,1:P,1:min(P, L3),1:P));

Lall=[L1, L2, L3];

alpha=exp(1i*rand(Dim,1)*2*pi)*sqrt(1/Dim);

J={[eye(L1-1), zeros(L1-1, 1)],[eye(L2-1), zeros(L2-1, 1)],[eye(L3-1), zeros(L3-1, 1)]};
Us_T1=tprod(CoreT, {J{1}*u1, J{2}*u2, J{3}*u3, []});
for i=1:max_iter+1
    if i == max_iter+1
        max_iter2 = max_iter3;
    else
        max_iter2 = 0;
    end
    Us_T2=0;
    for r=1:Dim
        J0=J;
        J0{r}=[zeros(Lall(r)-1, 1), eye(Lall(r)-1)];
        Us_T2=Us_T2+tprod(CoreT, {J0{1}*u1, J0{2}*u2, J0{3}*u3, []});
    end

    JU1=ndim_unfold(Us_T1, 4).';
    JU2=ndim_unfold(Us_T2, 4).';
    phi1=((JU1'*JU1)\JU1'*JU2).';
    
    [vector1,value1]=eig(phi1);
    TG=tprod(CoreT, {u1, u2, u3, inv(vector1)});
    
    w1=zeros(1,P);
    w2=zeros(1,P);
    w3=zeros(1,P);
    for p=1:P
        TGp=TG(:,:,:,p);
        [Sin Uin svin tolin] = HOSVD(TGp);
        ug1=double(Uin{1}(:,1));
        ug2=double(Uin{2}(:,1));
        ug3=double(Uin{3}(:,1));
        w1(p)=TEV1SLS(ug1, max_iter2, iteralpha2);
        w2(p)=TEV1SLS(ug2, max_iter2, iteralpha2);
        w3(p)=TEV1SLS(ug3, max_iter2, iteralpha2);
    end

    Wall=([w1;w2;w3]).';
    W=[];
    for j=2:P
        for i=1:j-1
            W=[W; exp(1i*Wall(i,:))-exp(1i*Wall(j,:))];
        end
    end
    Wei=W'*W;
    [u, s]=eig(Wei);
    [val, ind]=max(diag(s));
    alpha=u(:,ind);
end

[w1, index]=sort(w1);
w2=w2(index);
w3=w3(index);